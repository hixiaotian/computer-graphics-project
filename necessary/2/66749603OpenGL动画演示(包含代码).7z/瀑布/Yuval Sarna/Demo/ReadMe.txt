"Life vs. Routine" - A short demo created for NeHe's Mini-Contest 2003
-------------------------------------------------------------------------------------------------------

Thanks for downloading my demo. This demo was created for NeHe's Mini-Contest 2003.
The demo is about a serious subject, the routine and our life. I hope you take a way just a drop
from what I put into this. That would be a great reward for me.

PLEASE NOTE: Because the contest had a size limit of 500KB, this is just the short version of the demo.
The full version, which has many effects and a new scene, can be download here:
http://corky.net/rpg/FullDemo.zip (900KB)
Moreover, you may download the source code of the full version here:
http://corky.net/rpg/FullDemoSource.zip

Please read the license file if you plan to use the source code, and also, read the HowToCompile.txt file.

Credits:
Programmed & Developed by Yuval "Etus" Sarna
Tree Model by Soren "ZeeGate" Seeberg

Enjoy!
Yuval "Etus" Sarna
etus@actcom.net.il