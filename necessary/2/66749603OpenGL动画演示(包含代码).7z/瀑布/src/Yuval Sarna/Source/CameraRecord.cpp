//***********************************************************************//
//		Author:		Yuval "Etus" Sarna		etus@actcom.net.il			 //
//																		 //
//		Program:		Camera recording Class						     //
//																		 //
//		Description:	Record/Read the camera coords(cpp file)	         //
//																		 //
//		Date:			18.01.03										 //
//																		 //
//      NOTE: PLEASE CHECK THE LICENSE FILE FOR PREMISSION REGARDING     // 
//      THIS FILE AND THE OTHERS!                                        // 
//***********************************************************************//

#include "StdAfx.h"

CameraRecord :: CameraRecord(CCamera* pCamMan, char* filename, int doWhat) {

	// Variables init
	pCameraManager = *(&pCamMan);
	point = NULL;
	camFile = NULL;

	if(doWhat == 0) 
		camFile = fopen(filename, "rb");			
	else if(doWhat == 1)
		camFile = fopen(filename, "wb");
	else
		return;

	if(camFile == NULL) 
		return;

}

CameraRecord :: ~CameraRecord() {

	if(positionModel)
		delete [] positionModel;

	fclose(camFile);
	camFile = NULL;

}

void CameraRecord :: ResetFile() {

	rewind(camFile);

}

void CameraRecord :: RecordCamera() {

	fwrite(&pCameraManager->m_vPosition.x, 4, 1, camFile); 
	fwrite(&pCameraManager->m_vPosition.y, 4, 1, camFile);
	fwrite(&pCameraManager->m_vPosition.z, 4, 1, camFile);
	fwrite(&pCameraManager->m_vView.x, 4, 1, camFile);
	fwrite(&pCameraManager->m_vView.y, 4, 1, camFile);
	fwrite(&pCameraManager->m_vView.z, 4, 1, camFile);

}

CVector3* CameraRecord :: ReadOneCameraRecord() {

	static bool doneReading = false;

	if(point) {
		
		delete [] point;
		point = NULL;

	}

	point = new CVector3[2];

	point[0].x = 0.0f;
	point[0].y = 0.0f;
	point[0].z = 0.0f;
	point[1].x = 0.0f;
	point[1].y = 0.0f;
	point[1].z = 0.0f;	

	fread(&point[0].x, 4, 1, camFile);
	fread(&point[0].y, 4, 1, camFile); 
	fread(&point[0].z, 4, 1, camFile);
	fread(&point[1].x, 4, 1, camFile);
	fread(&point[1].y, 4, 1, camFile); 
	fread(&point[1].z, 4, 1, camFile);	

	return point;

}

CVector3* CameraRecord :: ReadEntireCameraRecord() {

	positionModel = new CVector3[50000];

	for(int i=0; i < 5000; i++) {

		positionModel[i].x = 0.0f;
		positionModel[i].y = 0.0f;
		positionModel[i].z = 0.0f;

	}
	
	for(i=0; i < 5000; i++) {

		fread(&positionModel[i].x, 4, 1, camFile);
	    fread(&positionModel[i].y, 4, 1, camFile); 
	    fread(&positionModel[i].z, 4, 1, camFile);		

	}
	
	return positionModel;

}

bool CameraRecord :: CreateCameraPath() {
	
	static float oldPoint[6];
	static float elapsedTime1   = 0.0f;
	static float lastTime1	  = 0.0f;
		
	float time1 = GetTickCount();	
	elapsedTime1 = time1 - lastTime1;	
	float t = elapsedTime1 / (1000.0f / 5.0f);	
	
    if(elapsedTime1 >= (1000.0f / 13.0f)) {
		
		CVector3* point = ReadOneCameraRecord();

		if(point[0].x != 0.0f && (point[0].y != 0.0f && (point[0].z != 0.0f))) {
			
			oldPoint[0] = point[0].x;
			oldPoint[1] = point[0].y;
			oldPoint[2] = point[0].z;
			oldPoint[3] = point[1].x;
			oldPoint[4] = point[1].y;
			oldPoint[5] = point[1].z;
			
		}
		else {
			return true;
		}
		
		point[0].x = oldPoint[0];
		point[0].y = oldPoint[1];
		point[0].z = oldPoint[2];
		point[1].x = oldPoint[3];
		point[1].y = oldPoint[4];
		point[1].z = oldPoint[5];

		pCameraManager->PositionCamera(point[0].x, point[0].y, point[0].z,
			point[1].x, point[1].y, point[1].z,
			pCameraManager->m_vUpVector.x, pCameraManager->m_vUpVector.y, pCameraManager->m_vUpVector.z);				

	}
	
	return false;
	
}






