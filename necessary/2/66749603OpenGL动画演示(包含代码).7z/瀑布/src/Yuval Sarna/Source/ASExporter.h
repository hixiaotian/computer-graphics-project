//***********************************************************************//
//		Author:		Yuval "Etus" Sarna		etus@actcom.net.il			 //
//																		 //
//		Program:		ASE files exporter Class						 //
//																		 //
//		Description:	Exports model files saved in ASE format(header file)	 //
//																		 //
//		Date:			04.12.02										 //
//																		 //
//      NOTE: PLEASE CHECK THE LICENSE FILE FOR PREMISSION REGARDING     // 
//      THIS FILE AND THE OTHERS!                                        // 
//***********************************************************************//

#ifndef _H_ASEX_
#define _H_ASEX_

#include "StdAfx.h"

class ASExporter : public FileExporters {

public:

	//---
	// Functions
	//---

	ASExporter() { return; } // The default constructor - will not work!
	ASExporter(TexturesExporter* pTexMan, char* filename); // The constructor
	~ASExporter(); // The destructor

	virtual void LoadFileInfo();
	Mesh LoadObject(); // Reads a mesh file - ment to be overriden	

	//---
	// Variables
	//---
		
	FileInfo FInfo;	

private:

	TexturesExporter* pTextureManager;	
	    
};

#endif