//***********************************************************************//
//		Author:		Yuval "Etus" Sarna		etus@actcom.net.il			 //
//																		 //
//		Program:		ASE files exporter Class						 //
//																		 //
//		Description:	Exports model files saved in ASE format(cpp file)	 //
//																		 //
//		Date:			04.12.02										 //
//																		 //
//      NOTE: PLEASE CHECK THE LICENSE FILE FOR PREMISSION REGARDING     // 
//      THIS FILE AND THE OTHERS!                                        // 
//***********************************************************************//

#include "StdAfx.h"

using namespace std;

ASExporter :: ASExporter(TexturesExporter* pTexMan, char* filename) : FileExporters(filename) {

	// Variable init
	pTextureManager = *(&pTexMan);
	
	// Load the file info
	LoadFileInfo();
    	
}

ASExporter :: ~ASExporter() {

    delete [] FInfo.Materials;
	
}

void ASExporter :: LoadFileInfo() {

    FILE *currFile = ReturnFilePointer(); // This is the current file that is open
	int objectCount = 0; // This will be used to count the number of objects
	int materialCount = 0; // This will be used to count the number of materials
	char seps[] = " \"\n";
	char* token = NULL;
	int i = 0; // This is used for loops
		
	ResetString();

	//////////////////////////////
	// Number of objects //
	//////////////////////////////

	while (!feof(currFile)) {
		
		if(ReadTo("*GEOMOBJECT") == true) {
			objectCount++;
		}		

	}

	FInfo.NumOfObjects = objectCount;

	ResetString();

	//////////////////////////////
	// Number of materials //
	//////////////////////////////

	if(ReadTo("*MATERIAL_COUNT") == true)
		fscanf(currFile, " %d", &materialCount);
	else
		materialCount = 0;

	FInfo.NumOfMaterials = materialCount;

	ResetString();

	//////////////////////////////
	// Material info //
	//////////////////////////////

	FInfo.Materials = new Material[materialCount];
	memset(FInfo.Materials, 0, sizeof(Material) * materialCount);

	if(FInfo.NumOfMaterials != 0) {
		for(i = 0; i < FInfo.NumOfMaterials; i++) {

			ResetString();
			ReadToLine("	*MATERIAL %d {\n", i);			
						
			while (!feof(currFile)) {

				fscanf(currFile, "%s", &string);
								
				if (!strcmp(string, "*MATERIAL")) {
					if(FInfo.Materials[i].TwoSidedMat != true)
						FInfo.Materials[i].TwoSidedMat = false;
					
					if(FInfo.Materials[i].bHasTexture != true)
						FInfo.Materials[i].bHasTexture = false;
					
					break;
				}
				else if (!strcmp(string, "*MATERIAL_REF")) {
					if(FInfo.Materials[i].TwoSidedMat != true)
						FInfo.Materials[i].TwoSidedMat = false;
					
					if(FInfo.Materials[i].bHasTexture != true)
						FInfo.Materials[i].bHasTexture = false;

					break;
				}
				else if(!strcmp(string, "*MATERIAL_DIFFUSE")) {
					fscanf(currFile, " %f %f %f", &FInfo.Materials[i].Diffuse[0], 
						                        &FInfo.Materials[i].Diffuse[1],
												&FInfo.Materials[i].Diffuse[2]);
				}
				else if(!strcmp(string, "*MATERIAL_TWOSIDED")) {					
					FInfo.Materials[i].TwoSidedMat = true;
				}
				else if(!strcmp(string, "*BITMAP")) {					
					fgets(string, 200, currFile);					

					token = strtok( string, seps );
					
                    while(token != NULL) {         
						strcpy(FInfo.Materials[i].TexFileName, token);                       
                        token = strtok( NULL, seps );
					}
					
					FInfo.Materials[i].TexFileName[strlen(FInfo.Materials[i].TexFileName)] = '\0';			
					FInfo.Materials[i].bHasTexture = true;
				}
				else if(!strcmp(string, "*UVW_U_TILING")) {
					fscanf(currFile, " %f", &FInfo.Materials[i].UTile);
				}
				else if(!strcmp(string, "*UVW_V_TILING")) {
					fscanf(currFile, " %f", &FInfo.Materials[i].VTile);					
				}
				else {
					ReadStr();
				}

			}

		}

	}

}

Mesh ASExporter :: LoadObject() {

	FILE *currFile = ReturnFilePointer(); // This is the current file that is open
	int NumOfObject = 1; // Counter for objects
	bool done = false; // Did we finish reading the file?
	int objectCount = 0; // This will be used in order to get the right object every time
	int VertexIndex = 0; // The index of the current vertex
	int TextureIndex = 0; // the index of the current texture
	int FaceIndex = 0; // The index of the current face
	int TFaceIndex = 0; // The index of the current texture face	
	int tempVerts = 0;
	int tempFaces = 0;
	int tempTexCoords = 0;
	int tempTexFaces = 0;
	char string2[255] = {NULL}; // Another string variable
	int i = 0; // This is used for loops	

	Mesh NewMesh(pTextureManager); // This is the mesh

	for(i=0; i < FInfo.NumOfObjects; i++) {

		tempVerts = 0;
	    tempFaces = 0;
	    tempTexCoords = 0;
	    tempTexFaces = 0;
		objectCount = 0;

		ResetString();
		
		//////////////////////////////
		// Object info //
		//////////////////////////////
		
		while (!feof(currFile)) {
			
			if(ReadTo("*GEOMOBJECT") == true) {
				objectCount++;

				if(objectCount == NumOfObject) {
					break;
				} 
			}	
			else {
				done = true;
			}			
			
		}

		if(done == true) {
			break;
		}

		while (!feof(currFile)) {
			
			fscanf(currFile, "%s", &string);
						
			if(!strcmp(string, "*MESH_NUMVERTEX")) {				
				fscanf(currFile, "%d", &tempVerts);
			}
			else if(!strcmp(string, "*MESH_NUMFACES")) {				
				fscanf(currFile, "%d", &tempFaces);
			}
			else if(!strcmp(string, "*MESH_NUMTVERTEX")) {				
				fscanf(currFile, "%d", &tempTexCoords);
			}
			else if(!strcmp(string, "*MESH_NUMTVFACES")) {				
				fscanf(currFile, "%d", &tempTexFaces);
			}
			else if(!strcmp(string, "*GEOMOBJECT")) {				
				break;
			}		
			else {
				ReadStr();
			}
		}

		ResetString();

		// It is now safe to create a new submesh for the mesh
		SubMesh NewSubMesh(pTextureManager, tempVerts, tempTexCoords, tempFaces, 
			tempTexFaces, FInfo.NumOfMaterials);

		objectCount = 0;
		while (!feof(currFile)) {
			
			if(ReadTo("*GEOMOBJECT") == true) {
				objectCount++;
			}	
			else {
				done = true;
			}

			if(objectCount == NumOfObject) {
				break;
			}
			
		}

		while (!feof(currFile)) {
			
			fscanf(currFile, "%s", &string);
			
			if(!strcmp(string, "*MESH_NUMVERTEX")) {
				fscanf(currFile, "%d", &NewSubMesh.MeshData.verts);
			}
			else if(!strcmp(string, "*MESH_NUMFACES")) {
				fscanf(currFile, "%d", &NewSubMesh.MeshData.faces);
			}
			else if(!strcmp(string, "*MESH_NUMTVERTEX")) {
				fscanf(currFile, "%d", &NewSubMesh.MeshData.NumOfTexCoords);
			}
			else if(!strcmp(string, "*MESH_NUMTVFACES")) {
				fscanf(currFile, "%d", &NewSubMesh.MeshData.NumOfTexFaces);
			}
			else if(!strcmp(string, "*GEOMOBJECT")) {
				break;
			}
			else {
				ReadStr();
			}
		}

		ResetString();
		
		objectCount = 0;
		
		while (!feof(currFile)) {
			
			if(ReadTo("*GEOMOBJECT") == true) {
				objectCount++;			
			}
			
			if(objectCount == NumOfObject) {
				break;
			}
			
		}	
		
		while (!feof(currFile)) {
			
			fscanf(currFile, "%s", &string);
			
			if(!strcmp(string, "*GEOMOBJECT")) {
				break;
			}	
			else if(!strcmp(string, "*MATERIAL_REF")) {
				fscanf(currFile, " %d", &NewSubMesh.MeshData.MaterialRef);
				
				if(FInfo.Materials[NewSubMesh.MeshData.MaterialRef].bHasTexture == true) {
					NewSubMesh.MeshData.bHasTexture = true;
				}
				else {
					NewSubMesh.MeshData.bHasTexture = false;
				}
			}
			else {
				ReadStr();
			}
		}
		
		ResetString();
		objectCount = 0;
		
		while (!feof(currFile)) {
			
			if(ReadTo("*GEOMOBJECT") == true) {
				objectCount++;
			}
			
			if(objectCount == NumOfObject) {
				break;
			}
			
		}	
		
		while (!feof(currFile)) {
			
			fscanf(currFile, "%s", &string);
			
			if(!strcmp(string, "*GEOMOBJECT")) {
				break;
			}
			else if(!strcmp(string, "*MESH_VERTEX")) {
				fscanf(currFile, "%d", &VertexIndex);
				
				fscanf(currFile, "%f %f %f", &NewSubMesh.MeshData.points[VertexIndex].x,
					&NewSubMesh.MeshData.points[VertexIndex].z,
					&NewSubMesh.MeshData.points[VertexIndex].y);
				
				NewSubMesh.MeshData.points[VertexIndex].z = -NewSubMesh.MeshData.points[VertexIndex].z;
				
			}
			else if(!strcmp(string, "*MESH_TVERT")) {
				fscanf(currFile, "%d", &TextureIndex);
				
				fscanf(currFile, "%f %f", &NewSubMesh.MeshData.points[TextureIndex].u, &NewSubMesh.MeshData.points[TextureIndex].v);
				NewSubMesh.MeshData.points[TextureIndex].u *= FInfo.Materials[NewSubMesh.MeshData.MaterialRef].UTile;
				NewSubMesh.MeshData.points[TextureIndex].v *= FInfo.Materials[NewSubMesh.MeshData.MaterialRef].VTile;			
			}
			else if(!strcmp(string, "*MESH_FACE")) {
				fscanf(currFile, "%d:", &FaceIndex);
				
				fscanf(currFile, "\tA:\t%d B:\t%d C:\t%d", &NewSubMesh.MeshData.the_faces[FaceIndex].x,
					&NewSubMesh.MeshData.the_faces[FaceIndex].y,
					&NewSubMesh.MeshData.the_faces[FaceIndex].z);

				while(!feof(currFile)) {
					fscanf(currFile, "%s", &string2);
					
					if(!strcmp(string2, "*MESH_FACE")) {
						break;
					}
					else if(!strcmp(string2, "*MESH_MTLID")) {
						fscanf(currFile, " %d", &NewSubMesh.MeshData.the_faces[FaceIndex].MatRef);
						break;
					}
				}				
								
			}	
			else if(!strcmp(string, "*MESH_TFACE")) {
				fscanf(currFile, "%d:", &TFaceIndex);
				
				fscanf(currFile, "%d %d %d", &NewSubMesh.MeshData.the_faces[TFaceIndex].tx,
					&NewSubMesh.MeshData.the_faces[TFaceIndex].ty,
					&NewSubMesh.MeshData.the_faces[TFaceIndex].tz);	
			}			
			else {
				ReadStr();
			}
		}

		NewSubMesh.FInfo = FInfo;

		NewSubMesh = CreateBoundingBox(NewSubMesh);		

		// Lets insert this submesh to the mesh
		NewMesh.SubMeshList.push_back(NewSubMesh);		
		
		NumOfObject++;

	}

	NewMesh.FInfo = FInfo;	

	NewMesh.currentAnim = 0;
	NewMesh.currentFrame = 0;
	NewMesh.numOfAnimations = 0;

	return NewMesh;

}

	


	
    






