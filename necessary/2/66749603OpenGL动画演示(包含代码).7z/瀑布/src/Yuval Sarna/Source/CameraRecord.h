//***********************************************************************//
//		Author:		Yuval "Etus" Sarna		etus@actcom.net.il			 //
//																		 //
//		Program:		Camera recording Class						         //
//																		 //
//		Description:	Record/Read the camera coords(header file)	 //
//																		 //
//		Date:			18.01.03										 //
//																		 //
//      NOTE: PLEASE CHECK THE LICENSE FILE FOR PREMISSION REGARDING     // 
//      THIS FILE AND THE OTHERS!                                        // 
//***********************************************************************//

#ifndef _H_CAMREC_
#define _H_CAMREC_

#include "StdAfx.h"

enum DoWhatToCamFile {
	FILE_READ,
    FILE_WRITE
};

class CameraRecord {

public:

	CameraRecord() { pCameraManager = NULL; } // The default constructor - will NOT work
	CameraRecord(CCamera* pCamMan, char* filename, int doWhat); // The constructor
	~CameraRecord(); // The destructor

	void ResetFile(); // Returns to the start of the file
	void RecordCamera(); // Records the current camera coords
	bool CreateCameraPath(); // Makes the camera move by the coords that were saved 
	CVector3* ReadEntireCameraRecord(); // Returns the camera coords from the given file
	CVector3* ReadOneCameraRecord(); // Returns one camera coord from the given file

private:

	CVector3* positionModel;
	CVector3* point;
	FILE *camFile;
	CCamera* pCameraManager;

};

#endif

