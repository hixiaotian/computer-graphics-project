#ifndef _CFMOD_H
#define _CFMOD_H

#include "fmod.h"

// This class allows you to initialize, load and play a MP3 or WAV sound
class CFmod {

public:

	// Typical constructor
	CFmod();

	// This will clean up memory and close the sound system
	~CFmod();

	// This inits your CFmod class MUST BE CALLED before any Fmod functions
	bool Init(char*);

	// This will play the current song stored in the m_pSound (Must be loaded first)
	void PlaySong();

	// This will free the memory stored in m_pSound (Song go bye bye)
	void FreeSound();

	// This will close the FMod Sound System
	void FreeSoundSystem();

	//////////////////// Data Access Functions //////////////////// 

	// This returns the pointer to our song module
	FSOUND_SAMPLE *GetSound() {	return m_pSound;			}

	// This will return a string of characters for the name of the song.
	// Some songs might not have the song information stored, so it
	// will be NULL.  
	char *GetSongName()	{ return FSOUND_Sample_GetName(m_pSound);	}

	// This will return a string of characters for the name of the file loaded
	char *GetFileName()	{ return m_strName;					}

private:

	// This holds the data for the current song loaded (Like a handle)
	FSOUND_SAMPLE *m_pSound;

	// This holds the name of the current song loaded
	char m_strName[255];

	// This holds the sound channel that is returned from FSOUND_PlaySound()
	// Since we pick any free channel, we need to know which one the sound was assigned.
	int m_soundChannel;

	// This will display a error message for whatever error may occur
	void DisplayError();

	// This takes a file name (a mp3 or wav file) and loads it into the m_pSound
	bool LoadSong(char *strName);
};


#endif