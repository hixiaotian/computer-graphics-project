//***********************************************************************//
//		Author:		Yuval "Etus" Sarna		etus@actcom.net.il			 //
//																		 //
//		Program:		Configuration Class       						 //
//																		 //
//		Description:	Loads a config file(header file)	             //
//														 	    		 //
//		Date:			10.01.03										 //
//																		 //
//      NOTE: PLEASE CHECK THE LICENSE FILE FOR PREMISSION REGARDING     // 
//      THIS FILE AND THE OTHERS!                                        // 
//***********************************************************************//

#ifndef _H_CONFIGFILE_
#define _H_CONFIGFILE_

#include "StdAfx.h"

class Configuration  : public FileHandling {
	
public:
	
	Configuration(); // The default constructor
	Configuration(char* filename); // The second constructor - allows you to specify your own 
	// config file
	~Configuration(); // The destructor
	
	// The following functions returns the values of the private variables
	int GetResolutionX();
	int GetResolutionY();
	int GetBits();	
	int GetTState();
	
	
private:
	
	//---
	// Functions
	//---
	
	void ParseFile();
	
	//---
	// Variables
	//---
	
	int resolutionX;
	int resolutionY;
	int bits;	 
	int tstate;
	
};

#endif