//***********************************************************************//
//		Author:		Yuval "Etus" Sarna		etus@actcom.net.il			 //
//																		 //
//		Program:		Configuration Class       						 //
//																		 //
//		Description:	Loads a config file(cpp file)	                 //
//														 	    		 //
//		Date:			10.01.03										 //
//																		 //
//      NOTE: PLEASE CHECK THE LICENSE FILE FOR PREMISSION REGARDING     // 
//      THIS FILE AND THE OTHERS!                                        // 
//***********************************************************************//

#include "StdAfx.h"

Configuration :: Configuration() : FileHandling("Config.dat") {

	// Variables init
	resolutionX = 0;
	resolutionY = 0;
	bits = 0;
	tstate = 0;
	FILE *currFile = ReturnFilePointer(); // This is the current file that is open

	ParseFile();

}

Configuration :: Configuration(char* filename) : FileHandling(filename) {

	// Variables init
	resolutionX = 0;
	resolutionY = 0;
	bits = 0;
	tstate = 0;

	ParseFile();

}

Configuration :: ~Configuration() {

	// Nothing here

}

void Configuration :: ParseFile() {

	FILE *currFile = ReturnFilePointer(); // This is the current file that is open

	// Load the file
	ResetString();

	while (!feof(currFile)) {
			
			fscanf(currFile, "%s", &string);
						
			if(!strcmp(string, "*RESOLUTION")) {				
				fscanf(currFile, " %d", &resolutionX);					
				fscanf(currFile, " %d", &resolutionY);
			}
			else if(!strcmp(string, "*SCREEND")) {				
				fscanf(currFile, " %d", &bits);
			}			
			else if(!strcmp(string, "*TSTATE")) {	
				fscanf(currFile, " %d", &tstate);				
			}			
			else {
				ReadStr();
			}
		}

	ResetString();

}

int Configuration :: GetResolutionX() {

	return resolutionX;

}

int Configuration :: GetResolutionY() {

	return resolutionY;

}

int Configuration :: GetBits() {

	return bits;

}

int Configuration :: GetTState() {

	return tstate;

}
