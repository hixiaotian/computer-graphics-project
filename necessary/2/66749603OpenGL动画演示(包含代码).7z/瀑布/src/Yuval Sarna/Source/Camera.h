#ifndef _MAIN_H
#define _MAIN_H

#include "math.h"

// This is our basic 3D point/vector class
class CVector3
{
public:
	
	// A default constructor
	CVector3() {}

	// This is our constructor that allows us to initialize our data upon creating an instance
	CVector3(float X, float Y, float Z) 
	{ 
		x = X; y = Y; z = Z;
	}

	// Here we overload the + operator so we can add vectors together 
	CVector3 operator+(CVector3 vVector)
	{
		// Return the added vectors result.
		return CVector3(vVector.x + x, vVector.y + y, vVector.z + z);
	}

	// Here we overload the - operator so we can subtract vectors 
	CVector3 operator-(CVector3 vVector)
	{
		// Return the subtracted vectors result
		return CVector3(x - vVector.x, y - vVector.y, z - vVector.z);
	}
	
	// Here we overload the * operator so we can multiply by scalars
	CVector3 operator*(float num)
	{
		// Return the scaled vector
		return CVector3(x * num, y * num, z * num);
	}

	// Here we overload the / operator so we can divide by a scalar
	CVector3 operator/(float num)
	{
		// Return the scale vector
		return CVector3(x / num, y / num, z / num);
	}

	CVector3 operator+(float f)
	{
		return CVector3(x+f, y+f, z+f);
	}
	float CVector3::length( void )
	{
		return( (float)sqrt( x * x + y * y + z * z ) );
	}
	void CVector3::normalize( void )
	{
		float fLength = length();
		
		x = x / fLength;
		y = y / fLength;
		z = z / fLength;

		return;
	}

	float x,y,z;

};

class CVector2
{
public:
	
	// A default constructor
	CVector2() {}

	// This is our constructor that allows us to initialize our data upon creating an instance
	CVector2(float X, float Y) 
	{ 
		x = X; y = Y;;
	}	

	float x,y;

};


// This is our camera class
class CCamera {

public:

	CVector3 m_vPosition;								// The camera's position
	CVector3 m_vView;									// The camera's View
	CVector3 m_vUpVector;								// The camera's UpVector
		
	// Our camera constructor - will NOT work
	CCamera() { return; }

	// Our camera constructor
	CCamera(int screenWidth, int screenHeight);	
	
	// This changes the position, view, and up vector of the camera.
	// This is primarily used for initialization
	void PositionCamera(float positionX, float positionY, float positionZ,
			 		    float viewX,     float viewY,     float viewZ,
						float upVectorX, float upVectorY, float upVectorZ);

	// This rotates the camera's view around the position using axis-angle rotation
	void RotateView(float angle, float X, float Y, float Z);

	void SetViewByMouse();


	void RotateAroundPoint(CVector3 vCenter, float angle, float x, float y, float z);

	// This will move the camera forward or backward depending on the speed
	void MoveCamera(float speed);

	void StrafeCamera(float speed);		

private:

	int SCREEN_WIDTH;						
    int SCREEN_HEIGHT;	
		
};

#endif