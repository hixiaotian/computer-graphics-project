#ifndef _STDINC_H_
#define _STDINC_H_

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <string>
#include <vector>

#include <GL\gl.h>
#include <GL\glu.h>

#include "Log.h"

#endif