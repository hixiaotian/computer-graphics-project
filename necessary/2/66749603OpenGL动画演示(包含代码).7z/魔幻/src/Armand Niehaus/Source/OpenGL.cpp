#include "OpenGL.h"

OpenGL::OpenGL()
{
    m_hDC = NULL;
    m_hRC = NULL;
    m_hAppWindowHandle = NULL;
}

OpenGL::~OpenGL()
{ 
    if ( (m_hDC) || (m_hRC) )
        Cleanup();
}

bool OpenGL::Initialize( HWND hWnd, int iWidth, int iHeight, 
                         int iDepth, bool bWindowed )
{
    m_dwDesiredWidth  = iWidth;
    m_dwDesiredHeight = iHeight;
    m_dwDesiredDepth  = iDepth;
    m_bWindowed       = bWindowed;

    m_hAppWindowHandle = hWnd;

    m_hDC = GetDC( m_hAppWindowHandle );

    if (!SetupPixelFormat( m_hDC ))
        return false;

    m_hRC = wglCreateContext( m_hDC );

    wglMakeCurrent( m_hDC, m_hRC );

	SizeViewport( 45.0f, m_dwDesiredWidth, m_dwDesiredHeight );

    if (!m_bWindowed)
    {
        // Set fullscreen
        ShowCursor( false );
        SetFullscreen( true );
    } 

    SetDefaults();

    return true;
}

bool OpenGL::Cleanup()
{
    if ( m_hRC )
    {
        if (!wglMakeCurrent( NULL, NULL ))
            return false;

        if (!wglDeleteContext( m_hRC ))
            return false;

        m_hRC = NULL;
	}
	
	if ( m_hDC )
    {
        if (!ReleaseDC( m_hAppWindowHandle, m_hDC ))
            return false;

        m_hDC = NULL;
    }

    if( !m_bWindowed )
    {
        SetFullscreen( false );
        ShowCursor( true );
    }

    return true;
}

bool OpenGL::SetFullscreen( bool bFlag )
{
    if (bFlag)
    {
        DEVMODE dmScreenSettings;
        memset( &dmScreenSettings, 0, sizeof(dmScreenSettings) );
        dmScreenSettings.dmSize       = sizeof( dmScreenSettings );
        dmScreenSettings.dmPelsWidth  = m_dwDesiredWidth;
        dmScreenSettings.dmPelsHeight = m_dwDesiredHeight;
        dmScreenSettings.dmBitsPerPel = m_dwDesiredDepth;
        dmScreenSettings.dmFields     = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
        ChangeDisplaySettings( &dmScreenSettings, CDS_FULLSCREEN );
        Log::Print( "OpenGL: Switched to fullscreen (%dx%d)", m_dwDesiredWidth, m_dwDesiredHeight );
    } else
    {
        ChangeDisplaySettings( NULL, 0 );
        Log::Print( "OpenGL: Switched to desktop" );
    }

    return true; 
}

bool OpenGL::SetupPixelFormat( HDC hdc )
{
    PIXELFORMATDESCRIPTOR pfd; 
    int pixelformat; 
 
    ZeroMemory( &pfd, sizeof(PIXELFORMATDESCRIPTOR) );

    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;

    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.dwLayerMask = PFD_MAIN_PLANE;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = m_dwDesiredDepth;
    pfd.cDepthBits = m_dwDesiredDepth;
    pfd.cAccumBits = 0;
    pfd.cStencilBits = 8;

    pixelformat = ChoosePixelFormat( hdc, &pfd );

    if (pixelformat == 0)
    {
        Log::Print( "OpenGL: Error choosing pixelformat" );
        return false; 
    }
 
    if (!SetPixelFormat( hdc, pixelformat, &pfd ))
    {
        Log::Print( "OpenGL: Error setting pixelformat" );
        return false; 
    }

    Log::Print( "OpenGL: Successfully set pixelformat" );

    return true;
}

bool OpenGL::SizeViewport( float fFOV, int iWidth, int iHeight )
{
    glViewport( 0, 0, iWidth, iHeight );

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();

    gluPerspective( fFOV, (float)iWidth/(float)iHeight, 1, 5000.0f );

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    return true;
}

bool OpenGL::SetFOV( float fAngle )
{
	return SizeViewport( fAngle, m_dwDesiredWidth, m_dwDesiredHeight );
}

void OpenGL::SetDefaults()
{
    // gouraud shading
	glShadeModel( GL_SMOOTH );

    // clear stuff
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	glClearDepth( 1.0f );

    // enable some stuff
	glEnable( GL_COLOR_MATERIAL );

    // z-buffer stuff
	glDepthFunc( GL_LEQUAL );
	glEnable( GL_DEPTH_TEST );

    // backface culling
    glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );

    glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );
}

//----------------------------------------------
//----------------------------------------------
// Utility functions
//----------------------------------------------
//----------------------------------------------
HDC OpenGL::RetrieveHDC()
{
    return m_hDC;
}
