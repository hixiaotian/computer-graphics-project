#ifndef _SIMPLEVECTOR_H_
#define _SIMPLEVECTOR_H_

class CVector3
{
    public:
        float x, y, z;

        inline void Set( float xx, float yy, float zz )
        { x=xx; y=yy; z=zz; };

        CVector3() {};
        CVector3( float x, float y, float z ) { Set( x, y, z ); }
};

#endif