#include "Texture.h"
#include "Image.h"

Texture::Texture()
{
    m_strTextureDir = "";

    m_iFilter = GL_LINEAR;
    m_bMips = false;
}

unsigned int Texture::UploadTexture( CImage* pImage )
{
    unsigned int iTexture=0;
    int uType;

    switch( pImage->m_dwDepth )
    {
        case 24: 
            uType = GL_RGB; 
            break;
        case 32:
            uType = GL_RGBA;
            break;
        default:
            return 0xffff;
    }

    glGenTextures( 1, &iTexture );
    glBindTexture( GL_TEXTURE_2D, iTexture );

    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );    

    if (m_bMips)
    {
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

        gluBuild2DMipmaps( GL_TEXTURE_2D, uType, pImage->m_dwWidth, pImage->m_dwHeight, 
                           uType, GL_UNSIGNED_BYTE, pImage->m_cData );
    } else
    {
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, m_iFilter );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, m_iFilter );
        glTexImage2D( GL_TEXTURE_2D, 0, uType, pImage->m_dwWidth, pImage->m_dwHeight,
                      0, uType, GL_UNSIGNED_BYTE, pImage->m_cData );
    }

    return iTexture;
}

unsigned int Texture::LoadTexture( std::string strFile )
{
    unsigned int iTexture;
    CImage* pImage;

    strFile = m_strTextureDir + strFile;

    pImage = new CImage();
    if (!pImage->LoadFromJPEG( strFile ))
        return 0xffff;

    iTexture = UploadTexture( pImage );

    delete pImage;

    Log::Print( "Texture loaded \"%s\"...", strFile.c_str() );

    return iTexture;
}

