#include "Credits.h"

CCreditsScene::CCreditsScene()
{
    m_fFades[ FADEIN ].m_bOn = true;
    m_fFades[ FADEIN ].m_fTime = 2.5f;
    m_fFades[ FADEIN ].m_fColorR = 0.0;
    m_fFades[ FADEIN ].m_fColorG = 0.0;
    m_fFades[ FADEIN ].m_fColorB = 0.0;

    m_fFades[ FADEOUT ].m_bOn = true; 
    m_fFades[ FADEOUT ].m_fTime = 7.0f;
    m_fFades[ FADEOUT ].m_fColorR = 0.0;
    m_fFades[ FADEOUT ].m_fColorG = 0.0;
    m_fFades[ FADEOUT ].m_fColorB = 0.0;

    m_fLength = 15.0f;
    SetSceneName( "Credits Scene" );
}

bool CCreditsScene::Initialize()
{
    Texture* tex = Texture::GetInstance();
   
    m_texText = tex->LoadTexture( "credits.jpg" );
    if (m_texText==0xffff)
        return false;
    
    /*m_pSprocket = new CObject();
    if (!m_pSprocket->LoadFrom3DS( "data\\sprocket.3ds" ))
        return false;*/

    m_pSphere = new CObject();
    if (!m_pSphere->LoadFrom3DS( "data\\sphere.3ds" ))
        return false;

    //*** create lights
    m_vLights.clear();
    CLight light2;
    light2.m_rgbAmbient.Set( 0.0, 0.0, 0.0 );
    light2.m_rgbDiffuse.Set( 1.0, 0.5, 0.5 );
    light2.m_vPosition.Set( 0, 0, 150 );
    light2.Create( GL_LIGHT1 );
    m_vLights.push_back( light2 );

    CLight light1;
    light1.m_rgbAmbient.Set( 0.0, 0.0, 0.0 );
    light1.m_rgbDiffuse.Set( 0.2, 0.2, 0.75 );
    light1.m_vPosition.Set( 0, 50, 50 );
    light1.Create( GL_LIGHT2 );
    m_vLights.push_back( light1 );

    return true;
}

bool CCreditsScene::Cleanup()
{
    /*if (m_pSprocket)
        delete m_pSprocket;*/

    if (m_pSphere)
        delete m_pSphere;

    return true;
}

bool CCreditsScene::Update()
{
    m_vLights[0].Create();
    m_vLights[1].Create();

    return true;
}

bool CCreditsScene::Render( int iScreenWidth, int iScreenHeight )
{
    OpenGL* ogl = OpenGL::GetInstance();
    ogl->SetFOV( 150.0f );
    gluLookAt( 0, 0, 0,
               0, 0, -10,
               0, 1, 0 );

    float fTime = Timer::GetTimer( TIMER_SINCEAPPSTART ) * 15.0f;

    glDisable( GL_DEPTH_TEST );

    glColor3f( 0.5, 0.5, 0.5 );
    glPushMatrix();
        glRotatef( fTime, 0, 1, 0 );
        glRotatef( fTime*1.4f, 1, 0, 0.33f );
        m_pSphere->Render();
    glPopMatrix();

    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_COLOR, GL_ONE );

    glColor3f( 1, 1, 1 );
    glPushMatrix();
        glRotatef( fTime, 0.4, 0, 1 );
        glRotatef( fTime*1.4f, 0, 1, 0.33f );
        m_pSphere->Render();
    glPopMatrix();

    glEnable( GL_DEPTH_TEST );

    ogl->SetFOV( 45.0f );
    gluLookAt( 0, 0, 50,
               0, 0, 0,
               0, 1, 0 );

    glColor3f( 1, 1, 1 );
    glEnable( GL_TEXTURE_2D );
    glBindTexture( GL_TEXTURE_2D, m_texText );

    glBegin( GL_QUADS );
        glTexCoord2f( 0, 0 ); glVertex3f( -10, 10, 0 );
        glTexCoord2f( 0, 1 ); glVertex3f( -10,-10, 0 );
        glTexCoord2f( 1, 1 ); glVertex3f(  10,-10, 0 );
        glTexCoord2f( 1, 0 ); glVertex3f(  10, 10, 0 );
    glEnd();

    glDisable( GL_BLEND );

    /*glEnable( GL_LIGHTING );
    glDisable( GL_COLOR_MATERIAL );

    glPushMatrix();
        glRotatef( y, 0, 1, 0 );
        m_pSprocket->Render();
    glPopMatrix();

    glDisable( GL_LIGHTING );
    glEnable( GL_COLOR_MATERIAL );*/

  
    return true;
}