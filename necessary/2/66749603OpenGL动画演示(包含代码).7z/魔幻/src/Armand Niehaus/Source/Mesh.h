#ifndef _MESH_H_
#define _MESH_H_

#include "Stdinc.h"

class CVertex
{
    public:
        float       x, y, z;
        float       nx, ny, nz;
        float       tu, tv;
};

class CMaterial
{
    public:
        std::string         m_strName;
    
        float               m_fUScale;
        float               m_fVScale;

        bool                m_bHasTexture;
        std::string         m_strTextureName;
        int                 m_iTextureID;
};

class CMesh
{
    public:
        std::string         m_strName;

        CVertex*            m_pVertices;
        int                 m_dwVertexCount;

        unsigned short*     m_pIndices;
        int                 m_dwIndexCount;

        std::string         m_strMaterialName; // for object loading
        CMaterial*          m_pMaterial;

        void CalculateNormals();
        void Render();

        CMesh();
        ~CMesh();
};

class CObject
{
    protected:
        std::vector<CMesh*> m_vMesh;
        std::vector<CMaterial*> m_vMaterials;

        bool ParseMeshesAndMaterials();

    public:

        bool LoadFrom3DS( std::string strFile );

        void AddMesh( CMesh* pMesh );
        void AddMaterial( CMaterial* pMat );

        virtual bool Render();

        CObject();
        ~CObject();
};

#endif