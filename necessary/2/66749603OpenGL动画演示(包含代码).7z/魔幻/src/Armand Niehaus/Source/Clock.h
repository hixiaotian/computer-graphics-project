#ifndef _TIMER_H_
#define _TIMER_H_

#include <stdio.h>
#include "Base.h"

enum TIMER_TYPE { TIMER_APPSTART, TIMER_SINCEAPPSTART, 
                  TIMER_SINCELASTFRAME, TIMER_ACTUAL };

class Timer
{
    private:

        static LARGE_INTEGER   m_llPerformanceFreq;
        static LARGE_INTEGER   m_llBeginTime;
        static LARGE_INTEGER   m_llLastTime;
        static LARGE_INTEGER   m_llCurTime;

        static float           m_fTimeScale;

        static float           m_fBeginTime;
        static float           m_fCurrentTime;
        static float           m_fSecSinceLastFrame;

        static float           m_fCounter;
        static float           m_fFPS, m_fTempFPS;
        static long            m_dwFrameCount;

    public:

        static float GetFPS();
        static float GetTimer( TIMER_TYPE enumType );
        static bool OncePerFrameQuery( HWND hWnd );

        static bool Initialize();

};

#endif
