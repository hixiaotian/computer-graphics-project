#include <windows.h>
#include "Sound.h"

Sound::Sound()
{
    m_bSongLoaded = false;
}

Sound::~Sound()
{
}

bool Sound::Initialize( int iFreq, bool bForce8Bit )
{
    if (BASSMOD_GetVersion() != MAKELONG( 1, 6 ))
    {
        Log::Print( "Sound: Wrong BASSMOD.DLL version!" );
        return false;
    }

    m_iFrequency = iFreq;
    m_bForce8Bit = bForce8Bit;

    long dwFlags = BASS_DEVICE_NOSYNC;
    if (bForce8Bit)
        dwFlags |= BASS_DEVICE_8BITS;

    if (!BASSMOD_Init( -1, iFreq, dwFlags ))
    {
        Log::Print( "Sound: Can't initialize BASSMOD...." );
        return false;
    }

    return true;
}

void Sound::Cleanup()
{
    BASSMOD_Free();
}

bool Sound::LoadSong( std::string strFile )
{
    BASSMOD_MusicFree();

    if (!BASSMOD_MusicLoad( false, (void*)strFile.c_str(), 0, 0, BASS_MUSIC_RAMPS ))
    {
        Log::Print( "Sound: Unable to load \"%s\" music file...", strFile.c_str() );
        return false;
    }

    m_bSongLoaded = true;

    return true;
}

bool Sound::Play()
{
    if (!m_bSongLoaded)
    {
        Log::Print( "Sound: No song loaded..."  );
        return false;
    }

    if (!BASSMOD_MusicPlay())
    {
        Log::Print( "Sound: Unable to play song..."  );
        return false;
    }

    return true;
}

bool Sound::Stop()
{
    if (m_bSongLoaded)
    {
        BASSMOD_MusicStop();
        return true;
    }
    return false;
}

bool Sound::SetInstSync( unsigned short sInst, SYNCPROC *proc )
{
    BASSMOD_MusicSetSync( BASS_SYNC_MUSICINST, MAKELONG( 6, -1 ), proc, 0 );
    return true;
}
