#ifndef _SOUND_H_
#define _SOUND_H_

#include "Stdinc.h"
#include "Singleton.h"
#include "Bass\Bassmod.h"

class Sound : public Singleton<Sound>
{
    private:
        
        int         m_iFrequency;
        bool        m_bForce8Bit;
        
        bool        m_bSongLoaded;

    public:

        bool Initialize( int iFreq, bool bForce8Bit );
        void Cleanup();

        bool SetInstSync( unsigned short sInst, SYNCPROC *proc );

        bool LoadSong( std::string strFile );

        bool Play();
        bool Stop();

        Sound();
        ~Sound();
};



#endif