#ifndef _CREDITS_H_
#define _CREDITS_H_

#include "Scene.h"
#include "Mesh.h" 
#include "Lights.h"

class CCreditsScene : public CScene
{
    private:
        unsigned int                m_texText; //:)
        CObject*                    m_pSprocket;
        CObject*                    m_pSphere;
        std::vector<CLight>         m_vLights;
        
    public:

        bool Initialize();
        bool Cleanup();
        bool Render( int iScreenWidth, int iScreenHeight );
        bool Update();

        CCreditsScene();
};

#endif