#include "intro_01.h"
#include "Math.h" 

//***************************************
//  CIntroScene: The Noise Stuff
//***************************************
CIntroScene::CIntroScene()
{
    m_fFades[ FADEIN ].m_bOn = true;
    m_fFades[ FADEIN ].m_fTime = 5.0f;
    m_fFades[ FADEIN ].m_fColorR = 0.0;
    m_fFades[ FADEIN ].m_fColorG = 0.0;
    m_fFades[ FADEIN ].m_fColorB = 0.0;

    m_fFades[ FADEOUT ].m_bOn = true; 
    m_fFades[ FADEOUT ].m_fTime = 5.0f;
    m_fFades[ FADEOUT ].m_fColorR = 1.0;
    m_fFades[ FADEOUT ].m_fColorG = 1.0;
    m_fFades[ FADEOUT ].m_fColorB = 1.0;

    m_fLength = 8.0f;
    SetSceneName( "The Noise Stuff" );
}

bool CIntroScene::Initialize()
{
    m_pNoise = new CImage();
    if (!m_pNoise)
        return false;

    m_pNoise->m_cData = new unsigned char[ 256 * 256 * 3 ];
    if (!m_pNoise->m_cData)
        return false;

    m_pNoise->m_dwWidth = 256;
    m_pNoise->m_dwHeight = 256;
    m_pNoise->m_dwDepth = 24;

    Texture* tex = Texture::GetInstance();
    m_iNoiseTex = tex->UploadTexture( m_pNoise );
    
    glEnable( GL_TEXTURE_2D );

    return true;
}

bool CIntroScene::Cleanup()
{
    if (m_pNoise)
        delete m_pNoise;

    return true;
}

bool CIntroScene::Render( int iScreenWidth, int iScreenHeight )
{
    glMatrixMode( GL_PROJECTION );
    glPushMatrix();
        glLoadIdentity();
        glOrtho( 0, iScreenWidth, iScreenHeight, 0, -1, 1 );

    glMatrixMode( GL_MODELVIEW );
    glPushMatrix();
        glLoadIdentity();

    glEnable( GL_TEXTURE_2D );
    glBindTexture( GL_TEXTURE_2D, m_iNoiseTex );

    glColor3f( 1, 1, 1 );

    glBegin( GL_QUADS );
        glTexCoord2f( 1, 0 ); glVertex3f( iScreenWidth,             0, 0 );
        glTexCoord2f( 0, 0 ); glVertex3f(            0,             0, 0 );
        glTexCoord2f( 0, 1 ); glVertex3f(            0, iScreenHeight, 0 );
        glTexCoord2f( 1, 1 ); glVertex3f( iScreenWidth, iScreenHeight, 0 );
    glEnd();

    glMatrixMode( GL_PROJECTION );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
    glPopMatrix();
    return true;
}

bool CIntroScene::Update()
{
    long idx = 0;
    unsigned char* pData = m_pNoise->m_cData;
    for( long y=0; y<65536; y++ )
    {
        m_uRandom += rand()%0xff;
        pData[0] = m_uRandom;
        pData[1] = m_uRandom;
        pData[2] = m_uRandom;
        pData+=3;
    }

    glBindTexture( GL_TEXTURE_2D, m_iNoiseTex );
    glTexSubImage2D( GL_TEXTURE_2D, 0, 0, 0, 256, 256, 
                     GL_RGB, GL_UNSIGNED_BYTE, m_pNoise->m_cData );

    return true;
}