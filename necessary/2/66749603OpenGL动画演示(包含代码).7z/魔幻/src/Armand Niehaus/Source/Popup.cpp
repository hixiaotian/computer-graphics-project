#include <windows.h>
#include "Popup.h"

CPopup::CPopup()
{
}

CPopup::~CPopup()
{
}

LRESULT CALLBACK DlgPasswordProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	char szPassword[25]={0};								// This will be used to hold the text they user types in.

    switch( message )										// Switch on all of the dialogs messages
    {
		case WM_INITDIALOG:									// If Initilizing the dialog box		

			// Do initialization here	(like WM_CREATE)

            return TRUE;

		case WM_COMMAND:									// If we clicked on anything in the dialog box
            
			switch( LOWORD( wParam ) )						// Check the LOWORD of the wParam (Which holds the ID of what was clicked on)
            {    
				case IDOK:									// Check if the OK button was clicked																			                    
															// This gets what the user typed into the password field.
															// It takes the hWnd, the ID of the dialog box control, a string to hold what they typed in,
															// and how many characters you want to retrieve from the field.
					GetDlgItemText(hWnd, IDC_PASSWORD, szPassword, 25);
															
															// Check if they typed in the right password
					if(!strcmp(szPassword, "GameTutorials") || !strcmp(szPassword, "gametutorials"))
					{						
						gCorrectPassword = true;			// Set the global flag to true
						EndDialog( hWnd, FALSE );			// Close the dialog box	
					}
					else 
					{										// Display a message box that tells the user they entered the incorrect password
						MessageBox(hWnd, "Incorrect password! (""GameTutorials"")", "Error!", MB_OK);
					}										// MessageBox takes (the window handle, the string of text, the title, and extra flags - Look in msdn).

					return TRUE;							// Return from the dialog proc

				case IDCANCEL:								// Check if the cancel button was pressed
															// Display a message box saying we clicked cancel.  (MB_OK stands for message box with a OK button)
					MessageBox(hWnd, "You must enter the correct password! (""GameTutorials"")", "Error!", MB_OK);
					EndDialog( hWnd, FALSE );				// Close the dialog box

					return TRUE;							// Quit from this function
            }
            break;

        case WM_CLOSE:										// If we close the dialog box

			EndDialog( hWnd, FALSE );						// Close the dialog box
            
			break;

		case WM_DESTROY:									// This message happens when the dialog box closes          
        
			// If we need to free anything, do it here

			break;											// Break from the loop
    }

    return FALSE;											// Return a default false
}

CParameters CPopup::Run( HINSTANCE hInstance )
{
    DialogBox( hInstance, MAKEINTRESOURCE(IDD_DIAG_MAIN), NULL, (DLGPROC)DlgPasswordProc );
}
