#ifndef _HARMONICS_H_
#define _HARMONICS_H_

#include "Stdinc.h"
#include "Scene.h"
#include "SimpleVector.h"

class CCresentScene : public CScene
{
    private:
        float               m_fMult;
        unsigned int        m_texCloud;

        CVector3 CresentIt( float u, float v );
        void RenderCresent();

    public:

        bool Initialize();
        bool Cleanup();
        bool Render( int iScreenWidth, int iScreenHeight );
        bool Update();

        CCresentScene();
};

#endif