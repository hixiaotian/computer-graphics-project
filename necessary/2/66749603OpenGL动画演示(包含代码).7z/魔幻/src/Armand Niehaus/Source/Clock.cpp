#include "Clock.h"

//-------------------------------------------------------
//  Static variables
//-------------------------------------------------------
LARGE_INTEGER   Timer::m_llPerformanceFreq;
LARGE_INTEGER   Timer::m_llBeginTime;
LARGE_INTEGER   Timer::m_llLastTime;
LARGE_INTEGER   Timer::m_llCurTime;

float           Timer::m_fTimeScale;

float           Timer::m_fBeginTime;
float           Timer::m_fCurrentTime;
float           Timer::m_fSecSinceLastFrame;

float           Timer::m_fCounter;
float           Timer::m_fFPS, Timer::m_fTempFPS;
long            Timer::m_dwFrameCount;

//-------------------------------------------------------
//  Initialize()
//-------------------------------------------------------
//      Checks performance counter for it's
//      frequency (if it exists) and resets the 
//      counters.
//
bool Timer::Initialize()
{
    if ( QueryPerformanceFrequency( &m_llPerformanceFreq ) )
    {
        QueryPerformanceCounter( &m_llBeginTime );
        m_llLastTime.QuadPart = m_llBeginTime.QuadPart;
        m_llCurTime.QuadPart = m_llBeginTime.QuadPart;
        m_fTimeScale = 1.0f / m_llPerformanceFreq.QuadPart;

        m_fBeginTime          = m_llBeginTime.QuadPart * m_fTimeScale;
        m_fCurrentTime        = m_llBeginTime.QuadPart * m_fTimeScale;
        m_fSecSinceLastFrame  = 0.0f;
        m_fCounter            = 0.0f;
        m_fFPS                = 0.0f;
        m_fTempFPS            = 0.0f;
        m_dwFrameCount        = 0;

        return true;
    }

    return false;
}

//-------------------------------------------------------
//  GetTimer()
//-------------------------------------------------------
//      Retrieves one of the four timer values.
//
//      TIMER_APPSTART
//          Returns the time when the app started.
//
//      TIMER_SINCEAPPSTART
//          Returns the time elapsed since the 
//          app started. 
//
//      TIMER_SINCELASTFRAME
//          Returns the time it took the to render
//          the last frame.
//
//      TIMER_ACTUAL
//          Returns the *actual* time at the moment
//          GetTimer() is called.
//
float Timer::GetTimer( TIMER_TYPE enumType )
{
    LARGE_INTEGER ct;
    switch( enumType )
    {
        case TIMER_APPSTART:
            return m_fBeginTime;
        case TIMER_SINCEAPPSTART:
            return m_fCurrentTime;
        case TIMER_SINCELASTFRAME:
            return m_fSecSinceLastFrame;
        case TIMER_ACTUAL:
            QueryPerformanceCounter( &ct );
            return ( (ct.QuadPart-m_llBeginTime.QuadPart) * m_fTimeScale );
    }
    return -1.0f;
}

//-------------------------------------------------------
//  OncePerFrameQuery()
//-------------------------------------------------------
//      Called once per frame to get the current
//      time and calculate the fps and other things
//      from that.
//
bool Timer::OncePerFrameQuery( HWND hWnd )
{
    m_llLastTime = m_llCurTime;

    if (!QueryPerformanceCounter( &m_llCurTime ))
        return false;

    m_fCurrentTime       = (float)( (m_llCurTime.QuadPart-m_llBeginTime.QuadPart) * m_fTimeScale );
    m_fSecSinceLastFrame = (float)( (m_llCurTime.QuadPart-m_llLastTime.QuadPart) * m_fTimeScale );
    m_fFPS = 1.0f / m_fSecSinceLastFrame;

    m_dwFrameCount++;

    m_fCounter += m_fSecSinceLastFrame;
    if ( m_fCounter>= 1.0f )
    {
        char ss[128];
        sprintf( ss, "The Hollow   %1.2f fps   running %1.2f seconds", m_fFPS, m_fCurrentTime );
        SetWindowText( hWnd, ss );
        m_fCounter = 0.0f;
    }

    return true;
}

//-------------------------------------------------------
//  OncePerFrameQuery()
//-------------------------------------------------------
//      Returns the current frames per second.
//
float Timer::GetFPS()
{
    return m_fFPS;
}
