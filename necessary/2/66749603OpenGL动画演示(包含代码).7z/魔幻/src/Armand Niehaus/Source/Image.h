#ifndef _IMAGE_H_
#define _IMAGE_H_

#include "Stdinc.h"

class CImage
{
    public:

        unsigned char*  m_cData;

        int             m_dwWidth;
        int             m_dwHeight;
        int             m_dwDepth;

        bool LoadFromJPEG( std::string strFilename );

        CImage();
        ~CImage();
};

#endif