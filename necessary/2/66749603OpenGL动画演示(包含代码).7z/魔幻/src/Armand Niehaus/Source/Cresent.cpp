#include <math.h>
#include "Cresent.h"

#define PI  3.141592f

CCresentScene::CCresentScene()
{
    m_fFades[ FADEIN ].m_bOn = true;
    m_fFades[ FADEIN ].m_fTime = 1.5f;
    m_fFades[ FADEIN ].m_fColorR = 0.0;
    m_fFades[ FADEIN ].m_fColorG = 0.0;
    m_fFades[ FADEIN ].m_fColorB = 0.0;

    m_fFades[ FADEOUT ].m_bOn = true; 
    m_fFades[ FADEOUT ].m_fTime = 3.5f;
    m_fFades[ FADEOUT ].m_fColorR = 0.0;
    m_fFades[ FADEOUT ].m_fColorG = 0.0;
    m_fFades[ FADEOUT ].m_fColorB = 0.0;

    m_fLength = 5.0f;
    SetSceneName( "Cresent" );
}

bool CCresentScene::Initialize()
{
    Texture* tex = Texture::GetInstance();

    m_texCloud = tex->LoadTexture( "flow.jpg" );
    if (m_texCloud==0xffff)
        return false;

    m_fMult = 0;

    return true;
}

bool CCresentScene::Cleanup()
{
    return true;
}

bool CCresentScene::Render( int iScreenWidth, int iScreenHeight )
{
    OpenGL* ogl = OpenGL::GetInstance();
    ogl->SetFOV( 20.0f );

    gluLookAt( 0, 0, 12, 
               0, 0, -20,
               0, 1, 0 );

    glPushMatrix();
        glRotatef( -90, 0, 0, 1 );
        glColor3f( 0.5f + (0.5f * cos(m_fMult/2.0f)), 0.75, 0.5f + (0.5f * sin(m_fMult/1.75f)) );
        RenderCresent();
    glPopMatrix();

    ogl->SetFOV( 45.0f );
    return true;
}

bool CCresentScene::Update()
{
    m_fMult += 1.0f * Timer::GetTimer( TIMER_SINCELASTFRAME );
    return true;
}

CVector3 CCresentScene::CresentIt( float u, float v )
{
    CVector3 vec;
    float fSin2PiV = sin(2*PI*v)*(1+(cos( (v*18)+m_fMult )/2.0f));
    float fSin2PiU = sin(2*PI*u);

    vec.x = ( 2+fSin2PiU * fSin2PiV ) * sin(3*PI*v);
    vec.y = ( 2+fSin2PiU * fSin2PiV ) * cos(3*PI*v);
    vec.z = cos(2*PI*u) * fSin2PiV + 4*v;

    return vec;
}

void CCresentScene::RenderCresent()
{
    float fDeltaU = 0.10;
    float fDeltaV = 0.03;
    CVector3 v1, v2, v3, v4;

    glEnable( GL_TEXTURE_2D );
    glBindTexture( GL_TEXTURE_2D, m_texCloud );

    glMatrixMode( GL_TEXTURE );
    glPushMatrix();
    glScalef( 0.5, 0.5, 0.5 );
    glMatrixMode( GL_MODELVIEW );

    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_COLOR, GL_ONE );

    glBegin( GL_QUADS );
    for( float u=0.0f; u<1.0f; u+=fDeltaU )
    {
        for( float v=-1.0f; v<1.0f; v+=fDeltaV )
        {
            v1 = CresentIt( u + fDeltaU, v );
            v2 = CresentIt(           u, v );
            v3 = CresentIt(           u, v + fDeltaV );
            v4 = CresentIt( u + fDeltaU, v + fDeltaV );

            glTexCoord2f( v1.z, v1.y ); glVertex3f( v1.x, v1.y, v1.z );
            glTexCoord2f( v2.z, v2.y ); glVertex3f( v2.x, v2.y, v2.z );
            glTexCoord2f( v3.z, v3.y ); glVertex3f( v3.x, v3.y, v3.z );
            glTexCoord2f( v4.z, v4.y ); glVertex3f( v4.x, v4.y, v4.z );
        }
    }
    glEnd();

    glDisable( GL_BLEND );

    glMatrixMode( GL_TEXTURE );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
}