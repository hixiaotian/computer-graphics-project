#include <math.h>
#include "intro_02.h" 

//***************************************
//  CMyObject
//***************************************
bool CMyObject::Render()
{
    glColor3f( 1, 1, 1 );

    glEnable( GL_TEXTURE_2D );
    glBindTexture( GL_TEXTURE_2D, m_texEnv );

    for( int iMesh=0; iMesh<m_vMesh.size(); iMesh++ )
    {
        CMesh* pMesh = m_vMesh[ iMesh ];

        glBegin( GL_TRIANGLES );
        for( int i=0; i<pMesh->m_dwIndexCount/3; i++ )
        {
            CVertex v1 = pMesh->m_pVertices[ pMesh->m_pIndices[i*3+0] ];
            CVertex v2 = pMesh->m_pVertices[ pMesh->m_pIndices[i*3+1] ];
            CVertex v3 = pMesh->m_pVertices[ pMesh->m_pIndices[i*3+2] ];

            glNormal3f( v1.nx, v1.ny, v1.nz );
            glTexCoord2f( v1.tu, v1.tv ); 
            glVertex3f( v1.x, v1.y, v1.z );

            glNormal3f( v2.nx, v2.ny, v2.nz );
            glTexCoord2f( v2.tu, v2.tv );
            glVertex3f( v2.x, v2.y, v2.z );

            glNormal3f( v3.nx, v3.ny, v3.nz );
            glTexCoord2f( v3.tu, v3.tv ); 
            glVertex3f( v3.x, v3.y, v3.z );
        }
        glEnd();
    }

    return true;
}

//***************************************
//  CIntroScene2: Fish-Eyed-Title-Thingy
//***************************************
CIntroScene2::CIntroScene2()
{
    m_fFades[ FADEIN ].m_bOn = true;
    m_fFades[ FADEIN ].m_fTime = 2.5f;
    m_fFades[ FADEIN ].m_fColorR = 1.0;
    m_fFades[ FADEIN ].m_fColorG = 1.0;
    m_fFades[ FADEIN ].m_fColorB = 1.0;

    m_fFades[ FADEOUT ].m_bOn = true; 
    m_fFades[ FADEOUT ].m_fTime = 15.0f;
    m_fFades[ FADEOUT ].m_fColorR = 0.0;
    m_fFades[ FADEOUT ].m_fColorG = 0.0;
    m_fFades[ FADEOUT ].m_fColorB = 0.0;

    m_fLength = 18.0f;
    SetSceneName( "Fish-Eyed-Title-Thingy" );
}

bool CIntroScene2::Initialize()
{
    Texture* tex = Texture::GetInstance();

    tex->SetMipMaps( true );
    m_texCloud = tex->LoadTexture( "cloud.jpg" );
    if (m_texCloud==0xffff)
        return false;
    tex->SetMipMaps( false );

    m_pTitle = new CMyObject();
    if (!m_pTitle->LoadFrom3DS( "data\\mytitle.3ds" ))
        return false;

    unsigned int iTemp = tex->LoadTexture( "reflection.jpg" );
    if (iTemp==0xffff)
        return false;
    m_pTitle->SetTexture( iTemp );

    m_listCurve = glGenLists( 1 );

    float f = 2.1f;
    float max = f * sqrtf( (11*11) + (11*11) );
    float fZ;

    glNewList( m_listCurve, GL_COMPILE );
    glBegin( GL_QUADS );

    for( int y=-11; y<11; y++ )
        for( int x=-11; x<11; x++ )
        {
            float fX = x*f;
            float fY = y*f;

            fZ = f * sqrtf( (fX*fX) + (fY*fY) );
            fZ = -20 * cos( fZ / max );
            glTexCoord2f( ((float)(x+11)/22.0f), ((float)(y+11)/22.0f) );
            glVertex3f( fX, fY, fZ );

            fX = x*f + f;
            fY = y*f;
            fZ = f * sqrtf( (fX*fX) + (fY*fY) );
            fZ = -20 * cos( fZ / max );
            glTexCoord2f( ((float)(x+11)/22.0f) + (1.0f/22.0f), ((float)(y+11)/22.0f) );
            glVertex3f( fX, fY, fZ );

            fX = x*f + f;
            fY = y*f + f;
            fZ = f * sqrtf( (fX*fX) + (fY*fY) );
            fZ = -20 * cos( fZ / max );
            glTexCoord2f( ((float)(x+11)/22.0f) + (1.0f/22.0f), ((float)(y+11)/22.0f)  + (1.0f/22.0f) );
            glVertex3f( fX, fY, fZ );

            fX = x*f;
            fY = y*f + f;
            fZ = f * sqrtf( (fX*fX) + (fY*fY) );
            fZ = -20 * cos( fZ / max );
            glTexCoord2f( ((float)(x+11)/22.0f), ((float)(y+11)/22.0f)  + (1.0f/22.0f));
            glVertex3f( fX, fY, fZ );
        }

    glEnd();
    glEndList();

    m_fBackgroundRotate = 0;
    m_fLayer1Par = 0;
    m_fLayer2Par = 0;

    glTexGenf( GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP );
    glTexGenf( GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP );

    return true;
}

bool CIntroScene2::Cleanup()
{
    glDeleteLists( m_listCurve, 1 );

    if (m_pTitle)
        delete m_pTitle;

    return true;
}

bool CIntroScene2::Render( int iScreenWidth, int iScreenHeight )
{
    // set the fov extremely high
    OpenGL* ogl = OpenGL::GetInstance();
    ogl->SetFOV( 160.0f );

    gluLookAt( 0, 0, 0,
               0, 0, -1,
               0, 1, 0 );

    glDisable( GL_DEPTH_TEST );

    glEnable( GL_TEXTURE_2D );
    glBindTexture( GL_TEXTURE_2D, m_texCloud );

    // semi-static background
    glPushMatrix();
    glRotatef( m_fBackgroundRotate, 0, 0, 1 );
    glColor3f( 1, 0.5, 0 );
    glCallList( m_listCurve );
    glPopMatrix();

    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_COLOR, GL_ONE );

    // layer 1
    ScaleTextureMatrix( 1.5f + cos(m_fLayer1Par), 1.5f + sin(m_fLayer1Par*1.5), 0 );
    glTranslatef( 0, 0, 3 );
    glColor3f( 0.5, 0, 1 );
    glCallList( m_listCurve );
    RestoreTextureMatrix();

    // layer 2
    ScaleTextureMatrix( 1, 1.5f + cos(m_fLayer2Par), 1.5f + sin(m_fLayer2Par*1.5) );
    glPushMatrix();
    glTranslatef( 0, 0, 3 );
    glColor3f( 1, 1, 1 );
    glCallList( m_listCurve );
    RestoreTextureMatrix();

    // disable blend
    glDisable( GL_BLEND );
    glEnable( GL_DEPTH_TEST );

    // restore field-of-view
    ogl->SetFOV( 45.0f );

    gluLookAt( 0, 0, 5,
               0, 0, 0,
               0, 1, 0 );

    glEnable( GL_TEXTURE_GEN_S );
    glEnable( GL_TEXTURE_GEN_T );

    ScaleTextureMatrix( (1.5f + cos(m_fLayer1Par)) / 5.0f, (1.5f + sin(m_fLayer2Par*1.5)) / 5.0f, 0 );
    glPushMatrix();
    glScalef( 0.05, 0.05, 0.05 );
    m_pTitle->Render();
    glPopMatrix();
    RestoreTextureMatrix();

    glDisable( GL_TEXTURE_GEN_S );
    glDisable( GL_TEXTURE_GEN_T );

    return true;
}

bool CIntroScene2::Update()
{
    float fTime = Timer::GetTimer( TIMER_SINCELASTFRAME );

    m_fBackgroundRotate += 10 * fTime;
    m_fLayer1Par += 0.33f * fTime;
    m_fLayer2Par += 0.43f * fTime;

    return true;
}

void CIntroScene2::ScaleTextureMatrix( float x, float y, float z )
{
    glMatrixMode( GL_TEXTURE );
    glPushMatrix();
    glScalef( x, y, z );
    glMatrixMode( GL_MODELVIEW );
    glPushMatrix();
}

void CIntroScene2::RestoreTextureMatrix()
{
    glPopMatrix();
    glMatrixMode( GL_TEXTURE );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
}
