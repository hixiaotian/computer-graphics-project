#include <math.h>
#include "Scene.h"

//********************************
//  CScene
//********************************
CScene::CScene()
{
    m_strSceneName = "Unnamed Scene";
    m_bRunning     = false;

    m_fLength      = 0.0f;

    m_fFades[ FADEIN ].m_bOn    = false;
    m_fFades[ FADEIN ].m_fTime  = 0;
    m_fFades[ FADEOUT ].m_bOn   = false;
    m_fFades[ FADEOUT ].m_fTime = 0;
}

CScene::~CScene()
{
}

//********************************
//  SceneManager
//********************************
SceneManager::SceneManager()
{
    m_vScenes.clear();
    m_vPlaylist.clear();

    m_bRunning = false;
}

SceneManager::~SceneManager()
{
    ClearScenes();
}

void SceneManager::SetResolution( int iWidth, int iHeight )
{
    m_iWindowWidth  = iWidth;
    m_iWindowHeight = iHeight;
}

bool SceneManager::AddScene( CScene* pScene )
{
    if (pScene)
    {
        m_vScenes.push_back( pScene );
        pScene->m_iVectorTag = m_vScenes.size() - 1;
        pScene->m_iQuality = m_iQuality;
        return true;
    }
    return false;
}

bool SceneManager::ClearScenes()
{
    for( int i=0; i<m_vScenes.size(); i++ )
        if (m_vScenes[i])
            delete m_vScenes[i];
    m_vScenes.clear();
    return true;
}

bool SceneManager::InitializeScenes()
{
    for( int i=0; i<m_vScenes.size(); i++ )
        if (m_vScenes[i])
            if (!m_vScenes[i]->Initialize())
                return false;

    return true;
}

bool SceneManager::CleanupScenes()
{
    for( int i=0; i<m_vScenes.size(); i++ )
        if (m_vScenes[i])
            if (!m_vScenes[i]->Cleanup())
                return false;
    return true;
}

bool SceneManager::Start( bool bLoop )
{
    if (m_bRunning)
        return false;

    m_iCurrentScene = 0;
    m_fStartTime    = Timer::GetTimer( TIMER_SINCEAPPSTART );
    m_fSceneStart   = m_fStartTime;
    m_bLoop         = bLoop;

    m_bRunning = true;

    return true;
}

bool SceneManager::Stop()
{
    if (!m_bRunning)
        return false;

    m_iCurrentScene = 0;
    m_bRunning      = false;

    return true;
}

bool SceneManager::UpdateAndRender()
{
    if (!m_bRunning)
        return true; // return no error

    CScene* pScene = m_vScenes[ m_iCurrentScene ];
    if (pScene)
    {
        float fTime = Timer::GetTimer( TIMER_SINCEAPPSTART );
        float fRunTime = fTime - m_fSceneStart;

        // see if we need to start the next frame
        if ( fRunTime >= pScene->m_fLength )
        {
            m_iCurrentScene++;

            // check if there's a next scene
            if (m_iCurrentScene==m_vScenes.size())
            {
                Stop();

                // if we're loopin'...... restart
                if (m_bLoop)
                {
                    Start( true );
                    return true;
                } else
                    return false;
            }

            m_fSceneStart = fTime;
        }

        // update and render the current scene
        pScene->SetRunningTime( fRunTime );
        pScene->Update();                                  // for some reason i'd like to
        pScene->Render( m_iWindowWidth, m_iWindowHeight ); // keep updating and rendering seperate

        HandleFades( pScene, fRunTime );

    }
    return true;
}

void SceneManager::HandleFades( CScene *pScene, float fRunTime )
{
    float fAlpha;
    float fR, fG, fB;
    int iFade;

    if ( !pScene->m_fFades[FADEIN].m_bOn && !pScene->m_fFades[FADEOUT].m_bOn )
        return; // no fade needed

    if ( pScene->m_fFades[FADEIN].m_bOn &&
         (fRunTime < pScene->m_fFades[FADEIN].m_fTime) )
        {
            iFade = FADEIN;
        }

    if ( pScene->m_fFades[FADEOUT].m_bOn &&
         (fRunTime > pScene->m_fFades[FADEOUT].m_fTime) )
        {
            iFade = FADEOUT;
        }

    switch( iFade )
    {
        case FADEIN:
            fAlpha = 1.0f - (1.0f / (pScene->m_fFades[FADEIN].m_fTime / fRunTime));
            fR = pScene->m_fFades[ FADEIN ].m_fColorR;
            fG = pScene->m_fFades[ FADEIN ].m_fColorG;
            fB = pScene->m_fFades[ FADEIN ].m_fColorB;
            break;

        case FADEOUT:
            fAlpha = 1.0f / ((pScene->m_fLength - pScene->m_fFades[FADEOUT].m_fTime) / (fRunTime - pScene->m_fFades[FADEOUT].m_fTime));
            fR = pScene->m_fFades[ FADEOUT ].m_fColorR;
            fG = pScene->m_fFades[ FADEOUT ].m_fColorG;
            fB = pScene->m_fFades[ FADEOUT ].m_fColorB;
            break;
            
        default:
            return;
    }

    // go into ortho mode and draw a quad filling
    // the screen at the calculated alpha value
    glMatrixMode( GL_PROJECTION );
    glPushMatrix();
        glLoadIdentity();
        glOrtho( 0, m_iWindowWidth, m_iWindowHeight, 0, -1, 1 );

    glMatrixMode( GL_MODELVIEW );
    glPushMatrix();
        glLoadIdentity();

    glDisable( GL_TEXTURE_2D );
    glDisable( GL_DEPTH_TEST );
    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

    glColor4f( fR, fG, fB, fAlpha );

    glBegin( GL_QUADS );
        glVertex3f( m_iWindowWidth,               0, 0 );
        glVertex3f(              0,               0, 0 );
        glVertex3f(              0, m_iWindowHeight, 0 );
        glVertex3f( m_iWindowWidth, m_iWindowHeight, 0 );
    glEnd();

    glEnable( GL_DEPTH_TEST );
    glDisable( GL_BLEND );

    glMatrixMode( GL_PROJECTION );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
    glPopMatrix();

    glColor4f( 1, 1, 1, 1 );
}
