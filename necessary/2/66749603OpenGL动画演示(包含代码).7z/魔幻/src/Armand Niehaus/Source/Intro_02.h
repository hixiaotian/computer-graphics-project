#ifndef _INTRO_02_H
#define _INTRO_02_H

#include "Stdinc.h"
#include "Scene.h"
#include "Mesh.h"

class CMyObject : public CObject
{
    private:
        float           m_fRot; // etc, etc, .....
        unsigned int    m_texEnv;

    public:

        inline void SetTexture( unsigned int uI ) { m_texEnv = uI; };

        bool Render();

        CMyObject() {};
};

class CIntroScene2 : public CScene
{
    private:
        CMyObject*          m_pTitle;
        unsigned int        m_texCloud;
        unsigned int        m_listCurve;

        float               m_fBackgroundRotate;
        float               m_fLayer1Par;
        float               m_fLayer2Par;

    public:

        void ScaleTextureMatrix( float x, float y, float z );
        void RestoreTextureMatrix();

        bool Initialize();
        bool Cleanup();
        bool Render( int iScreenWidth, int iScreenHeight );
        bool Update();

        CIntroScene2();
};

#endif