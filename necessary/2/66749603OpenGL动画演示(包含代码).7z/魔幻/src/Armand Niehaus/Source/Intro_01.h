#ifndef _INTRO_01_H
#define _INTRO_01_H

#include "Stdinc.h"
#include "Scene.h"
#include "Mesh.h"

class CIntroScene : public CScene
{
    private:
        unsigned int    m_iNoiseTex;
        CImage*         m_pNoise;
        unsigned char   m_uRandom;

    public:

        bool Initialize();
        bool Cleanup();
        bool Render( int iScreenWidth, int iScreenHeight );
        bool Update();

        CIntroScene();
};

#endif