#include <math.h>
#include "Tube.h"

CTubeScene::CTubeScene()
{
    m_fFades[ FADEIN ].m_bOn = true;
    m_fFades[ FADEIN ].m_fTime = 2.5f;
    m_fFades[ FADEIN ].m_fColorR = 0.0;
    m_fFades[ FADEIN ].m_fColorG = 0.0;
    m_fFades[ FADEIN ].m_fColorB = 0.0;

    m_fFades[ FADEOUT ].m_bOn = true; 
    m_fFades[ FADEOUT ].m_fTime = 15.0f;
    m_fFades[ FADEOUT ].m_fColorR = 0.0;
    m_fFades[ FADEOUT ].m_fColorG = 0.0;
    m_fFades[ FADEOUT ].m_fColorB = 0.0;

    m_fLength = 18.0f;
    SetSceneName( "Tube Scene" );
}

bool CTubeScene::Initialize()
{
    Texture* tex = Texture::GetInstance();
    tex->SetMipMaps( true );

    m_pTube = new CObject();
    if (!m_pTube->LoadFrom3DS( "data\\tube2.3ds" ))
        return false;

    m_pPlates = new CObject();
    if (!m_pPlates->LoadFrom3DS( "data\\tube.3ds" ))
        return false;

    tex->SetMipMaps( false );

    //*** create lights
    m_vLights.clear();
    CLight light2;
    light2.m_rgbAmbient.Set( 0.0, 0.0, 0.0 );
    light2.m_rgbDiffuse.Set( 0.0, 0.0, 0.75 );
    light2.m_vPosition.Set( 0, 0, -150 );
    light2.Create( GL_LIGHT1 );
    m_vLights.push_back( light2 );

    CLight light3;
    light3.m_rgbAmbient.Set( 0.0, 0.0, 0.0 );
    light3.m_rgbDiffuse.Set( 0.75, 0.0, 0.0 );
    light3.m_vPosition.Set( 0, 10, 0 );
    light3.Create( GL_LIGHT2 );
    m_vLights.push_back( light3 );

    return true;
}

bool CTubeScene::Cleanup()
{
    if (m_pTube)
        delete m_pTube;

    if (m_pPlates)
        delete m_pPlates;

    return true;
}

bool CTubeScene::Render( int iScreenWidth, int iScreenHeight )
{
    float fTime = Timer::GetTimer( TIMER_SINCEAPPSTART );
    gluLookAt( 15*cos(fTime), 0, 150,
               0, 0, 0,
               0, 1, 0 );

    glEnable( GL_LIGHTING );
    glDisable( GL_COLOR_MATERIAL );

    m_pTube->Render();

    //fTime /= 5.0f;

    glPushMatrix();
        glRotatef( fTime*70, 0, 0, 1 );
        glRotatef( 180, 0, 1, 0 );
        m_pPlates->Render();
    glPopMatrix();
    
    glPushMatrix();
        glScalef( 0.70, 0.70, 1.0 );
        glRotatef( -fTime*70, 0, 0, 1 );
        glRotatef( 180, 0, 1, 0 );
        m_pPlates->Render();
    glPopMatrix();

    glPushMatrix();
        glScalef( 0.45, 0.45, 1.0 );
        glRotatef( fTime*70, 0, 0, 1 );
        glRotatef( 180, 0, 1, 0 );
        m_pPlates->Render();
    glPopMatrix();

    glPushMatrix();
        glScalef( 0.25, 0.25, 1.0 );
        glRotatef( -fTime*70, 0, 0, 1 );
        glRotatef( 180, 0, 1, 0 );
        m_pPlates->Render();
    glPopMatrix();

    glDisable( GL_LIGHTING );
    glEnable( GL_COLOR_MATERIAL );

    return true;
}

bool CTubeScene::Update()
{
    float fTime = Timer::GetTimer( TIMER_SINCELASTFRAME );

    m_vLights[0].m_vPosition.z += 60.0f * fTime;
    if (m_vLights[0].m_vPosition.z>100)
    {
        float f = 0.75f - ((0.75f / 50.0f) * (m_vLights[0].m_vPosition.z-100));
        m_vLights[0].m_rgbDiffuse.Set( 0, 0, f );
        if (m_vLights[0].m_vPosition.z>150)
        {
            m_vLights[0].m_vPosition.z=-150.0f;
            m_vLights[0].m_rgbDiffuse.Set( 0, 0, 0.75f );
        }
    }
    m_vLights[0].Create();

    fTime = Timer::GetTimer( TIMER_SINCEAPPSTART );

    m_vLights[1].m_vPosition.Set( 50*cos(0.5*fTime), 50*sin(0.5*fTime), -150 );
    m_vLights[1].Create();

    return true;
}

