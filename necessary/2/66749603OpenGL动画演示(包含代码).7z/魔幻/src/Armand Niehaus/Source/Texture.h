#ifndef _TEXTURE_H_
#define _TEXTURE_H_

#include "Stdinc.h"
#include "Singleton.h"
#include "Image.h"

class Texture : public Singleton<Texture>
{
    private:

        std::string         m_strTextureDir;

        unsigned int        m_iFilter;
        bool                m_bMips;

    public:

        inline void SetTextureDirectory( std::string dir )
        { m_strTextureDir = dir; };
        inline std::string GetTextureDirectory()
        { return m_strTextureDir; };

        inline void SetFilter( unsigned int iFilter )
        { m_iFilter = iFilter; }
        inline void SetMipMaps( bool bOn )
        { m_bMips = bOn; }

        unsigned int LoadTexture( std::string strFile );
        unsigned int UploadTexture( CImage* pImage );
        
        Texture();
};


#endif