#include "Demo.h"
#include "Scene.h"
#include "Sound.h" 

// Scenes
#include "intro_01.h"
#include "intro_02.h"
#include "cresent.h"
#include "tube.h"
#include "credits.h" 

CApp::CApp()
{
    // why am i here ???
}

CApp::~CApp()
{
    // yeah, and what about me ??
}

bool CApp::AppInitialize()
{
    // set the standard texture directory
    Texture* tex = Texture::GetInstance();
    tex->SetTextureDirectory( "data\\" );

    // pass some standard parameters to our scenemanager
    SceneManager* sm = SceneManager::GetInstance();
    sm->SetResolution( m_iWindowWidth, m_iWindowHeight );

    // add the scenes, in all their hardcoded splendure
    sm->AddScene( new CIntroScene() );
    sm->AddScene( new CIntroScene2() );
    sm->AddScene( new CCresentScene() ); // <---
    sm->AddScene( new CTubeScene() );    //    |
    sm->AddScene( new CCresentScene() ); // <---- didn't have time to do a proper playlist :)
    sm->AddScene( new CCreditsScene() );

    // let every scene initialize
    if (!sm->InitializeScenes())
        return false;

    // start,.. :)
    sm->Start( m_parApp.m_bLooped );

    if (m_parApp.m_bSound)
    {
        // intialize BASS sound system and 
        // start playing music
        Sound* snd = Sound::GetInstance();
        if (!snd->Initialize( 44100, false ))
            return false;
        if (!snd->LoadSong( "data\\noise.mod" ))
            return false;
        snd->Play();
    }

    return true;
}

bool CApp::AppCleanup()
{
    // stop and cleanup sound
    if (m_parApp.m_bSound)
    {
        Sound* snd = Sound::GetInstance();
        snd->Stop();
        snd->Cleanup();
        snd->ReleaseInstance();
    }

    SceneManager* sm = SceneManager::GetInstance();
    if (!sm->CleanupScenes())
        return false;
    sm->ClearScenes();
    sm->ReleaseInstance();

    return true;
}

bool CApp::AppRender()
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glLoadIdentity();

    SceneManager* sm = SceneManager::GetInstance();
    if (!sm->UpdateAndRender())
        PostQuitMessage( 0 );

    return true;
}