#include "Base.h"

CBaseApp::CBaseApp()
{
    // null me!
    m_hInstance     = NULL;
    m_hWnd          = NULL;

    // standard window parameters
    m_iWindowWidth   = 640;
    m_iWindowHeight  = 480;
    m_iWindowDepth   = 32;
    m_bWindowed      = true;
    m_strWindowTitle = "Unnamed";

    m_bReady = false;
}

CBaseApp::~CBaseApp()
{
}

bool CBaseApp::Initialize( HINSTANCE hInst, std::string strTitle, 
                           int iWidth, int iHeight, int iDepth, bool bWindowed )
{
    // return error if instance is null
    if (!hInst)
        return false;

    m_hInstance = hInst;

    Log::Initialize( "log.txt" );

    // window parameters
    m_iWindowWidth   = iWidth;
    m_iWindowHeight  = iHeight;
    m_iWindowDepth   = iDepth;
    m_bWindowed      = bWindowed;
    m_strWindowTitle = strTitle;

    // create main window
    if (!MyCreateWindow())
        return false;

    // setup our opengl viewport
    OpenGL* ogl = OpenGL::GetInstance();
    if (!ogl->Initialize( m_hWnd, m_iWindowWidth, m_iWindowHeight, 
                          m_iWindowDepth, m_bWindowed ))
        return false;

    // setup timer
    if (!Timer::Initialize())
        return false;
    Timer::OncePerFrameQuery( m_hWnd );

    // let the app do some custom initialization
    if (!AppInitialize())
        return false;

    // we're ready!
    m_bReady = true;

    return true;
}

bool CBaseApp::Cleanup()
{
    // let the app cleanup its stuff
    AppCleanup();

    // destroy the textures
    Texture::ReleaseInstance();

    // cleanup opengl
    OpenGL* ogl = OpenGL::GetInstance();
    ogl->Cleanup();
    OpenGL::ReleaseInstance();

    // destroy main window
    if (m_hWnd)
    {
        if (!DestroyWindow(m_hWnd))
            return false;
        m_hWnd = NULL;
    }

    // unregister windowclass
    if (!UnregisterClass( "BaseClass", m_hInstance ))
        return false;

    m_hInstance = NULL;

    Log::Cleanup();

    return true;
}

bool CBaseApp::MyCreateWindow()
{
    // fill and register window class
    WNDCLASS wc;
    wc.style         = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
    wc.lpfnWndProc   = (WNDPROC)WndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = m_hInstance;
    wc.hIcon         = NULL;
    wc.hCursor       = NULL;
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH),
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = "BaseClass";

    if (!RegisterClass(&wc))
    {
        Log::Print( "Error registering window class" );
        return false;
    }

    // desired window size
    RECT rcClient;
    rcClient.left   = 0;
    rcClient.right  = m_iWindowWidth;
    rcClient.top    = 0;
    rcClient.bottom = m_iWindowHeight;

    unsigned long dwExtendedWindowStyle;
    unsigned long dwWindowStyle;

    if (m_bWindowed)
    {
        dwExtendedWindowStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
        dwWindowStyle         = WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|/*WS_THICKFRAME|*/WS_MINIMIZEBOX|WS_VISIBLE;
    } else
    {
        dwExtendedWindowStyle = WS_EX_APPWINDOW;
        dwWindowStyle         = WS_POPUP;
    }

    // adjust windowrect to make room for borders, caption, etc
    AdjustWindowRectEx( &rcClient, dwWindowStyle, false, dwExtendedWindowStyle );

    m_hWnd = CreateWindowEx( dwExtendedWindowStyle,
                           "BaseClass",
                           m_strWindowTitle.c_str(),
                           WS_CLIPSIBLINGS | WS_CLIPCHILDREN | dwWindowStyle,
                           CW_USEDEFAULT, CW_USEDEFAULT,
                           (rcClient.right-rcClient.left),
                           (rcClient.bottom-rcClient.top),
                           NULL,
                           NULL,
                           m_hInstance,
                           NULL );
    if (m_hWnd==NULL)
    {
        Log::Print( "Error creating window" );
        return false;
    }

    // this is usually done at window creation, but you can never be too sure
    ShowWindow( m_hWnd, SW_SHOW );
    SetFocus( m_hWnd );

    Log::Print( "Window created (%dx%d)", m_iWindowWidth, m_iWindowHeight );

    return true;
}

LRESULT CALLBACK CBaseApp::WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
    switch( uMsg )
    {
        case WM_SYSCOMMAND:
        {
            switch( wParam )
            {
                case SC_SCREENSAVE:
                case SC_MONITORPOWER:
                    return 0;
            }
            break;
        }

        case WM_PAINT:
        {
            PAINTSTRUCT ps;
            BeginPaint( hWnd, &ps );
            EndPaint( hWnd, &ps );
            return 0;
        }

        case WM_CLOSE:
            // send WM_QUIT to main loop
            PostQuitMessage( 0 );
            return 0;

        case WM_KEYDOWN:
            if (wParam==VK_ESCAPE)
                PostQuitMessage( 0 );
            return 0;
    };

    // do standard window message handling stuff
    return DefWindowProc( hWnd, uMsg, wParam, lParam );
}

int CBaseApp::Run()
{
    MSG msg;
    bool bDone = false;

    while (!bDone)
    {
        if (PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ))
        {
            if (msg.message == WM_QUIT)
            {
                // WM_QUIT; exit the while-loop
                bDone = true;
            } else
            {
                // any other message needs to be handled correctly
                TranslateMessage( &msg );
                DispatchMessage( &msg );
            }
        } else
        {
            // no message to handle, so render a new frame
            if (m_bReady)
            {
                if (!Render())
                    bDone = true;
            }
        }
    };

    return msg.wParam;
}

bool CBaseApp::Render()
{
    // get current time/fps/etc/whatever
    if (!Timer::OncePerFrameQuery( m_hWnd ))
        return false;

    if (!AppRender())
        return false;

    OpenGL* ogl = OpenGL::GetInstance();
    SwapBuffers( ogl->RetrieveHDC() );

    return true;
}