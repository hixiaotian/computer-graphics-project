#ifndef _MATERIAL_H_
#define _MATERIAL_H_

#include "Stdinc.h"

namespace baseScene
{

class CMaterial
{
    public:
        std::string         m_strName;
    
        float               m_fUScale;
        float               m_fVScale;

        bool                m_bHasTexture;
        std::string         m_strTextureName;


        /*CMaterial();
        ~CMaterial();*/
};

} // namespace

#endif