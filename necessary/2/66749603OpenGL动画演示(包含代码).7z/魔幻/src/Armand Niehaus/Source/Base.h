#ifndef _BASE_H_
#define _BASE_H_

#include "Stdinc.h"
#include "OpenGL.h"

#include "Clock.h"

#include "Texture.h"

class CBaseApp
{
    private:
        HINSTANCE       m_hInstance;
        bool            m_bReady;

        bool MyCreateWindow();
        static LRESULT CALLBACK WndProc( HWND hWnd, UINT uMsg, 
                                         WPARAM wParam, LPARAM lParam ); 

    protected:
        HWND            m_hWnd;
        int             m_iWindowWidth;
        int             m_iWindowHeight;
        int             m_iWindowDepth;
        bool            m_bWindowed;
        std::string     m_strWindowTitle;

    public:

        virtual bool AppInitialize() { return true; };
        virtual bool AppCleanup()    { return true; };
        virtual bool AppRender()     { return true; };

        bool Initialize( HINSTANCE hInst, std::string strTitle, 
                         int iWidth, int iHeight, int iDepth, bool bWindowed );
        bool Cleanup();

        bool Render();
        int Run();

        CBaseApp();
        ~CBaseApp();
};

#endif