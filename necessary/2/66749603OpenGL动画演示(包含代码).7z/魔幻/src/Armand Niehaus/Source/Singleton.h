#ifndef _SINGLETON_H_
#define _SINGLETON_H_

#include <windows.h>

template<class T> class Singleton
{
    protected:
        Singleton() {}
        Singleton( const Singleton & ) {}
        Singleton &operator = (Singleton &) {}

        static T* pInst;

    public:
        static T* GetInstance()
        {
            if (pInst)
                return pInst;
            pInst = new T;
            return pInst;
        }

        static void ReleaseInstance()
        {
            if (pInst)
            {
                delete pInst;
                pInst = NULL;
            }
        }
};

template<class T> T *Singleton<T>::pInst = 0;

#endif