#include "Log.h"

//-------------------------------------------------------
//  Static variables    
//-------------------------------------------------------
FILE* Log::m_pFileHandle = NULL;
std::string Log::m_strFile;
std::string Log::m_strSub;

//-------------------------------------------------------
//  Initialize()
//-------------------------------------------------------
//      Creates the log file and writes a simple header.
//
bool Log::Initialize( std::string strFile )
{
    m_strSub = "";

    m_pFileHandle = fopen( strFile.c_str(), "wt" );
    if (m_pFileHandle==NULL)
        return false;

    fclose( m_pFileHandle );

    m_strFile = strFile;

    Print( "**********************************" );
    Print( " Base Log " );
    Print( "**********************************" );

    return true;
}

//-------------------------------------------------------
//  Cleanup()
//-------------------------------------------------------
//      Closes log file if it's accidentally left open.
//
void Log::Cleanup()
{
    Print( "Closing Log" );
    if (m_pFileHandle)
        fclose( m_pFileHandle );
}

//-------------------------------------------------------
//  Print()
//-------------------------------------------------------
//      Prints text to the log file, in that handy
//      printf() style string thingy.
//
void Log::Print( const char *str, ... )
{
	va_list l_va;
	
	va_start( l_va, str );
        m_pFileHandle = fopen( m_strFile.c_str(), "a+" );
        if (m_pFileHandle==NULL)
            return;
		fprintf( m_pFileHandle, "%s", m_strSub.c_str() );
		vfprintf( m_pFileHandle, str, l_va );
		putc( '\n', m_pFileHandle );
        fclose( m_pFileHandle );
	va_end( l_va );
}

//-------------------------------------------------------
//  SetSub()
//-------------------------------------------------------
//      Changes the sub string.
//
void Log::SetSub( std::string str )
{
    m_strSub = str;
}
