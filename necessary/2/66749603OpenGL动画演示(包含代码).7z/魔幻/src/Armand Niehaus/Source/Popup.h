#ifndef _POPUP_H_
#define _POPUP_H_

class CParameters
{
    public:
        // window parameters
        int     m_iWidth;
        int     m_iHeight;
        int     m_iDepth;
        bool    m_bWindowed;

        // demo parameters
        bool    m_bLooped;
        bool    m_bSound;
};

class CPopup
{
    private:


    public:

        CParameters Run();

        CPopup();
        ~CPopup();
};

#endif