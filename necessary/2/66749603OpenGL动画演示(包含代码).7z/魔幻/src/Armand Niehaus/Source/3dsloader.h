#ifndef _CLoader3DS_H_
#define _CLoader3DS_H_

#include "Stdinc.h"
#include "Texture.h"
#include "Mesh.h"

class CLoader3DS
{
    private:
        CMesh*          m_pCurrentMesh;
        CMaterial*      m_pCurrentMaterial;

        CObject*        m_pCurrentObject;

        Texture*        tm;

        long EatChunk(char* buffer);

    public:
        bool Load( std::string filename, CObject* pObj );

        CLoader3DS();
        ~CLoader3DS();
};

#endif