//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res_script.rc
//
#define IDD_DIAG_MAIN                   101
#define IDB_BITMAP_POPUP                103
#define IDI_ICON_MAIN                   104
#define IDC_QUIT                        1000
#define IDC_RUN                         1001
#define IDC_RADIO_640                   1002
#define IDC_RADIO_800                   1003
#define IDC_RADIO_1024                  1004
#define IDC_RADIO_16                    1005
#define IDC_RADIO_32                    1006
#define IDC_CHECK_WINDOWED              1008
#define IDC_CHECK_LOOP                  1009
#define IDC_CHECK_SOUND                 1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
