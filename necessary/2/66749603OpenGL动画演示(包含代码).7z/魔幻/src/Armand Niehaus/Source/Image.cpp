#include <stdio.h>
#include "Image.h"

#include "Jpeg\jpegdecoder.h"

CImage::CImage()
{
    m_cData = NULL;
    m_dwWidth = 0;
    m_dwHeight = 0;
}
        
CImage::~CImage()
{
    if ( m_cData )
    {
        delete[] m_cData;
        m_cData = NULL;
    }
}

bool CImage::LoadFromJPEG( std::string strFilename )
{
    Pjpeg_decoder_file_stream Pinput_stream = new jpeg_decoder_file_stream();

    if (Pinput_stream->open( strFilename.c_str() ))
    {
        delete Pinput_stream;
        return false;
    }

    Pjpeg_decoder Pd = new jpeg_decoder( Pinput_stream, false );

    if (Pd->get_error_code() != 0)
    {
        delete Pd;
        delete Pinput_stream;
        return false;
    }

    //printf("Width: %i\n", Pd->get_width());
    //printf("Height: %i\n", Pd->get_height());
    //printf("Components: %i\n", Pd->get_num_components());

    m_dwWidth = Pd->get_width();
    m_dwHeight = Pd->get_height();
    m_dwDepth = 24;//Pd->get_num_components() * 8;

    if (Pd->begin())
    {
        delete Pd;
        delete Pinput_stream;

        return false;
    }

    unsigned char *Pbuf = NULL;
    if (Pd->get_num_components() == 3)
    {
        Pbuf = new unsigned char[ Pd->get_width() * 3 ];
        if (!Pbuf)
        {
            delete Pd;
            delete Pinput_stream;

            return false;
        }
    }

    int lines_decoded = 0;

    m_cData = new unsigned char[ Pd->get_width() * Pd->get_height() * Pd->get_num_components() ];
    int pos=0;

    for ( ; ; )
    {
        void *Pscan_line_ofs;
        uint scan_line_len; 

        if (Pd->decode(&Pscan_line_ofs, &scan_line_len))
            break;

        lines_decoded++;

        if (Pd->get_num_components() == 3)
        {
            uchar *Psb = (uchar *)Pscan_line_ofs;
            uchar *Pdb = Pbuf;
            int src_bpp = Pd->get_bytes_per_pixel();

            for (int x = Pd->get_width(); x > 0; x--, Psb += src_bpp, Pdb += 3 )
            {
                m_cData[pos+0] = Psb[0];
                m_cData[pos+1] = Psb[1];
                m_cData[pos+2] = Psb[2];
                pos += 3;
            }
        }

    }

    delete Pbuf;

    if (Pd->get_error_code())
    {
        delete Pd;
        delete Pinput_stream;
        //delete m_cData;

        return false;
    }

    delete Pd;
    delete Pinput_stream;

    return true;
}
