#ifndef _LOG_H_
#define _LOG_H_

#include <stdio.h>
#include "Stdinc.h"

class Log // no singleton, because it's used to often to
          // return the instance every time.
{
    private:

        static FILE* m_pFileHandle;
        static std::string m_strFile;
        static std::string m_strSub;

    public:

        static bool Initialize( std::string strFile );
        static void Cleanup();
        static void Print( const char *str, ... );
        static void SetSub( std::string str );  
};

#endif