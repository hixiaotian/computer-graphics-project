#ifndef _SCENE_H_
#define _SCENE_H_

#include "Stdinc.h"
#include "Singleton.h"
#include "Base.h"

class SceneManager;

#define FADEIN     0
#define FADEOUT    1

class CScene
{
    friend SceneManager;
    class CFade
    {
        public:
            float   m_fTime;
            bool    m_bOn;
            float   m_fColorR, m_fColorG, m_fColorB;
    };
    private:
        std::string     m_strSceneName;

        bool            m_bRunning;
        int             m_iVectorTag;

    protected:
        float           m_fLength;
        float           m_fRunningTime;
        
        CFade           m_fFades[2];

        int             m_iQuality;

    public:
        virtual bool Initialize() { return true; };
        virtual bool Cleanup() { return true; };
        virtual bool Update() { return true; };
        virtual bool Render( int iScreenWidth, int iScreenHeight ) { return true; };

        inline void SetRunningTime( float fTime )
        { m_fRunningTime = fTime; };

        inline std::string GetSceneName()
        { return m_strSceneName; };
        inline void SetSceneName( std::string strName )
        { m_strSceneName = strName; };

        CScene();
        ~CScene();
};

class SceneManager : public Singleton<SceneManager>
{
    private:
        std::vector<CScene*>    m_vScenes;
        std::vector<int>        m_vPlaylist;

        bool            m_bRunning;
        bool            m_bLoop;

        int             m_iCurrentScene;

        float           m_fStartTime;
        float           m_fSceneStart;

        int             m_iWindowWidth;
        int             m_iWindowHeight;

        int             m_iQuality;

        void HandleFades( CScene* pScene, float fRunTime );

    public:

        bool AddScene( CScene* pScene );
        bool ClearScenes();

        void SetResolution( int iWidth, int iHeight );

        bool InitializeScenes();
        bool CleanupScenes();
        bool Start( bool bLoop );
        bool Stop();

        bool UpdateAndRender();

        SceneManager();
        ~SceneManager();
};

#endif