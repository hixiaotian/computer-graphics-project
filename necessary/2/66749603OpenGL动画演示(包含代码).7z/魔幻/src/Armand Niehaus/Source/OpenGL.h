#ifndef _OPENGL_H_
#define _OPENGL_H_

#include "Stdinc.h"
#include "Singleton.h"

class OpenGL : public Singleton<OpenGL>
{
    private:
        HDC                 m_hDC;
        HGLRC               m_hRC;
        HWND                m_hAppWindowHandle;

        int                 m_dwDesiredWidth;
        int                 m_dwDesiredHeight;
        int                 m_dwDesiredDepth;
        bool                m_bWindowed;

        void SetDefaults();
        bool SetFullscreen( bool bFlag );
        bool SetupPixelFormat( HDC hdc );
        bool SizeViewport( float fFOV, int iWidth, int iHeight );

    public:

        bool SetFOV( float fAngle );

        // Intialization and cleanup
        bool Initialize( HWND hWnd, int iWidth, int iHeight, 
                         int iDepth, bool bWindowed );
        bool Cleanup();

        // Util functions
        HDC RetrieveHDC();

        OpenGL();
        ~OpenGL();
}; 

#endif