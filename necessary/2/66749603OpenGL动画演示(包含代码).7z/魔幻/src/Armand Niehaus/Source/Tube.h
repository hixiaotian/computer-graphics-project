#ifndef _TUBE_H_
#define _TUBE_H_

#include "Scene.h"
#include "Mesh.h"
#include "SimpleVector.h"
#include "Lights.h"

class CTubeScene : public CScene
{
    private:
        CObject*                    m_pTube;
        CObject*                    m_pPlates;
        std::vector<CLight>         m_vLights;

    public:

        bool Initialize();
        bool Cleanup();
        bool Render( int iScreenWidth, int iScreenHeight );
        bool Update();

        CTubeScene();
};


#endif