#ifndef _LIGHTS_H_
#define _LIGHTS_H_

#include "SimpleVector.h"

class CLight // kind of messy :)
{
    class RGB 
    { 
        public:
            float r, g, b; 

            inline void Set( float rr, float gg, float bb )
            { r=rr; g=gg; b=bb; } // try say *that* ten times

            inline void Format( float* pFloats )
            { 
                pFloats[0] = r;
                pFloats[1] = g;
                pFloats[2] = b;
                pFloats[3] = 1.0f;
            }
    };
    public:
        RGB             m_rgbAmbient;
        RGB             m_rgbDiffuse;
        CVector3        m_vPosition;
        unsigned int    m_iId;

        void Create( unsigned iId )
        {
            float fTemp[4];

            m_iId = iId;

            m_rgbAmbient.Format( (float*)fTemp );
            glLightfv( m_iId, GL_AMBIENT, fTemp  );

            m_rgbDiffuse.Format( (float*)fTemp );
            glLightfv( m_iId, GL_DIFFUSE, fTemp  );

            Pos();
            Enable();
        }
        void Create()
        {
            Create( m_iId );
        }

        void Pos()
        {
            float fTemp[4];
            fTemp[0] = m_vPosition.x;
            fTemp[1] = m_vPosition.y;
            fTemp[2] = m_vPosition.z;
            fTemp[3] = 1.0f;
            glLightfv( m_iId, GL_POSITION, fTemp );
        }
        void Enable() { glEnable( m_iId ); };
        void Disable() { glDisable( m_iId ); };
};

#endif