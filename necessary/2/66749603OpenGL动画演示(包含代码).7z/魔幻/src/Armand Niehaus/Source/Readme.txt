**********************************
  ******************************  

   NeHe Mini-Demo Contest Entry

          "The Hollow"
  
              by 

     Armand "Crawl" Niehaus

  ******************************  
**********************************

    I started programming two weeks ago, when the contest was 
announced but i spend a *week* tracking a bug down that caused textures
to not upload completely in fullscreen..... it's "kind of" fixed... :)

    The demo uses "Small JPEG Decoding Library" by Rich Geldreich
and BASSMOD for sound. The JPEG library is great utility which enables 
you to load prepared JPEG's... Best thing about it is that you don't 
need to distribute any external DLL files. The site can be found at 
www.voicenet.com/~richgel the full source can also be found there...

    No special extensions are used,... so in theory it should run on
any system......

Enjoy,....