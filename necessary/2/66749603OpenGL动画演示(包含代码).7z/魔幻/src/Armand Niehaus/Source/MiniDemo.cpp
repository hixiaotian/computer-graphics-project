#include <windows.h>
#include "Demo.h"
#include "Resource\Resource.h"

CParameters     g_Parameters;

LRESULT CALLBACK DlgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch( uMsg )
    {
        case WM_INITDIALOG:
            ZeroMemory( &g_Parameters, sizeof(CParameters) );

            SendDlgItemMessage( hWnd, IDC_RADIO_640, BM_SETCHECK, BST_CHECKED , 0 );
            SendDlgItemMessage( hWnd, IDC_RADIO_32, BM_SETCHECK, BST_CHECKED , 0 );
            SendDlgItemMessage( hWnd, IDC_CHECK_SOUND, BM_SETCHECK, BST_CHECKED , 0 );
            SendDlgItemMessage( hWnd, IDC_CHECK_WINDOWED, BM_SETCHECK, BST_CHECKED , 0 );

            g_Parameters.m_iWidth  = 640;
            g_Parameters.m_iHeight = 480;
            g_Parameters.m_iDepth  = 32;
            g_Parameters.m_bLooped   = false;
            g_Parameters.m_bWindowed = true;
            g_Parameters.m_bSound    = true;

            return true;

        case WM_COMMAND:
            switch( LOWORD( wParam ) )
            {
                case IDC_RUN:
                    EndDialog( hWnd, 0 );
                    return true;
                case IDC_QUIT:
                    EndDialog( hWnd, 1 );
                    return true;

                case IDC_RADIO_640:
                    g_Parameters.m_iWidth  = 640;
                    g_Parameters.m_iHeight = 480;
                    break;
                case IDC_RADIO_800:
                    g_Parameters.m_iWidth  = 800;
                    g_Parameters.m_iHeight = 600;
                    break;
                case IDC_RADIO_1024:
                    g_Parameters.m_iWidth  = 1024;
                    g_Parameters.m_iHeight = 768;
                    break;

                case IDC_RADIO_16:
                    g_Parameters.m_iDepth  = 16;
                    break;
                case IDC_RADIO_32:
                    g_Parameters.m_iDepth  = 32;
                    break;

                case IDC_CHECK_LOOP:
                    if (g_Parameters.m_bLooped)
                        g_Parameters.m_bLooped = false;
                    else
                        g_Parameters.m_bLooped = true;
                    break;
                case IDC_CHECK_WINDOWED:
                    if (g_Parameters.m_bWindowed)
                        g_Parameters.m_bWindowed = false;
                    else
                        g_Parameters.m_bWindowed = true;
                    break;
                case IDC_CHECK_SOUND:
                    if (g_Parameters.m_bSound)
                        g_Parameters.m_bSound = false;
                    else
                        g_Parameters.m_bSound = true;
                    break;

            }
            break;

        case WM_CLOSE:
            EndDialog( hWnd, 1 );
            break;

        case WM_DESTROY:

            break;
    }
    return false;
}

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE, LPSTR, int )
{
    // our little popup, return a 1 when the user wants to exit
    if (DialogBox( hInstance, MAKEINTRESOURCE(IDD_DIAG_MAIN), NULL, (DLGPROC)DlgProc ))
        return 0;

    // the actual demo
    CApp* pApp;
    pApp = new CApp();

    if (pApp)
    {
        // window parameters
        pApp->SetParameters( g_Parameters );

        // our app class was succesfuly created
        if (pApp->Initialize( hInstance, "The Hollow", g_Parameters.m_iWidth, g_Parameters.m_iHeight, 
                              g_Parameters.m_iDepth, g_Parameters.m_bWindowed ))
        {
            // intialization succesfull,.... run !
            int iReturn = pApp->Run();

            // app has exited, attempt a cleanup
            if (pApp->Cleanup())
            {
                // cleanup succesfull, delete our app class and exit...
                delete pApp;
                return iReturn; // usually zero,...
            }
        }

        // an error has occured, so try and cleanup everything
        // that has already been initialized
        pApp->Cleanup();
        delete pApp;

        MessageBox( NULL, "An Error Has Occured!!\n\nCheck the log file for further information...", 
                    "Demo", MB_OK | MB_ICONERROR );

        // exit
        return 1;
    }

    MessageBox( NULL, "Something is *very* wrong here !!!", "Demo", MB_OK | MB_ICONERROR );

    // exit
    return 1;
}