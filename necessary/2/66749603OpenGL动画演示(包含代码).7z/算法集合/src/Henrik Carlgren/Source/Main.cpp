//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "system.h"

#include "demo.h"

#include "music.h"

#include "config.h"

#include <stdio.h>



//
// GLOBAL VARIABLES
//

FMUSIC_MODULE *musicModule;

HINSTANCE applicationInstance;

HWND windowHandle;

HDC deviceContext;

HGLRC renderContext;

bool running = true;



//
// FUNCTION: WinMain
//

int WINAPI WinMain(HINSTANCE currentInstance, HINSTANCE otherInstance, LPSTR parameters, int show)
{
	__int64 last, temp;
	long double timeScale, delta, time;

	applicationInstance = currentInstance;

	//
	// STARTUP
	//

	systemStartup();

	demoStartup();
	
	musicStartup();

	
	//
	// HPC
	//

	QueryPerformanceFrequency((LARGE_INTEGER *)&temp);
	timeScale = 1.0 / temp;


	//
	// GLOBAL OPENGL STATES
	//

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);


	
	//
	// DEMO STUFF
	//

	#ifdef MUSIC
		FMUSIC_PlaySong(musicModule);
	#endif // MUSIC

	time = 0.0;

	QueryPerformanceCounter((LARGE_INTEGER *)&last);

	//
	// DEMO LOOP
	//

	while(running)
	{

		systemCycle(); // PROCESS ALL PENDING MESSAGES
		
		QueryPerformanceCounter((LARGE_INTEGER *)&temp);

		delta = (temp - last) * timeScale * 1000.0;

		QueryPerformanceCounter((LARGE_INTEGER *)&last);

		time += delta;

		demoCycle(time, delta); // DO SOME DEMO STUFF =)

	}



	//
	// CLEANUP
	//

	musicCleanup();

	demoCleanup();

	systemCleanup();


	//
	// THE END
	//

	return 0;
}