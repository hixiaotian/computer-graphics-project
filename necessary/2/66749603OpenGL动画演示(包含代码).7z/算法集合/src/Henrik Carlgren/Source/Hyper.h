//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//

#ifndef hyper_h
#define hyper_h

void hyperCycle(float a_fTime, float a_fDelta);

#endif // hyper_h