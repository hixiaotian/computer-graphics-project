//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "intro.h"

#include "particle.h"

#include "texture.h"

#include "misc.h"

#include <windows.h>

#include <gl\gl.h>



//
// GLOBAL VARIABLES
//

const int particleCount = 2048;

VECTOR targetPosition;

VECTOR targetVelocity;

VECTOR targetImpulse;

PARTICLE particle[particleCount];

extern GLuint texture[TEXTURE_COUNT];



//
// FUNCTION: introStartup
//

void introStartup(void)
{
	//
	// PARTICLE SYSTEM
	//

	targetVelocity.x = 0.0f;
	
	targetVelocity.y = -0.002f;

	targetVelocity.z = 0.0f;


	for(int i = 0; i < particleCount; i++)
	{

		particle[i].targetPosition = &targetPosition;

		particle[i].targetVelocity = &targetVelocity;

		particle[i].targetImpulse = &targetImpulse;

		particle[i].ageRangeMinimum = 1000;

		particle[i].ageRangeMaximum = 2000;

		particle[i].color.x = 1.0f; // red

		particle[i].color.y = 0.68f; // green

		particle[i].color.z = 0.32f; // blue

		particle[i].birth();

	}

	generateTextures();

}



//
// FUNCTION: introCleanup
//

void introCleanup(void)
{
}



//
// FUNCTION: introStartup
//

void introCycle(long double time, long double delta)
{
	float particleSize = 0.16f;
	int particleUsage = particleCount;

	//
	// PRE
	//

	glClear(GL_DEPTH_BUFFER_BIT);



	//
	// BACKGROUND
	//

	ortho();

	glMatrixMode(GL_TEXTURE);

	glPushMatrix();

	glTranslatef((float)time*-0.0001f, 0.0f, 0.0f);

	glRotatef((float)time*-0.01f, 1.0f, 0.0f, 0.0f);

	glRotatef((float)time*-0.02f, 0.0f, 1.0f, 0.0f);

	glRotatef((float)time*-0.03f, 0.0f, 0.0f, 1.0f);
	
	glEnable(GL_BLEND);
		
	glDisable(GL_DEPTH_TEST);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_TEXTURE_2D);
	
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BG1]);

	glColor4f(0.5f, 0.5f, 1.0f, (float)delta*0.01f);

	glBegin(GL_QUADS);

		glTexCoord2i(0, 0);
		glVertex2i(0, 0);

		glTexCoord2i(1, 0);
		glVertex2i(800, 0);

		glTexCoord2i(1, 1);
		glVertex2i(800, 600);

		glTexCoord2i(0, 1);
		glVertex2i(0, 600);

	glEnd();

	glPopMatrix();

	glMatrixMode(GL_MODELVIEW);



	//
	// PARTICLE SYSTEM
	//

	float timeScale = 0.005f;

	targetPosition.x = 2.0f * cosf((float)time * timeScale);

	targetPosition.y = sinf((float)time * timeScale) + 0.8f;

	targetPosition.z = cosf((float)time * (timeScale / 2.0f)) - 1.0f;

	targetImpulse.x = 0.005f * sinf((float)time * timeScale);

	targetImpulse.y = 0.005f * -cosf((float)time * timeScale);

	targetImpulse.z = 0.005f * (sinf((float)time * (timeScale / 2.0f)));

	perspective();

	glTranslatef(0.0f,0.0f,-2.75f);
	
	glEnable(GL_BLEND);
		
	glDisable(GL_DEPTH_TEST);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glEnable(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_PARTICLE]);
	
	for(int i = 0; i < particleUsage; i++)
	{

		particle[i].update(delta);

		glColor4f(	particle[i].color.x-0.16f,
					particle[i].color.y-0.16f,
					particle[i].color.z-0.16f,
					(1.0f - (float)particle[i].currentAge/(float)particle[i].maximumAge)*0.1f*(float)delta);
		
		glBegin(GL_QUADS);

			glTexCoord2d(0,0);
			glVertex3f(	particle[i].position.x - particleSize,
						particle[i].position.y - particleSize,
						particle[i].position.z);

			glTexCoord2d(1,0);
			glVertex3f( particle[i].position.x + particleSize,
						particle[i].position.y - particleSize,
						particle[i].position.z);

			glTexCoord2d(1,1);
			glVertex3f(	particle[i].position.x + particleSize,
						particle[i].position.y + particleSize,
						particle[i].position.z);

			glTexCoord2d(0,1);
			glVertex3f( particle[i].position.x - particleSize,
						particle[i].position.y + particleSize,
						particle[i].position.z);

		glEnd();
	
	}



	//
	// SOFT WIDESCREEN
	//
	
	ortho();

	glEnable(GL_BLEND);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		
	glDisable(GL_DEPTH_TEST);

	glDisable(GL_TEXTURE_2D);
	
	glBegin(GL_QUADS);

		glColor4f(0.0f, 0.0f, 0.0f, 0.1f*(float)delta);
		glVertex2d(0, 0);

		glVertex2d(800, 0);

		glColor4f(0.0f, 0.0f, 0.0f, 0.0);
		glVertex2d(800, 100);

		glVertex2d(0, 100);

		//

		glVertex2d(0, 500);

		glVertex2d(800, 500);

		glColor4f(0.0f, 0.0f, 0.0f, 0.1f*(float)delta);
		glVertex2d(800, 600);

		glVertex2d(0, 600);

	glEnd();


	//
	// FADEOUT
	//

	if(time > 22500.0)
	{
		fadeOut(2500.0, time-22500.0);
	}


	//
	// END
	//

	SwapBuffers(wglGetCurrentDC());

}