//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//

#ifndef cube_h
#define cube_h

void renderCube(float);

#endif // cube_h