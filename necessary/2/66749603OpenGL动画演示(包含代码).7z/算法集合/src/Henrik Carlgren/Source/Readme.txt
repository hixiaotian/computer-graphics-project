a64ki, by Henrik Carlgren
-------------------------
system requirements:
	opengl graphics card that can supply
	at least 2bits stencil buffer.

about the code:
	very ugly code structure... =( but it works =)

about the music:
	big thanks to zaril for the music

about the size:
	i compressed the binary with upx with the --best option
	it reduced the size to about 50%
	i only got up to 169kb because when i started it
	where supposed to be an 64kb intro but i changed my mind
	and wasted some space... if i remove the static torus & the
	high res texture 'cwl' it get below 64kb...

contact:
	ziruz@hotpop.com,
	vm00heca@skola.sundsvall.se
	or icq: 13501614

homepage:
	http://ziruz@hotpop.com