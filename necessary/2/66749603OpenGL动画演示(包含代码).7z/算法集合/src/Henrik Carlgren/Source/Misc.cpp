//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "misc.h"

#include <windows.h>

#include <gl\gl.h>

#include <gl\glu.h>



//
// FUNCTION: perspective
//

void perspective(void)
{

	glViewport(0, 0, 800, 600);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	gluPerspective(90.0f, 800.0f / 600.0f, 0.1f, 1000.0f);

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

}



//
// FUNCTION: ortho
//

void ortho(void)
{

	glViewport(0, 0, 800, 600);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	glOrtho(0, 800, 0, 600, -1, 1);

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

}

//
// FUNCTION: fadeOut
//

void fadeOut(long double length, long double current)
{
	//
	// FADE BLOCK
	//

	ortho();

	glEnable(GL_BLEND);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		
	glDisable(GL_DEPTH_TEST);

	glDisable(GL_TEXTURE_2D);

	glColor4f(0.0f, 0.0f, 0.0f, (float)(1.0f/length) * (float)current);

	glBegin(GL_QUADS);
		glVertex2i(0, 0);
		glVertex2i(0, 600);
		glVertex2i(800, 600);
		glVertex2i(800, 0);
	glEnd();

}


void calcNormal(const VECTOR &a, const VECTOR &b, const VECTOR &c, VECTOR &n)
{
	VECTOR p,q;
	float length;
	
	p.x = b.x - a.x;
	p.y = b.y - a.y;
	p.z = b.z - a.z;

	q.x = c.x - a.x;
	q.y = c.y - a.y;
	q.z = c.z - a.z;

	n.x = p.y * q.z - p.z * q.y;
	n.y = p.z * q.x - p.x * q.z;
	n.z = p.x * q.y - p.y * q.x;

	length = sqrtf(n.x*n.x + n.y*n.y + n.z*n.z);
	
	if(length == 0.0f)
		return;

	length = 1.0f / length;
	
	n.x *= length;
	n.y *= length;
	n.z *= length;
}