//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef texture_h
#define texture_h


enum
{
	TEXTURE_PARTICLE,
	TEXTURE_BG0,
	TEXTURE_BG1,
	TEXTURE_ENV0,
	TEXTURE_ENV1,
	TEXTURE_CWL0,
	TEXTURE_COUNT
};




//
// FUNCTION PROTOTYPES
//

void generateParticleTexture(void);

void generateBackground0Texture(void);

void generateBackground1Texture(void);

void generateEnv0Texture(void);

void generateEnv1Texture(void);

void generateCwl0Texture(void);

void generateTextures(void);

void uploadTexture(const unsigned char *, int, int);



#endif // texture_h