//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "funky.h"

#include "misc.h"

#include "vector.h"

#include "texture.h"

#include "cube.h"

#include <windows.h>

#include <gl\gl.h>

#include <math.h>



//
// GLOBAL VARIABLES
//

const int numCircleCoords = 192;

VECTOR circleCoords[numCircleCoords];

const float PI = 3.1415926535f;

extern GLuint texture[TEXTURE_COUNT];



//
// FUNCTION: funkyStartup
//

void funkyStartup(void)
{
	int i;
	float c,t;

	c = (2.0f*PI)/float(numCircleCoords-1.0f);

	for(i = 0; i < numCircleCoords; i++)
	{
		t = c*float(i);
		circleCoords[i].x = cosf(t);
		circleCoords[i].y = sinf(t);
		circleCoords[i].z = 0.0f;
	}
}

void funkyCleanup(void)
{
}

void funkyCycle(long double time, long double delta)
{
	VECTOR cCC[2][numCircleCoords];
	VECTOR faceNormal;
	int i,j,k,s;


	//
	// PRE
	//

	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

	for(i = 0; i < numCircleCoords; i++)
	{
			cCC[0][i].x = circleCoords[i].x;
			cCC[0][i].y = circleCoords[i].y;
			cCC[0][i].z = circleCoords[i].z;

			cCC[1][i].x = circleCoords[i].x;
			cCC[1][i].y = circleCoords[i].y;
			cCC[1][i].z = circleCoords[i].z;
	}



	//
	// BACKGROUND
	//

	ortho();

	glDisable(GL_DEPTH_TEST);

	glEnable(GL_TEXTURE_2D);
	
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ENV1]);

	//glColor4f(0.0f, 0.7f, 0.9f, 1.0f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	glBegin(GL_QUADS);

		glTexCoord2i(0, 0);
		glVertex2i(0, 0);

		glTexCoord2i(1, 0);
		glVertex2i(800, 0);

		glTexCoord2i(1, 1);
		glVertex2i(800, 600);

		glTexCoord2i(0, 1);
		glVertex2i(0, 600);

	glEnd();


	
	//
	// CUBES
	//
	
	perspective();
	glTranslatef(0.0f, 0.0f, -8.0f);
	glRotatef(float(0.01f * time), 1.0f, 0.0f, 0.0f);
	glRotatef(float(0.02f * time), 0.0f, 1.0f, 0.0f);
	glRotatef(float(0.04f * time), 0.0f, 0.0f, 1.0f);

	glColor4f(1.0f, 1.0f, 1.0f, 0.05f);
	
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	for(i = 1; i <= 12; i++)
	{
		for(j = 1; j <= 12; j++)
		{
			for(k = 1; k <= 12; k++)
			{
				glPushMatrix();
				glTranslatef(float(i-6), float(j-6), float(k-6));
					renderCube(0.3f);
				glPopMatrix();
			}
		}
	}
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);




	//
	// TUBE
	//
	
	perspective();
	glTranslatef(4.0f, -5.5f, -4.0f);
	glRotatef(75.0f, 0.0f, 1.0f, 0.0f);
	glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
	
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CWL0]);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_S, GL_SPHERE_MAP, 0);
	glTexGeni(GL_T, GL_SPHERE_MAP, 0);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	//glColor4f(9.0f, 0.7f, 0.0f, 0.25f);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLES);
	for(s = 0; s < 44; s++)
	{

		for(i = 0; i < numCircleCoords; i++)
		{
			cCC[1][i].x = cCC[0][i].x;
			cCC[1][i].y = cCC[0][i].y;
			cCC[1][i].z = cCC[0][i].z;

			cCC[0][i].x = circleCoords[i].x * (1.0f-(sinf(float(time+s*100)*0.001f)*0.5f));
			cCC[0][i].y = circleCoords[i].y * (2.0f-(sinf(float(time+s*100)*0.001f)*0.5f));
			cCC[0][i].z = circleCoords[i].z - s*0.25f;
		}
		
		for(i = 1; i < numCircleCoords; i++)
		{
			float c = 1.0f / float(numCircleCoords);


			
			//
			// Triangle 1
			//

			calcNormal(cCC[0][i - 1], cCC[1][i], cCC[1][i - 1], faceNormal);

			glNormal3f(faceNormal.x, faceNormal.y, faceNormal.z);
			
			glVertex3f(cCC[0][i - 1].x, cCC[0][i - 1].y, cCC[0][i - 1].z);
			glVertex3f(cCC[1][i].x, cCC[1][i].y, cCC[1][i].z);
			glVertex3f(cCC[1][i - 1].x, cCC[1][i - 1].y, cCC[1][i - 1].z);
		


			//
			// Triangle 2
			//

			calcNormal(cCC[0][i - 1], cCC[0][i], cCC[1][i], faceNormal);
			
			glNormal3f(faceNormal.x, faceNormal.y, faceNormal.z);
			
			glVertex3f(cCC[0][i - 1].x, cCC[0][i - 1].y, cCC[0][i - 1].z);
			glVertex3f(cCC[0][i].x, cCC[0][i].y, cCC[0][i].z);
			glVertex3f(cCC[1][i].x, cCC[1][i].y, cCC[1][i].z);
		}

	}
	glEnd();


	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_TEXTURE_2D);
	


	//
	// SOFT INTRO
	//

	if(time < 2500.0f)
	{
		fadeOut(2500.0f, 2500.0f - time);
	}


	//
	// FADEOUT
	//

	if(time > 22500.0)
	{
		fadeOut(2500.0, time-22500.0);
	}



	//
	// END
	//

	SwapBuffers(wglGetCurrentDC());
}