//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef mem_h
#define mem_h



//
// STRUCTURES
//

typedef struct
{
	int length;
	int cursor;
	void *data;
} MEM;



//
// FUNCTION PROTOTYPES
//

unsigned int memOpen(char *name);

void memClose(unsigned int handle);

int memRead(void *buffer, int size, unsigned int handle);

void memSeek(unsigned int handle, int pos, signed char mode);

int memTell(unsigned int handle);



#endif // mem_h