//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef particle_h
#define particle_h



//
// INCLUDE FILES
//

#include "vector.h"



//
// CLASS PROTOTYPES
//

class PARTICLE
{
public:
	void birth(void);
	void update(long double delta);

	long double currentAge;
	int maximumAge;
	int ageRangeMinimum;
	int ageRangeMaximum;
	VECTOR position;
	VECTOR velocity;
	VECTOR impulse;
	VECTOR color;	// red = x, green = y, blue = z
					// alpha = 1 - currentAge/maximumAge
	VECTOR *targetPosition;
	VECTOR *targetVelocity;
	VECTOR *targetImpulse;
};



#endif // particle_h