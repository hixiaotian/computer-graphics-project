//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef config_h
#define config_h



//
// DEFINES
//

#define FULLSCREEN

#define MUSIC



#endif // config_h