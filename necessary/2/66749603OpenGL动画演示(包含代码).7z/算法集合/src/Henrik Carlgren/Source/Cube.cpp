//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//

#include "cube.h"

#include <windows.h>
#include <gl\gl.h>

void renderCube(float size)
{
	glBegin(GL_QUADS);
		glVertex3f(-size,-size,-size);
		glVertex3f(-size,+size,-size);
		glVertex3f(+size,+size,-size);
		glVertex3f(+size,-size,-size);

		glVertex3f(-size,-size,+size);
		glVertex3f(-size,+size,+size);
		glVertex3f(+size,+size,+size);
		glVertex3f(+size,-size,+size);

		glVertex3f(-size,-size,-size);
		glVertex3f(-size,-size,+size);
		glVertex3f(+size,-size,+size);
		glVertex3f(+size,-size,-size);

		glVertex3f(-size,+size,-size);
		glVertex3f(-size,+size,+size);
		glVertex3f(+size,+size,+size);
		glVertex3f(+size,+size,-size);

		glVertex3f(-size,-size,-size);
		glVertex3f(-size,-size,+size);
		glVertex3f(-size,+size,+size);
		glVertex3f(-size,+size,-size);

		glVertex3f(+size,-size,-size);
		glVertex3f(+size,-size,+size);
		glVertex3f(+size,+size,+size);
		glVertex3f(+size,+size,-size);
	glEnd();
}