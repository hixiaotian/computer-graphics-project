//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//

#include <windows.h>
#include <gl\gl.h>

#include "tunnel.h"
#include "misc.h"
#include "vector.h"
#include "texture.h"
#include "cube.h"

typedef VECTOR circle32[32];

circle32 g_tunnel[512];

extern GLuint texture[TEXTURE_COUNT];

void tunnelInit(void)
{
	int i, j;

	for(i = 0; i < 512; i++)
	{
		for(j = 0; j < 32; j++)
		{
			g_tunnel[i][j].x = 0.5f * sinf(i * 0.1f) + 2.0f * cosf(((2.0f * 3.1415f) /32.0f) * j);
			g_tunnel[i][j].y = 0.5f * cosf(i * 0.3f) + 2.0f * sinf(((2.0f * 3.1415f) /32.0f) * j);
			g_tunnel[i][j].z = float(-i)*0.25f;
		}
	}
}

void tunnelCycle(int a_time, int a_delta)
{
	int i, j, k;
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BG0]);
	
	ortho();

	glColor4f(0.25f, 0.25f, 0.25f, 1.0f);
	
	glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2i(0, 0);
		
		glTexCoord2f(0, 24 + 8*sinf(a_time*0.001f));
		glVertex2i(0, 600);
		
		glTexCoord2f(12 + 4*sinf(a_time*0.001f), 24 + 8*sinf(a_time*0.001f));
		glVertex2i(800, 600);
		
		glTexCoord2f(12 + 4*sinf(a_time*0.001f), 0);
		glVertex2i(800, 0);
	glEnd();

	glDisable(GL_TEXTURE_2D);

	//
	// TUNNEL
	//

	perspective();

	glTranslatef(	0.4f * cosf(a_time*0.002f),
					0.6f * sinf(a_time*0.001f),
					64.0f + 16.0f * sinf(a_time*0.0001f));
	
	glRotatef(float(a_time)*0.1f, 0.0f, 0.0f, 1.0f);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glDisable(GL_DEPTH_TEST);

	glEnable(GL_BLEND);

	glEnable(GL_LINE_SMOOTH);

	glBegin(GL_LINE_STRIP);
	for(i = 0; i < 512; i++)
	{
		for(j = 0; j < 32; j++)
		{
			glColor4f(1.0f+sinf(i*0.1f), 0.01f*(i%100+j%10), 1.0f, 0.75f);

			glVertex3f(	g_tunnel[i][j].x,
						g_tunnel[i][j].y,
						g_tunnel[i][j].z);
		}
	}
	glEnd();

	glDisable(GL_LINE_SMOOTH);

	glDisable(GL_BLEND);

	glEnable(GL_DEPTH_TEST);




	//
	// DANCING CUBES =)
	//

	perspective();
	glTranslatef(5.0f, 3.0f, -8.0f);
	glRotatef(float(0.01f * a_time), 1.0f, 0.0f, 0.0f);
	glRotatef(float(0.02f * a_time), 0.0f, 1.0f, 0.0f);
	glRotatef(float(0.04f * a_time), 0.0f, 0.0f, 1.0f);

	glColor4f(1.0f, 1.0f, 1.0f, 0.05f);
	
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	for(i = 1; i <= 12; i++)
	{
		for(j = 1; j <= 12; j++)
		{
			for(k = 1; k <= 12; k++)
			{
				glPushMatrix();
				glTranslatef(float(i-6)*0.3f, float(j-6)*0.3f, float(k-6)*0.3f);
					renderCube(0.1f);
				glPopMatrix();
			}
		}
	}

	perspective();
	glTranslatef(2.5f*sinf(a_time*0.001f),-4.0f, -6.0f);

	glColor4f(0.0f, 0.0f, 1.0f, 0.15f);
	
	for(i = 1; i <= 32; i++)
	{
		glPushMatrix();
		glTranslatef(float(i-16)*0.75f, 0.0f, 0.0f);
		glRotatef(a_time * 0.02f, 1.0f, 0.0f, 0.0f);
		glRotatef(a_time * 0.04f, 0.0f, 1.0f, 0.0f);
		glRotatef(a_time * 0.08f, 0.0f, 0.0f, 1.0f);
			renderCube(0.5f);
		glPopMatrix();
	}

	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);


	//
	// SOFT INTRO
	//

	if(a_time < 2500.0f)
	{
		fadeOut(2500.0f, 2500.0f - a_time);
	}


	//
	// FADEOUT
	//

	if(a_time > 22500.0)
	{
		fadeOut(2500.0, a_time-22500.0);
	}


	SwapBuffers(wglGetCurrentDC());
}