//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "system.h"

#include "config.h"



//
// GLOBAL VARIABLES
//

extern HINSTANCE applicationInstance;

extern HWND windowHandle;

extern HDC deviceContext;

extern HGLRC renderContext;

extern bool running;



//
// FUNCTION: systemStartup
//
void systemStartup(void)
{
	WNDCLASS wndClass;
	DWORD style;
	PIXELFORMATDESCRIPTOR pixelFormatDescriptor;
	int i;


	//
	// Win32
	//

	for(i = 0; i < sizeof(wndClass); i++)
	{
		*(((char *)&wndClass)+i) = 0;
	}
	wndClass.lpfnWndProc = windowProcess;
	wndClass.hInstance = applicationInstance;
	wndClass.lpszClassName = "window";
	RegisterClass(&wndClass);

	#ifdef FULLSCREEN
		DEVMODE screenSettings;
		ZeroMemory(&screenSettings, sizeof(screenSettings));
		screenSettings.dmSize = sizeof(screenSettings);
		screenSettings.dmPelsWidth = 800;
		screenSettings.dmPelsHeight = 600;
		screenSettings.dmBitsPerPel = 32;
		screenSettings.dmFields = DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT|DM_DISPLAYFREQUENCY;
		ChangeDisplaySettings(&screenSettings, CDS_FULLSCREEN);
		style = WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_POPUP;
		ShowCursor(FALSE);
	#else // FULLSCREEN
		style = WS_CAPTION|WS_POPUPWINDOW|WS_VISIBLE;
	#endif // FULLSCREEN

	windowHandle = CreateWindowEx(
		WS_EX_APPWINDOW,
		"window", "a64ki",
		style,0, 0, 800, 600,
		NULL, NULL,	applicationInstance, NULL);

	ShowWindow(windowHandle, SW_SHOW);
	SetForegroundWindow(windowHandle);
	SetFocus(windowHandle);

	

	//
	// OpenGL
	//

	deviceContext = GetDC(windowHandle);
	for(i = 0; i < sizeof(wndClass); i++)
	{
		*(((char *)&pixelFormatDescriptor)+i) = 0;
	}
	pixelFormatDescriptor.nSize = sizeof(pixelFormatDescriptor);
	pixelFormatDescriptor.dwFlags = PFD_DRAW_TO_WINDOW|PFD_SUPPORT_OPENGL|PFD_DOUBLEBUFFER;
	pixelFormatDescriptor.cColorBits = 32;
	pixelFormatDescriptor.cDepthBits = 16;
	pixelFormatDescriptor.cStencilBits = 8;
	SetPixelFormat(deviceContext, ChoosePixelFormat(deviceContext, &pixelFormatDescriptor), &pixelFormatDescriptor);
	renderContext = wglCreateContext(deviceContext);
	wglMakeCurrent(deviceContext, renderContext);
}



//
// FUNCTION: systemCleanup
//
void systemCleanup(void)
{
	//
	// OpenGL
	//

	wglMakeCurrent(NULL, NULL);
	wglDeleteContext(renderContext);



	//
	// Win32
	//

	DestroyWindow(windowHandle);
	UnregisterClass("window", applicationInstance);
	ChangeDisplaySettings(NULL, 0);
	ShowCursor(TRUE);
}



//
// FUNCTION: systemCycle
//
void systemCycle(void)
{
	MSG message;

	while(PeekMessage(&message, NULL, 0, 0, PM_REMOVE))
	{

		TranslateMessage(&message);
		DispatchMessage(&message);

	}
}



//
// FUNCTION: windowProcess
//
LRESULT APIENTRY windowProcess(HWND windowHandle, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_CLOSE:
		running = false;
		break;

	case WM_QUIT:
		running = false;
		break;

	case WM_KEYDOWN:
		if(LOWORD(wParam) == VK_ESCAPE)
			running = false;
		break;

	default:
		return DefWindowProc(windowHandle, message, wParam, lParam);

	}

	return 0;
}