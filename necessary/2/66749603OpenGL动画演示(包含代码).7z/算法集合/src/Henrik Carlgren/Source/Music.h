//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef music_h
#define music_h



//
// INCLUDE FILES
//

#include "minifmod.h"



//
// FUNCTION PROTOTYPES
//

void musicStartup(void);

void musicCleanup(void);



#endif // music_h