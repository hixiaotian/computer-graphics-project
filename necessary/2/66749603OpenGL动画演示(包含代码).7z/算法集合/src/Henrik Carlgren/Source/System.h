//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef system_h
#define system_h



//
// INCLUDE FILES
//

#include <windows.h>

#include <gl\gl.h>

#include <gl\glu.h>



//
// FUNCTION PROTOTYPES
//

void systemStartup(void);

void systemCleanup(void);

void systemCycle(void);

LRESULT APIENTRY windowProcess(HWND a_hWnd, UINT message, WPARAM wParam, LPARAM lParam);



#endif // system_h