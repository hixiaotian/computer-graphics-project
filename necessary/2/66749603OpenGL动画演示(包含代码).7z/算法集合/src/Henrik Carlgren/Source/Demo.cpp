//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "demo.h"

#include "intro.h"

#include "funky.h"

#include "tunnel.h"

#include "hyper.h"

#include <windows.h>




//
// FUNCTION: demoStartup
//

void demoStartup(void)
{

	introStartup();

	funkyStartup();

	tunnelInit();

}



//
// FUNCTION: demoCleanup
//

void demoCleanup(void)
{

	introCleanup();

	funkyCleanup();

}



//
// FUNCTION: demoStartup
//

void demoCycle(long double time, long double delta)
{

	if(time < 25000.0f)
	{
		introCycle(time, delta);
	}
	else if(time < 50000.0f)
	{
		funkyCycle(time - 25000.0f, delta);
	}
	else if(time < 70000.0f)
	{
		tunnelCycle(int(time - 50000.0f), int(delta));
	}
	else if(time < 105000.0f)
	{
		hyperCycle(float(time - 70000.0f), float(delta));
	}
	else
	{
		exit(0);
	}

}