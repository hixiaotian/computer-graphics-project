//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef vector_h
#define vector_h



//
// INCLUDE FILES
//

#include <cmath>



//
// CLASS PROTOTYPES
//

class VECTOR
{
public:
	VECTOR() { }
	VECTOR(float _x, float _y, float _z) { x = _x; y = _y; z = _z; }
	float x,y,z;
};



#endif // vector_h