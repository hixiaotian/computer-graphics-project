//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "music.h"

#include "minifmod.h"

#include "mem.h"

#include "config.h"



//
// GLOBAL VARIABLES
//

extern FMUSIC_MODULE *musicModule;



//
// FUNCTION: musicStartup
//
void musicStartup(void)
{
	FSOUND_File_SetCallbacks(memOpen, memClose, memRead, memSeek, memTell);
	FSOUND_Init(44100, 0);
	musicModule = FMUSIC_LoadSong(0, 0);
}



//
// FUNCTION: musicCleanup
//
void musicCleanup(void)
{
	FMUSIC_FreeSong(musicModule);
	FSOUND_Close();
}