//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef misc_h
#define misc_h


//
// INCLUDE FILES
//

#include "vector.h"


//
// FUNCTION PROTOTYPES
//

void perspective(void);

void ortho(void);

void fadeOut(long double, long double);

void calcNormal(const VECTOR &, const VECTOR &, const VECTOR &, VECTOR &);


#endif // misc_h