//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//

#ifndef __TUNNEL_HEADER_INCLUDED__
#define __TUNNEL_HEADER_INCLUDED__

void tunnelInit(void);

void tunnelCycle(int, int);

#endif // __TUNNEL_HEADER_INCLUDED__