//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "particle.h"

#include <stdlib.h>

#include <cmath>



//
// CLASS: PARTICLE
// METHOD: birth
//

void PARTICLE::birth(void)
{

	currentAge = 0;
	
	maximumAge = rand() % (ageRangeMaximum - ageRangeMinimum + 1) + ageRangeMinimum;
	
	position = *targetPosition;

	position.x = position.x + (float)(rand() % 100 - 50)*0.002f;

	position.y = position.y + (float)(rand() % 100 - 50)*0.002f;

	position.z = position.z + (float)(rand() % 100 - 50)*0.002f;
	
	velocity = *targetVelocity;
	
	float angle = (float)(rand()%36000) / 100.0f;
	
	velocity.x = velocity.x + 0.0005f * (float)cos(angle);
	
	velocity.y = velocity.y + 0.0005f * (float)sin(angle);
	
	velocity.z = velocity.z + 0.0005f * (float)cos(angle);

	impulse = *targetImpulse;

	impulse.x += (float)(rand()%13-6)/4444.0f;

	impulse.y += (float)(rand()%13-6)/4444.0f;

	impulse.z += (float)(rand()%13-6)/4444.0f;

}



//
// CLASS: PARTICLE
// METHOD: update
//

void PARTICLE::update(long double delta)
{
	currentAge += delta;

	if(currentAge > maximumAge)
		birth();

	position.x += (velocity.x + impulse.x) * (float)delta;
	
	position.y += (velocity.y + impulse.y) * (float)delta;
	
	position.z += (velocity.z + impulse.z) * (float)delta;

	impulse.x -= (float)delta*(impulse.x/512);

	impulse.y -= (float)delta*(impulse.y/512);

	impulse.z -= (float)delta*(impulse.z/512);

}