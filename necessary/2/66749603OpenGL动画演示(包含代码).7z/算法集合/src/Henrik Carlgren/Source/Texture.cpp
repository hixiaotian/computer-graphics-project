//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "texture.h"

#include "chrome.h"

#include "cwl.h"

#include <windows.h>

#include <gl\gl.h>

#include <cmath>



double hypot(double a, double b)
{
	double t;
	if(a<0) a = -a;
	if(b<0) b = -b;
	if(a > b) {
		t = a;
		a = b;
		b = t;
	}
	if(b==0) return(0.);
	a /= b;
	return(b*sqrt(1. + a*a));
}



//
// GLOBAL VARIABLES
//

GLuint texture[TEXTURE_COUNT];



//
// FUNCTION: generateParticleTexture
//

void generateParticleTexture(void)
{

	const int size = 64;
	float k;
	unsigned char buffer[size * size * 3];
	int c;
	int i = 0;

	for(int y = 0; y < size; y++)
	{

		for(int x = 0; x < size; x++)
		{

			k = float(1.0f - hypot(x - size / 2, y - size / 2) * 2 / size);

			if (k < 0) k = 0;

			c = (int)(255.f * k * k);

			buffer[i] = buffer[i+1] = buffer[i+2] = c;

			i+=3;

		}

	}

	uploadTexture(buffer, size, TEXTURE_PARTICLE);

}



//
// FUNCTION: generateBackground0Texture
//

void generateBackground0Texture(void)
{

	const int size = 256;
	unsigned char buffer[size * size * 3];
	int x, y, i = 0;

	for(y = 0; y < size; y++)
	{

		for(x = 0; x < size; x++)
		{

			buffer[i] = buffer[i+1] = buffer[i+2] = i^y;
			
			i+=3;

		}

	}

	uploadTexture(buffer, size, TEXTURE_BG0);

}



//
// FUNCTION: generateBackground1Texture
//

void generateBackground1Texture(void)
{

	const int size = 256;
	unsigned char buffer[size * size * 3];
	int i = 0;

	for(int y = 0; y < size; y++)
	{

		for(int x = 0; x < size; x++)
		{

			buffer[i] = buffer[i+1] = buffer[i+2] = (i^x*y);

			i+=3;

		}

	}

	uploadTexture(buffer, size, TEXTURE_BG1);

}



void generateEnv0Texture(void)
{
	const int size = 256;
	float k;
	unsigned char buffer[size * size * 3];
	int c;
	int i = 0;

	for(int y = 0; y < size; y++)
	{

		for(int x = 0; x < size; x++)
		{

			k = float(1.0f - hypot(x - size / 2, y - size / 2) * 2 / size);

			if(k < 0)
				k = 0.1f;

			c = (int)(255.f * k);

			c /= 4;
			c *= 5;

			buffer[i] = buffer[i+1] = buffer[i+2] = c>255?255:c;

			i+=3;

		}

	}

	uploadTexture(buffer, size, TEXTURE_ENV0);
}



void generateEnv1Texture(void)
{
	uploadTexture(chrome, 32, TEXTURE_ENV1);
}



void generateCwl0Texture(void)
{
	uploadTexture(cwl, 128, TEXTURE_CWL0);
}



//
// FUNCTION: generateTextures
//

void generateTextures(void)
{

	glGenTextures(TEXTURE_COUNT, texture);

	generateParticleTexture();

	generateBackground0Texture();

	generateBackground1Texture();

	generateEnv0Texture();

	generateEnv1Texture();

	generateCwl0Texture();

}



//
// FUNCTION: uploadTexture
//

void uploadTexture(const unsigned char *buffer , int size, int id)
{

	glBindTexture(GL_TEXTURE_2D, texture[id]);

  	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);

  	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	
	glTexImage2D (GL_TEXTURE_2D, 0, GL_RGB, size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, buffer);

}