//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef intro_h
#define intro_h



//
// FUNCTION PROTOTYPES
//

void introStartup(void);

void introCleanup(void);

void introCycle(long double, long double);



#endif // intro_h