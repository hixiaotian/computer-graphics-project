//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef funky_h
#define funky_h



//
// FUNCTION PROTOTYPES
//

void funkyStartup(void);

void funkyCleanup(void);

void funkyCycle(long double, long double);



#endif // funky_h