//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



//
// INCLUDE FILES
//

#include "mem.h"

#include "tkno.h" // the xm music file in hex

#include <memory.h>

#include <stdio.h>



//
// FUNCTION: memOpen
//

unsigned int memOpen(char *name)
{
	MEM *mem = new MEM;
	mem->length = TKNO_LEN;
	mem->cursor = 0;
	mem->data = tkno;
	return (unsigned int)mem;
}



//
// FUNCTION: memClose
//

void memClose(unsigned int handle)
{
	delete (MEM *)handle;
}



//
// FUNCTION: memRead
//

int memRead(void *buffer, int size, unsigned int handle)
{
	if(((MEM *)handle)->cursor + size >= ((MEM *)handle)->length)
		size = ((MEM *)handle)->length - ((MEM *)handle)->cursor;
	memcpy(buffer, (char *)((MEM *)handle)->data + ((MEM *)handle)->cursor, size);
	((MEM *)handle)->cursor += size;
	return size;
}



//
// FUNCTION: memSeek
//

void memSeek(unsigned int handle, int pos, signed char mode)
{
	switch(mode)
	{
	case SEEK_SET:
		((MEM *)handle)->cursor = pos;
		break;

	case SEEK_CUR:
		((MEM *)handle)->cursor += pos;
		break;

	case SEEK_END:
		((MEM *)handle)->cursor = ((MEM *)handle)->length-1;
		break;
	default:
		return;
	}

	if(((MEM *)handle)->cursor < 0)
		((MEM *)handle)->cursor = 0;

	if(((MEM *)handle)->cursor >= ((MEM *)handle)->length)
		((MEM *)handle)->cursor = ((MEM *)handle)->length-1;
}



//
// FUNCTION: memTell
//

int memTell(unsigned int handle)
{
	return ((MEM *)handle)->cursor;
}