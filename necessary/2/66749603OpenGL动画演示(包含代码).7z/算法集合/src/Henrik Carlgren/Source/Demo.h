//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//



#ifndef demo_h
#define demo_h



//
// FUNCTION PROTOTYPES
//

void demoStartup(void);

void demoCleanup(void);

void demoCycle(long double, long double);


#endif // demo_h