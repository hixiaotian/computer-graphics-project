//
// a64ki
// Copyright (c) 2002 Henrik Carlgren
// http://ziruz.cjb.net
// ziruz@hotpop.com
//

#include <windows.h>
#include <gl\gl.h>

#include "misc.h"
#include "texture.h"
#include "vector.h"
#include "PQTorus.h"

extern GLuint texture[TEXTURE_COUNT];

void hyperCycle(float a_fTime, float a_fDelta)
{
	int i;

	a_fTime += 10000.0f;

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	glClearStencil(0);

	glClear(GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	glDisable(GL_DEPTH_TEST);

	glEnable(GL_BLEND);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// Background Layer 1
	{
		ortho();

		glEnable(GL_TEXTURE_2D);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ENV1]);

		glColor4f(1.0f, 1.0f, 1.0f, 0.1f);

		glBegin(GL_QUADS);
			glTexCoord2i(0, 0); glVertex2i(0, 0);
			glTexCoord2i(0, 1); glVertex2i(0, 600);
			glTexCoord2i(1, 1); glVertex2i(800, 600);
			glTexCoord2i(1, 0); glVertex2i(800, 0);
		glEnd();

		glDisable(GL_TEXTURE_2D);
	}

	// Background Layer 2
	{
		ortho();

		glMatrixMode(GL_TEXTURE);
		glPushMatrix();

		glLoadIdentity();

		glTranslatef(a_fTime * 0.00005f, a_fTime * 0.0001f, 0.0f);
		
		glRotatef(sinf(a_fTime * 0.001f) * a_fTime * 0.002f, 0.0f, 0.0f, 1.0f);

		glEnable(GL_TEXTURE_2D);

		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ENV1]);

		glColor4f(1.0f, 1.0f, 1.0f, 0.003f + 0.002f * cosf(a_fTime * 0.0003f));

		glBegin(GL_QUADS);
			glTexCoord2i(0, 0); glVertex2i(0, 0);
			glTexCoord2i(0, 1); glVertex2i(0, 600);
			glTexCoord2i(1, 1); glVertex2i(800, 600);
			glTexCoord2i(1, 0); glVertex2i(800, 0);
		glEnd();

		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glDisable(GL_TEXTURE_2D);

		glPopMatrix();
		glMatrixMode(GL_MODELVIEW);
	}

	// Background Layer 3
	{
		ortho();

		glMatrixMode(GL_TEXTURE);
		glPushMatrix();

		glLoadIdentity();

		glTranslatef(-a_fTime * 0.00002f,-a_fTime * 0.0002f, 0.0f);
		
		glRotatef(sinf(a_fTime * 0.0004f) * a_fTime * 0.001f, 0.0f, 0.0f, 1.0f);

		glEnable(GL_TEXTURE_2D);

		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ENV1]);

		glColor4f(1.0f, 1.0f, 1.0f, 0.001f + 0.001f * sinf(a_fTime * 0.0001f));

		glBegin(GL_QUADS);
			glTexCoord2i(0, 0); glVertex2i(0, 0);
			glTexCoord2i(0, 20); glVertex2i(0, 600);
			glTexCoord2i(20, 20); glVertex2i(800, 600);
			glTexCoord2i(20, 0); glVertex2i(800, 0);
		glEnd();

		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glDisable(GL_TEXTURE_2D);

		glPopMatrix();
		glMatrixMode(GL_MODELVIEW);
	}
	
	// PQTorus
	{
		static VECTOR oPosition(1024.0f, 0.0f, -96.0f);
		static VECTOR oRotation;
		float fStencilLine1 = 0.0f;
		float fStencilLine2 = 0.0f;

		if(a_fTime >= 15000.0f)
		{
			fStencilLine1 = 0.05f * (a_fTime - 15000.0f);
		}

		if(a_fTime >= 20000.0f)
		{
			fStencilLine2 = 0.05f * (a_fTime - 20000.0f);
		}
		
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_STENCIL_TEST);

		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);

		ortho();

		glStencilOp(GL_KEEP, GL_INCR, GL_INCR);
		glStencilMask(0xff);
		glStencilFunc(GL_ALWAYS, 0x0, 0xff);

		glColor4f(0.0f, 0.0f, 0.0f, 0.1f);

		glBegin(GL_QUADS);
			glVertex2i(0, 0);
			glVertex2i(0, int(fStencilLine1));
			glVertex2i(800, int(fStencilLine1));
			glVertex2i(800, 0);
		glEnd();

		glBegin(GL_QUADS);
			glVertex2i(0, 0);
			glVertex2i(0, 600);
			glVertex2i(int(fStencilLine2), 600);
			glVertex2i(int(fStencilLine2), 0);
		glEnd();

		perspective();

		glTranslatef(oPosition.x, oPosition.y, oPosition.z);

		if(a_fTime <= 15000.0f)
		{
			oPosition.x = 1024.0f - (1000.0f / 15000.0f) * a_fTime;
		}
		else
		{
			oPosition.x = 24.0f + 8.0f * sinf(a_fTime * 0.004f);
		}

		oPosition.y = 8.0f * sinf(a_fTime * 0.006f);

		if(a_fTime >= 10000.0f)
		{
			float fSmoothSpeed;

			if(a_fTime <= 20000.0f)
			{
				fSmoothSpeed = ( 1.0f / 10000.0f ) * ( a_fTime - 10000.0f );
			}
			else
			{
				fSmoothSpeed = 1.0f;
			}

			glRotatef(oRotation.x * fSmoothSpeed, 1.0f, 0.0f, 0.0f);
			glRotatef(oRotation.y * fSmoothSpeed, 0.0f, 1.0f, 0.0f);
			glRotatef(oRotation.z * fSmoothSpeed, 0.0f, 0.0f, 1.0f);

			oRotation.x += a_fDelta * 0.1f;
			oRotation.y += a_fDelta * 0.2f;
			oRotation.z += a_fDelta * 0.1f;
		}

		glEnable(GL_TEXTURE_2D);
		
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CWL0]);

		glColor4f(1.0f, 1.0f, 1.0f, 0.1f);

		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

		glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
		glStencilMask(0xff);
		glStencilFunc(GL_EQUAL, 0x0, 0xff);

		glBegin(GL_TRIANGLES);
		for(i = 0; i < sizeof(PQTorus_vidx)/sizeof(long); i++)
		{
			glNormal3d( PQTorus_normal[ PQTorus_nidx[i] ].x,
						PQTorus_normal[ PQTorus_nidx[i] ].y,
						PQTorus_normal[ PQTorus_nidx[i] ].z);
				
			glVertex3d(	PQTorus_vertex[ PQTorus_vidx[i] ].x,
						PQTorus_vertex[ PQTorus_vidx[i] ].y,
						PQTorus_vertex[ PQTorus_vidx[i] ].z);
		}
		glEnd();

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

		glStencilFunc(GL_EQUAL, 0x1, 0xff);

		glBegin(GL_TRIANGLES);
		for(i = 0; i < sizeof(PQTorus_vidx)/sizeof(long); i++)
		{
			glNormal3d( PQTorus_normal[ PQTorus_nidx[i] ].x,
						PQTorus_normal[ PQTorus_nidx[i] ].y,
						PQTorus_normal[ PQTorus_nidx[i] ].z);
				
			glVertex3d(	PQTorus_vertex[ PQTorus_vidx[i] ].x,
						PQTorus_vertex[ PQTorus_vidx[i] ].y,
						PQTorus_vertex[ PQTorus_vidx[i] ].z);
		}
		glEnd();

		glStencilFunc(GL_EQUAL, 0x2, 0xff);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ENV1]);

		glBegin(GL_TRIANGLES);
		for(i = 0; i < sizeof(PQTorus_vidx)/sizeof(long); i++)
		{
			glNormal3d( PQTorus_normal[ PQTorus_nidx[i] ].x,
						PQTorus_normal[ PQTorus_nidx[i] ].y,
						PQTorus_normal[ PQTorus_nidx[i] ].z);
				
			glVertex3d(	PQTorus_vertex[ PQTorus_vidx[i] ].x,
						PQTorus_vertex[ PQTorus_vidx[i] ].y,
						PQTorus_vertex[ PQTorus_vidx[i] ].z);
		}
		glEnd();

		glDisable(GL_TEXTURE_2D);

		glDisable(GL_STENCIL_TEST);
		glDisable(GL_TEXTURE_GEN_T);
		glDisable(GL_TEXTURE_GEN_S);
	}

	glDisable(GL_BLEND);

	glEnable(GL_DEPTH_TEST);

	//
	// SOFT INTRO
	//

	if(a_fTime < 12500.0f)
	{
		fadeOut(2500.0f, 12500.0f - a_fTime);
	}


	SwapBuffers(wglGetCurrentDC());
}