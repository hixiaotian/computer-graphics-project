Hello, 
I hope u like this demo. It was my first ! :o)
All is written with Visual C++ 6.

Info about the code :
Bug, Bug, Bug, Bug, Bug :o)
I got some probleme with in debug mode with delete and free() fonction  (dbgdel.cpp error ?)

Thanx To all the coder for ur source,
fmod, nvidia, nehe :), Jan Horn, and all other...

Contact me :

axl@naskel.com
 
 


Dir tree :
---------�

|-- Naskel3D.dsp
|-- Naskel3D.dsw		
|-- data
|   `-- data.npk
|-- lib
|   |-- GlAux.Lib
|   |-- ftol2.obj
|   |-- jpeg.lib
|   |-- minifmod.lib
|   |-- unzip - readme.txt
|   |-- unzip.lib
|   `-- util.lib
|-- main.cpp				
|-- main.h
|-- readme.txt
|-- src
|   |-- 3d_intro.h
|   |-- Camera.cpp
|   |-- NaskelClass.cpp
|   |-- NaskelClass.h
|   |-- Star
|   |   |-- starwars.cpp
|   |   `-- starwars.h
|   |-- Water
|   |   |-- water.cpp
|   |   `-- water.h
|   |-- camera.h
|   |-- cyl.cpp
|   |-- fly
|   |   |-- fly.cpp
|   |   `-- fly.h
|   |-- keyb.h
|   |-- matrix
|   |   |-- Core.cpp
|   |   |-- Core.h
|   |   |-- Init.cpp
|   |   |-- Rendering.cpp
|   |   |-- Rendering.h
|   |   |-- main.cpp
|   |   |-- main.h
|   |   |-- resource.h
|   |   |-- sliding.cpp
|   |   `-- sliding.h
|   |-- moving
|   |   |-- img_slide.cpp
|   |   |-- img_slide.h
|   |   |-- moving.cpp
|   |   `-- moving.h
|   |-- ogl
|   |   |-- ogl.cpp
|   |   `-- ogl.h
|   |-- sliding
|   |   |-- sliding.cpp
|   |   `-- sliding.h
|   `-- unzip
|       |-- Unzip.dsp
|       |-- Unzip.dsw
|       `-- src
|           |-- bass.h
|           |-- bassmod.h
|           |-- minifmod.h
|           |-- unzip.cpp
|           |-- unzip.h
|           |-- utils_unzip.h
|           |-- utils_util.cpp
|           |-- utils_util.h
|           |-- zconf.h
|           |-- zlib.h
|           `-- zutil.h
`-- upx.exe