// Include
// disable: truncation from 'double' to 'float'
#pragma warning (disable : 4305)
// disable: conversion from 'double' to 'float', possible loss of data
#pragma warning (disable : 4244)

#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ocidl.h>
#include <olectl.h>
#include <mmsystem.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <direct.h>
#include <time.h>
#include <gl\gl.h>										
#include <gl\glu.h>	
#include <gl\glaux.h>									
#include "src/unzip/src/utils_unzip.h"
#include "src/unzip/src/utils_util.h"
#include "src/naskelclass.h"
//#include "src/Particle.h"
#include "src/ogl/ogl.h"
#include "src/camera.h"
#include "src/water/water.h"
#include "src/sliding/sliding.h"
#include "src/star/starwars.h"
#include "src/moving/moving.h"
#include "src/moving/img_slide.h"
#include "src/fly/fly.h"


// Libs
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "Winmm.lib")
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "lib/glaux.lib")
#pragma comment(lib, "lib/minifmod.lib")
// If u want to use bassmod, but u need the .dll
// look at the util tools (src/unzip/)
//#pragma comment(lib, "lib/bassmod.lib")
#pragma comment(lib, "lib/util.lib")
#pragma comment(lib, "lib/unzip.lib")
#pragma comment(lib, "lib/jpeg.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")

// Define
//#define __RELEASE_NASKEL3D
#define SCREEN_WIDTH 800								
#define SCREEN_HEIGHT 600								
#define SCREEN_DEPTH 32	

// Ready to Final Release !! yeah =))
#define __FINAL

#ifndef __FINAL
// Only debug if non final..
#define __DEBUG
#endif


// Setting
extern float StartTime;

// Proc. Def.
