// Main Include
#include "main.h"
#include "src/keyb.h"


// Main Setting
bool  g_bFullScreen = FALSE;								
HWND  g_hWnd;											
RECT  g_rRect;											
HDC   g_hDC;											
HGLRC g_hRC;											
HINSTANCE g_hInstance;	
Naskel3D Naskel;								
CCamera			objCamera; 
GLdouble	mouse_x, mouse_y;
GLdouble	mouse_3d_x, mouse_3d_y;
POINT MouseDownPoint;

// Main Definition
LRESULT CALLBACK	WinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
void			RenderScene();

int seq = 0;
int num_water=6;
int key_move[4];

bool GotNextScene = false;
float m_Z=-0.5f;

float StartTime=0.0f;
bool bukey = false;
bool bdkey = false;

extern float cubeH;

void ChangeToFullScreen()
{
	DEVMODE dmSettings;									
	memset(&dmSettings,0,sizeof(dmSettings));			
	
	if(!EnumDisplaySettings(NULL,ENUM_CURRENT_SETTINGS,&dmSettings)) {
		MessageBox(NULL, "Could Not Enum Display Settings", "Error", MB_OK);
		return;
	}

	dmSettings.dmPelsWidth	= SCREEN_WIDTH;				
	dmSettings.dmPelsHeight	= SCREEN_HEIGHT;			
	
	int result = ChangeDisplaySettings(&dmSettings,CDS_FULLSCREEN);	
	
	if(result != DISP_CHANGE_SUCCESSFUL) {
		MessageBox(NULL, "Display Mode Not Compatible", "Error", MB_OK);
		PostQuitMessage(0);
	}
}

HWND CreateMyWindow(LPSTR strWindowName, int width, int height, DWORD dwStyle, bool bFullScreen, HINSTANCE hInstance)
{
	HWND hWnd;
	WNDCLASS wndclass;
	
	memset(&wndclass, 0, sizeof(WNDCLASS));				
	wndclass.style = CS_HREDRAW | CS_VREDRAW;			
	wndclass.lpfnWndProc = WinProc;						
	wndclass.hInstance = hInstance;						
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);	
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);		
	wndclass.hbrBackground = (HBRUSH) (COLOR_WINDOW+1);	
	wndclass.lpszClassName = "Naskel3D";			

	RegisterClass(&wndclass);							
	
	if(bFullScreen && !dwStyle) {										
		dwStyle = WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
		ChangeToFullScreen();							
		ShowCursor(FALSE);								
	}
	else if(!dwStyle)									
		dwStyle = WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	
	g_hInstance = hInstance;							

	RECT rWindow;
	rWindow.left	= 0;								
	rWindow.right	= width;							
	rWindow.top	    = 0;								
	rWindow.bottom	= height;							

	AdjustWindowRect( &rWindow, dwStyle, false);		

	hWnd = CreateWindow("Naskel3D", strWindowName, dwStyle, 0, 0,
						rWindow.right  - rWindow.left, rWindow.bottom - rWindow.top, 
						NULL, NULL, hInstance, NULL);

	if(!hWnd) return NULL;								

	ShowWindow(hWnd, SW_SHOWNORMAL);					
	UpdateWindow(hWnd);									

	SetFocus(hWnd);										

	return hWnd;
}

WPARAM MainLoop()
{
	MSG msg;

	while(1) {													
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) { 
			if(msg.message == WM_QUIT)					
				break;
        	    TranslateMessage(&msg);						
        	    DispatchMessage(&msg);						
        	} else {
        		RenderScene();
        	} 
	}

	return(msg.wParam);									
}

bool bSetupPixelFormat(HDC hdc) 
{ 
    PIXELFORMATDESCRIPTOR pfd; 
    int pixelformat; 
 
    pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);			
    pfd.nVersion = 1;									
														
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER; 
    pfd.dwLayerMask = PFD_MAIN_PLANE;					
    pfd.iPixelType = PFD_TYPE_RGBA;						
    pfd.cColorBits = SCREEN_DEPTH;						
    pfd.cDepthBits = SCREEN_DEPTH;						
    pfd.cAccumBits = 0;									
    pfd.cStencilBits = 0;								
 
    if ( (pixelformat = ChoosePixelFormat(hdc, &pfd)) == FALSE ) 
    { 
        MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK); 
        return FALSE; 
    } 
 
    if (SetPixelFormat(hdc, pixelformat, &pfd) == FALSE) 
    { 
        MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK); 
        return FALSE; 
    } 
 
    return TRUE;										
}

void SizeOpenGLScreen(int width, int height)			
{
	if (height==0)										
	{
		height=1;										
	}

	glViewport(0,0,width,height);						

	glMatrixMode(GL_PROJECTION);						
	glLoadIdentity();									
				  
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height, 1 ,150.0f);

	glMatrixMode(GL_MODELVIEW);							
	glLoadIdentity();									
}

void InitializeOpenGL(int width, int height) 
{
}

void Init(HWND hWnd)
{
	g_hWnd = hWnd;										
	GetClientRect(g_hWnd, &g_rRect);					
	InitializeOpenGL(g_rRect.right, g_rRect.bottom);
	
	g_hDC = GetDC(g_hWnd);								
														
	if (!bSetupPixelFormat(g_hDC))						
		PostQuitMessage (0);							

	g_hRC = wglCreateContext(g_hDC);					
	wglMakeCurrent(g_hDC, g_hRC);						

	SizeOpenGLScreen(g_rRect.right, g_rRect.bottom);					

	// Naskel Init
	Naskel.InitAllScene();
}

void RenderScene() 
{
	// Naskel Render All Scene here..
	Naskel.DrawAllScene();

	SwapBuffers(g_hDC);									
}

void DeInit()
{
	if (g_hRC)											
	{
		wglMakeCurrent(NULL, NULL);						
		wglDeleteContext(g_hRC);						
	}
	
	if (g_hDC) 
		ReleaseDC(g_hWnd, g_hDC);						
		
	if(g_bFullScreen)									
	{
		ChangeDisplaySettings(NULL,0);					
		ShowCursor(TRUE);								
	}

	UnregisterClass("Naskel3D", g_hInstance);
	
	sliding::UnloadLevel();
	sliding::KillFont();
	//mods2::Free();
	Naskel.Destroy3DFont();

	PostQuitMessage (0);								
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprev, PSTR cmdline, int ishow)
{	
	HWND hWnd;
	
	#ifndef __DEBUG
	if(MessageBox(NULL, "Click Yes to go to full screen", "Options", MB_YESNO | MB_ICONQUESTION) == IDYES)
		g_bFullScreen = TRUE;
	#endif
	
	hWnd = CreateMyWindow("Naskel3D", SCREEN_WIDTH, SCREEN_HEIGHT, 0, g_bFullScreen, hInstance);
	
	if(hWnd == NULL) return TRUE;
	
	Init(hWnd);													
	
	return MainLoop();						
}

LRESULT CALLBACK WinProc(HWND hWnd,UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    LONG    lRet = 0; 
    PAINTSTRUCT    ps;

    switch (uMsg)
	{ 
	case WM_SIZE:										
		if(!g_bFullScreen)								
		{												
			SizeOpenGLScreen(LOWORD(lParam),HIWORD(lParam));
			GetClientRect(hWnd, &g_rRect);				
		}
        break; 
 
	case WM_PAINT:										
		BeginPaint(hWnd, &ps);							
		EndPaint(hWnd, &ps);							
		break;

	case WM_KEYDOWN:
//		if (bdkey) return true;
		 bdkey = true;
		 bukey = false;
		 
		switch (wParam) {
			case VK_ESCAPE:
				DeInit();
			break;
#ifdef __DEBUG
			
			case VK_UP:	key_move[0] = 0;	break;
			case VK_DOWN:	key_move[1] = 0;	break;
			case VK_LEFT:	key_move[2] = 0;	break;
			case VK_RIGHT:	key_move[3] = 0;	break;
			case KEY_w:	m_Z -=	1.1f;		break;
			case KEY_x:	m_Z +=	1.1f;		break;
			
			case VK_SPACE: {
				// Dump Camera
				float PosX = objCamera.mPos.x, PosY = objCamera.mPos.y, PosZ = objCamera.mPos.z;
				float ViewX = objCamera.mView.x, ViewY = objCamera.mView.y, ViewZ = objCamera.mView.z; 
	
				FILE *f = fopen("camera.log", "a");
				if (f) fprintf(f, "%0.2f, %0.2f,%0.2f, ", PosX, PosY, PosZ);
				if (f) fprintf(f, "%0.2f, %0.2f, %0.2f, ", ViewZ, ViewY, ViewZ); 
				if (f) fprintf(f, "%0.2f, %0.2f, %0.2f", objCamera.mUp.x, objCamera.mUp.y, objCamera.mUp.z); 
				fclose(f);
				GotNextScene = true;
			}
			break;
			case KEY_a: objCamera.mPos.y +=0.1;	break;
			case KEY_z: objCamera.mPos.y -=0.1;	break;
			case KEY_e: cubeH +=0.1f;		break;
			case KEY_r: cubeH -=0.1f;		break;
			case KEY_t: num_water = 4;		break;
			case KEY_y: num_water = 5;		break;
			case KEY_u: num_water = 6;		break;
			case KEY_i: num_water = 7;		break;
#endif
		}		
	break;

#ifdef __DEBUG
	case WM_KEYUP:
//		if (bukey) return true;
		 bukey = true;
		 bdkey = false;
		switch (wParam) {
			case VK_UP:	key_move[0] = 1;	break;
			case VK_DOWN:	key_move[1] = 1;	break;
			case VK_LEFT:	key_move[2] = 1;	break;
			case VK_RIGHT:	key_move[3] = 1;	break;
		}		
	break;
	
		case WM_LBUTTONUP: {
			MouseDownPoint.x = 0; MouseDownPoint.y = 0;
			ReleaseCapture();
		}
		break;
		case WM_LBUTTONDOWN: {
			int xPos = LOWORD(lParam); int yPos = HIWORD(lParam);
			MouseDownPoint.x = xPos; MouseDownPoint.y = yPos;
			SetCapture(hWnd);
		}
		break;
		
		case WM_MOUSEMOVE: {
			int xPos = LOWORD(lParam); int yPos = HIWORD(lParam);
			if (GetCapture()) {
				objCamera.MouseMove();
				mouse_x+=double(yPos-MouseDownPoint.y)/3.6;
				mouse_y+=double(xPos-MouseDownPoint.x)/3.6;
				MouseDownPoint.x = xPos; MouseDownPoint.y = yPos;
			}
		}
		break;
#endif
 
	case WM_DESTROY:									
	        DeInit();										
        break; 
     
	default:											
	        lRet = DefWindowProc (hWnd, uMsg, wParam, lParam); 
	break; 
    } 
 
    return lRet;										
}