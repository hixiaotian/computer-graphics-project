#include "main.h"
#include "rendering.h"

GLfloat fMove=0;
GLfloat rot=0;
BYTE map[50][41];
GLfloat brmap[50][41];
GLint nmap[50][41];
GLuint speedmap[50][2];

UINT Tick1=0, Tick2=0;   // used to help keep speed constant
UINT DTick;



