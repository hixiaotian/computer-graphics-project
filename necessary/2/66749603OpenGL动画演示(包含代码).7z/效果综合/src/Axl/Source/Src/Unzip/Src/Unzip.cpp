#ifndef __utils_util_h__
#include "utils_util.h"
#endif

#ifndef _unz_H
#define CASESENSITIVITYDEFAULT_NO
#include "unzip.h"
#endif // _unz_H

namespace unzip
{
  
    unsigned char * open(const char * filename, const char * inzipfile, unsigned int * size)
    {
	    char filename_inzip[256];
        int err=UNZ_OK;
        unsigned char * buf;
        unzFile uf=NULL;
        char pathname[MAX_PATH];

        if (utils_util::findfile(filename, MAX_PATH, pathname) == 0)
            return NULL;

        uf = unzOpen(pathname);


        if (unzLocateFile(uf,inzipfile,0)!=UNZ_OK) //CASESENSITIVITY
        {
            printf("file %s not found in the %s zipfile\n",inzipfile,pathname );
            return NULL;
        }

        unz_file_info file_info;

        err = unzGetCurrentFileInfo(uf,&file_info,filename_inzip,sizeof(filename_inzip),NULL,0,NULL,0);

	    if (err!=UNZ_OK)
	    {
		    printf("error %d with zipfile in unzGetCurrentFileInfo\n",err);
		    return NULL;
	    }

  
  	    err = unzOpenCurrentFile(uf);
	    if (err!=UNZ_OK)
	    {
		    printf("error %d with zipfile in unzOpenCurrentFile\n",err);
            return NULL;
	    }

        *size = file_info.uncompressed_size;
        buf = new unsigned char[file_info.uncompressed_size];

        unsigned int count = 0;
        err = 1;
        while (err > 0)
        {
            err = unzReadCurrentFile(uf,&buf[count],65535);
	        if (err<0)	
	        {
		        printf("error %d with zipfile in unzReadCurrentFile\n",err);
                break;
	        }
            else
                count += err;
        }
//        assert(count == file_info.uncompressed_size);
        if (err==UNZ_OK)
        {
		    err = unzCloseCurrentFile (uf);
		    if (err!=UNZ_OK)
		    {
			    printf("error %d with zipfile in unzCloseCurrentFile\n",err);
		    }
        }
        else
        {
            *size = 0;
            delete [] buf;
            buf = NULL;
            unzCloseCurrentFile(uf); /* don't lose the error */       
        }

        return buf;
    }

} // namespace unzip
