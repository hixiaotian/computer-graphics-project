
namespace fly
{
	void	Draw();
	void	BackGround();	
}