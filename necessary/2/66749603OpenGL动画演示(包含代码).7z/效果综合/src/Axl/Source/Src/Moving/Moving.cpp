#include "../../main.h"


extern float		m_Z;
GLUquadricObj		*Quad;
extern NIMG			Moving,Chrome;
float				Angle=0.0f;
bool				Init = true;
float				X = 0.0;
bool 				TimeRec = false;
extern NSCENE	 	NScene[NUM_SCENE];
extern Naskel3D		Naskel;
 
namespace moving
{

void Draw()
{
	glPushMatrix();
	
	float time = timeGetTime()*0.001f;
	glPushMatrix();
	if (Init) {
             
		Amiga::init();
		
		
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(165.0f, 4/3, 0.001f, 100.0f); 
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		Init = false;
	}

	glTranslatef(0, 0, -6);
	
  
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE); 
	glEnable(GL_TEXTURE_2D);
	glTranslatef(0, 0, 5);
	
	glRotatef(Angle/2,1.0,0.0,0.0);
	glRotatef(Angle/3,0.0,1.0f,0.0);

	glBindTexture(GL_TEXTURE_2D, Moving.ID);
	glBegin(GL_QUADS);
	  // Front Face
	  glNormal3f( 0.0, 0.0, 1.0f);
	  glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
	  glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
	  glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
	  glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
	  // Back Face
	  glNormal3f( 0.0f, 0.0f,-1.0f);
	  glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
	  glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
	  glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
	  glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
	  // Top Face
	  glNormal3f( 0.0f, 1.0f, 0.0f);
	  glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
	  glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
	  glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
	  glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
	  // Bottom Face
	  glNormal3f( 0.0f,-1.0f, 0.0f);
	  glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
	  glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
	  glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
	  glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
	  // Right face
	  glNormal3f( 1.0f, 0.0f, 0.0f);
	  glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
	  glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
	  glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
	  glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
	  // Left Face
	  glNormal3f(-1.0f, 0.0f, 0.0f);
	  glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
	  glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
	  glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
	  glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
	glEnd();

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	
	glPopMatrix();

	// Le rectangle blanc // 116.03
	if (TimeRec!=true && time>95)
		TimeRec=true;
		
	if (TimeRec) {
		// On remet la projection... 
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(0.0f, 2.0, 0.0f, 0.0f); 
		glMatrixMode(GL_MODELVIEW);         // Return to the modelview matrix
		glLoadIdentity();

		glPushMatrix();
		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glColor3f(1.0, 1.0, 1.0);

		glScalef(X, X, 1);
		glTranslatef(0.0,0.0, 0.7);
		X +=0.005;
		
		if (X >=1) {
			X =1;
			glDisable(GL_TEXTURE_2D);
			glPushMatrix();
				glTranslatef(0.0f, 0.0f, 0.7);

				Amiga::Draw();
			glPopMatrix();
			glDisable(GL_TEXTURE_2D);
			Naskel.glDrawText(300, 450,"In memory of my dead Amiga ;o)");
		}

		// Rectangle 
		glDisable(GL_TEXTURE_2D);
		glLineWidth(3);
		glBegin(GL_LINE_LOOP);
			glVertex3f(0.6, -0.3, 0.01);
			glVertex3f( 0.2, -0.3, 0.01);
			glVertex3f( 0.2,  0.3, 0.01);
			glVertex3f(0.6,  0.3, 0.01);
		glEnd();

		glPopMatrix();
	}
	Angle+=1.9f;
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(165.0, 4/3, 0.001, 100.0);  // Do the perspective calculations. Last value = max clipping depth
	glMatrixMode(GL_MODELVIEW);         // Return to the modelview matrix
	glLoadIdentity();
	
	
	glLoadIdentity();
} // End Draw()  


} // end namespace