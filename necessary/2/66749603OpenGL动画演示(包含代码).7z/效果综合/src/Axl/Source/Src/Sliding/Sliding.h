

namespace sliding
{
	void Init();
	void UnloadLevel(void);
	void LoadLevel(void);
	void ProcessLevel(void);
	void UnloadLevelTextures(void);
	void LoadLevelTextures(void);
	void RenderLevelScene(void);
	GLvoid BuildFont(GLvoid);
	GLvoid glSetChar(unsigned char ch);
	GLvoid KillFont(GLvoid);	
}