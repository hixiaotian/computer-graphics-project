#include "../../main.h"


typedef struct _tagVECT
{
  float x;
  float y;
  float z;
} VECT;

typedef struct _tagTDPOINT
{
  float x;
  float y;
  float z;
} TDPOINT,*LPTDPOINT;

typedef struct _tagSTAR
{
  TDPOINT m_start;
  VECT speed;
  float m_curPos[3]; // a float[], so we can call glVertex3fv
  float m_fColor[3];
  float timeOffset;
} STAR,*LPSTAR;

#define EYE_Z 3.0f


float m_fStarSpeed;
float m_fTimeElapsed;
int m_iNumStars;
bool m_bStarted;
bool m_bPointStars;
bool m_bMultiSample;

LPSTAR m_pStars;
LARGE_INTEGER m_start;
LARGE_INTEGER m_starStart;
LARGE_INTEGER m_freq;
  

namespace Star 
{
// Returns a random number between min and max
float GetRandom(float min,float max)
{
  float random = float(rand())/float(RAND_MAX);
  return (min + ((max-min)*random));
} 
void InitStars()
{
  m_bStarted = false;
  m_bMultiSample = false;
  m_fStarSpeed = 10.0f;
  m_iNumStars = 100;
  m_bPointStars = false;
  m_pStars = new STAR[100];

  QueryPerformanceFrequency(&m_freq);
  
  srand(GetTickCount());

  for (int i=0;i<m_iNumStars;++i)
  {
	m_pStars[i].m_start.x = GetRandom(-5.0,5.0);
	m_pStars[i].m_start.y = GetRandom(-5.0,5.0);
	m_pStars[i].m_start.z = GetRandom(-10.0,1.0);

	m_pStars[i].speed.x = 0.0;
	m_pStars[i].speed.y = 0.0;
	m_pStars[i].speed.z = m_fStarSpeed;

	// 80% of the stars are white.  The rest are yellowish - redish
#define PERCENTAGE_WHITE 0.8f
	m_pStars[i].m_fColor[0] = 1.0;
	if (GetRandom(0.0,1.0) > PERCENTAGE_WHITE)
	{
	  // make it a colorful star
	  m_pStars[i].m_fColor[1] = GetRandom(0.5,1.0);
	  m_pStars[i].m_fColor[2] = 0.0;
	}
	else
	{
	  // make it white
	  m_pStars[i].m_fColor[1] = 1.0;
	  m_pStars[i].m_fColor[2] = 1.0;
	}

	m_pStars[i].timeOffset = 0.0f;
  }
}

/* Idle function.  Moves the text/stars using the current time */
void Render()
{
  LARGE_INTEGER now;

  // get current time
  QueryPerformanceCounter(&now);

  m_fTimeElapsed = ((float)(now.QuadPart - m_start.QuadPart)/(float)m_freq.QuadPart);

  // move the stars, calculate new time based on star m_start time
  m_fTimeElapsed = ((float)(now.QuadPart - m_starStart.QuadPart)/(float)m_freq.QuadPart);
  for (int i=0;i<m_iNumStars;++i)
  {
	// update their z position
	m_pStars[i].m_curPos[2] = m_pStars[i].m_start.z + m_pStars[i].speed.z * (m_fTimeElapsed - m_pStars[i].timeOffset);
	// ok they're out of view, respawn a new star
	if (m_pStars[i].m_curPos[2] >= EYE_Z)
	{
	  m_pStars[i].m_start.x = GetRandom(-5.0,5.0);
	  m_pStars[i].m_start.y = GetRandom(-5.0,5.0);
	  m_pStars[i].m_start.z = -10.0f;
	  m_pStars[i].timeOffset = m_fTimeElapsed;
	}
	else
	{
	  m_pStars[i].m_curPos[0] = m_pStars[i].m_start.x;
	  m_pStars[i].m_curPos[1] = m_pStars[i].m_start.y;
	}
  }
}

/* Method to actually draw on the control */
void vDraw()
{
	Render();
  
	glDisable(GL_BLEND);

	// now draw stars - as points
	glBegin(GL_POINTS);
	for (int i=0;i<m_iNumStars;++i)
	{
	  glColor3fv(m_pStars[i].m_fColor);
	  glVertex3fv(m_pStars[i].m_curPos);
	}
	glEnd();

}

}