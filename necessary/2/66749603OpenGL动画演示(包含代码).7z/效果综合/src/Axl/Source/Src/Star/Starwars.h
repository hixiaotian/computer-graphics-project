
namespace Star
{
  void Render();
  void vDraw();
  float GetRandom(float min,float max);
  void InitStars();
  
}