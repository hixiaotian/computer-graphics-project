#ifndef _CORE_H
#define _CORE_H


extern BYTE map[50][41];
extern GLfloat brmap[50][41];
extern GLint nmap[50][41];
extern GLuint speedmap[50][2];
extern int nUpPoint;
extern GLfloat fMove;
extern GLfloat rot;


void gcUnloadLevel(void);
void gcLoadLevel(void);
void gcProcessLevel(void);

#endif