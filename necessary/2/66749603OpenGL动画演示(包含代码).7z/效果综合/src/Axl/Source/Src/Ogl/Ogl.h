
namespace ogl
{

	void Init();
	void Draw();
	void Animate();
	void SetCamera();
	void randomize(void);
	void Reset();	
}