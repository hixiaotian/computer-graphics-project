#include "../../main.h"

#define RADIUS		 0.05
#define STEP_LONGITUDE	 22.5		/* 22.5 makes 8 bands like original Boing */
#define STEP_LATITUDE	 22.5

#define DIST_BALL		(RADIUS * 10 + RADIUS+10 * 0.1)

#define BOUNCE_HEIGHT	(RADIUS * 101.1)
#define BOUNCE_WIDTH	(RADIUS * 10.1)

#define WALL_L_OFFSET	-4.95
#define WALL_R_OFFSET	5.2

///// A virer
#define GRID_SIZE	(RADIUS * 6.5)			/* length (width) of grid */
#define SHADOW_OFFSET_X	-6.0
#define SHADOW_OFFSET_Y	 6.0
#define SHADOW_OFFSET_Z   0.0

#define RGB_BROWN		0.7,	0.35,	0.2
#define RGB_GRAY		0.55,	0.55,	0.55
#define RGB_GREEN		0.05,	0.9,	0.05
#define RGB_PURPLE		0.6,	0.1,	0.6
#define RGB_RED			0.8,	0.1,	0.1
#define RGB_BLUE		0.1,	0.1,	0.8
#define RGB_SKYBLUE		0.2,	0.6,	0.99
#define RGB_SHADOW		0.35,	0.35,	0.35
#define RGB_WHITE		0.95,	0.95,	0.95

typedef unsigned char	uchar;
typedef unsigned int	uint;

#ifndef M_PI
#define M_PI           3.14159265358979323846  /* pi */
#endif

#ifndef FALSE
#define FALSE 0
#define TRUE  1
#endif

#ifndef max
#define max(a,b) ((a > b) ? (a) : (b))
#define min(a,b) ((a < b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a,b) ((a > b) ? (a) : (b))
#define MIN(a,b) ((a < b) ? (a) : (b))
#endif

#define STREQ(a,b) (strcmp((a),(b))==0)
#define STRNE(a,b) (strcmp((a),(b))!=0)
/*
 * For full-speed (ie no delay), set this to 1.
 */
#define TIMER_MSECS		80

enum DRAW_BALL_ENUM { DRAW_BALL, DRAW_BALL_SHADOW };

struct vertex_t
{
   GLfloat	x;
   GLfloat	y;
   GLfloat	z;
};

#define random() rand()
#define srandom() srand()

GLfloat	deg_rot_y		= 0.0;
GLfloat deg_rot_y_inc		= 6.0;
GLfloat ball_x			= -RADIUS;
GLfloat ball_y			= -RADIUS;
GLfloat ball_x_inc		= 1.0;
GLfloat ball_y_inc		= 6.0;

DRAW_BALL_ENUM drawBallHow;

/*****************************************************************************
 * Truncate a degree.
 *****************************************************************************/
GLfloat TruncateDeg( GLfloat deg )
{
   if ( deg >= 360.0 )
      return (deg - 360.0);
   else
      return deg;
}

/*****************************************************************************
 * Convert a degree (360-based) into a radian.
 * 360' = 2 * PI
 *****************************************************************************/
double deg2rad( double deg )
{
    return deg / 360 * (2 * M_PI);
}

/*****************************************************************************
 * 360' sin().
 *****************************************************************************/
double sin_deg( double deg )
{
   return sin( deg2rad( deg ) );
}

/*****************************************************************************
 * 360' cos().
 *****************************************************************************/
double cos_deg( double deg )
{
   return cos( deg2rad( deg ) );
}

// Compute a cross product (for a normal vector).
// c = a x b
void CrossProduct( vertex_t& a, vertex_t& b, vertex_t& c, vertex_t& n )
{
   GLfloat u1, u2, u3;
   GLfloat v1, v2, v3;

   u1 = b.x - a.x;
   u2 = b.y - a.y;
   u3 = b.y - a.z;

   v1 = c.x - a.x;
   v2 = c.y - a.y;
   v3 = c.z - a.z;

   n.x = u2 * v3 - v2 * v3;
   n.y = u3 * v1 - v3 * u1;
   n.z = u1 * v2 - v1 * u2;
}

namespace Amiga
{
void init()
{
   glShadeModel( GL_FLAT );
}
void Draw()
{
	glPushMatrix();

	glTranslatef(0.0,0.0, -0.8);
	drawBallHow = DRAW_BALL;
	DrawBoingBall();

	glPopMatrix();
   return;
}

void DrawBoingBall()
{
   GLfloat lon_deg;		/* degree of longitude */

   glPushMatrix();
   glMatrixMode( GL_MODELVIEW );

   BounceBall();

  /*
   * Tilt the ball.
   */
   glRotatef( -20.0, 0.0, 0.0, 1.0 );

  /*
   * Continually rotate ball around Y axis.
   */
   glRotatef( deg_rot_y, 0.0, 1.0, 0.0 );
   deg_rot_y = TruncateDeg( deg_rot_y + deg_rot_y_inc );

  /*
   * Set OpenGL state for Boing ball.
   */
   glCullFace( GL_FRONT );
   glEnable( GL_CULL_FACE );
   glEnable( GL_NORMALIZE );

  /*
   * Build a faceted latitude slice of the Boing ball,
   * stepping same-sized vertical bands of the sphere.
   */
   for ( lon_deg = 0;
         lon_deg < 180;
         lon_deg += STEP_LONGITUDE )
   {
     /*
      * Draw a latitude circle at this longitude.
      */
      DrawBoingBallBand( lon_deg,
                         lon_deg + STEP_LONGITUDE );
   }
   glDisable( GL_CULL_FACE );
   glDisable( GL_NORMALIZE );
   
   glPopMatrix();

   return;
}

/*****************************************************************************
 * Bounce the ball.
 *****************************************************************************/
void BounceBall()
{
   GLfloat sign;
   GLfloat deg;

   if ( ball_x >  (BOUNCE_WIDTH/2 + WALL_R_OFFSET ) )
   {
      ball_x_inc = -0.5 - 0.75 * (GLfloat)random() / (GLfloat)RAND_MAX;
      deg_rot_y_inc = -deg_rot_y_inc;
   }
   if ( ball_x < -(BOUNCE_HEIGHT/2 + WALL_L_OFFSET) )
   {
      ball_x_inc =  0.5 + 0.75 * (GLfloat)random() / (GLfloat)RAND_MAX;
      deg_rot_y_inc = -deg_rot_y_inc;
   }
   ball_x += ball_x_inc/60;	// test /10
   
   glTranslatef( ball_x/10, 0.0, 0.0 );

   if ( ball_y >  BOUNCE_HEIGHT/2      ) ball_y_inc = -0.75 - 1.0 * (GLfloat)random() / (GLfloat)RAND_MAX;
   if ( ball_y < -BOUNCE_HEIGHT/2*0.85 ) ball_y_inc =  0.75 + 1.0 * (GLfloat)random() / (GLfloat)RAND_MAX;

   ball_y += ball_y_inc/60;	// test /10

   glTranslatef( 0.0, ball_y/10, 0.0 );

  /*
   * Simulate the effects of gravity on Y movement.
   */
   if ( ball_y_inc < 0 ) sign = -1.0; else sign = 1.0;

   deg = (ball_y + BOUNCE_HEIGHT/2) * 90 / BOUNCE_HEIGHT;
   if ( deg > 80 ) deg = 80;
   if ( deg < 10 ) deg = 10;

   ball_y_inc = sign * 4.0 * sin_deg( deg );

  /*
   * Offset the shadow.
   */
   if ( drawBallHow == DRAW_BALL_SHADOW )
   {
      glTranslatef( SHADOW_OFFSET_X, SHADOW_OFFSET_Y, SHADOW_OFFSET_Z );
   }
}

/*****************************************************************************
 * Draw a faceted latitude band of the Boing ball.
 *
 * Parms:	long_lo, long_hi
 *			Low and high longitudes of slice, resp.
 *****************************************************************************/
void DrawBoingBallBand( GLfloat long_lo,
                        GLfloat long_hi )
{
   vertex_t	vert_ne;			/* "ne" means south-east, so on */
   vertex_t	vert_nw;
   vertex_t	vert_sw;
   vertex_t	vert_se;
   vertex_t	vert_norm;
   GLfloat	lat_deg;
   static int colorToggle = 0;

  /*
   * Iterate thru the points of a latitude circle.
   * A latitude circle is a 2D set of X,Z points.
   */
   for ( lat_deg = 0;
         lat_deg <= (360 - STEP_LATITUDE);
         lat_deg += STEP_LATITUDE )
   {
     /*
      * Color this polygon with red or white.
      */
      if ( colorToggle )
         glColor3f( RGB_RED );
      else
         glColor3f( RGB_WHITE );
#if 0
      if ( lat_deg >= 180 )
         if ( colorToggle )
            glColor3f( 0.1, 0.8, 0.1 );
         else
            glColor3f( 0.5, 0.5, 0.95 );
#endif
      colorToggle = ! colorToggle;

     /*
      * Change color if drawing shadow.
      */
      if ( drawBallHow == DRAW_BALL_SHADOW )
         glColor3f( RGB_SHADOW );

     /*
      * Assign each Y.
      */
      vert_ne.y = vert_nw.y = cos_deg(long_hi) * RADIUS;
      vert_sw.y = vert_se.y = cos_deg(long_lo) * RADIUS;

     /*
      * Assign each X,Z with sin,cos values scaled by latitude radius indexed by longitude.
      * Eg, long=0 and long=180 are at the poles, so zero scale is sin(longitude),
      * while long=90 (sin(90)=1) is at equator.
      */
      vert_ne.x = cos_deg( lat_deg                 ) * (RADIUS * sin_deg( long_lo + STEP_LONGITUDE ));
      vert_se.x = cos_deg( lat_deg                 ) * (RADIUS * sin_deg( long_lo                  ));
      vert_nw.x = cos_deg( lat_deg + STEP_LATITUDE ) * (RADIUS * sin_deg( long_lo + STEP_LONGITUDE ));
      vert_sw.x = cos_deg( lat_deg + STEP_LATITUDE ) * (RADIUS * sin_deg( long_lo                  ));

      vert_ne.z = sin_deg( lat_deg                 ) * (RADIUS * sin_deg( long_lo + STEP_LONGITUDE ));
      vert_se.z = sin_deg( lat_deg                 ) * (RADIUS * sin_deg( long_lo                  ));
      vert_nw.z = sin_deg( lat_deg + STEP_LATITUDE ) * (RADIUS * sin_deg( long_lo + STEP_LONGITUDE ));
      vert_sw.z = sin_deg( lat_deg + STEP_LATITUDE ) * (RADIUS * sin_deg( long_lo                  ));

     /*
      * Draw the facet.
      */
      glBegin( GL_POLYGON );

      CrossProduct( vert_ne, vert_nw, vert_sw, vert_norm );
      glNormal3f( vert_norm.x, vert_norm.y, vert_norm.z );

      glVertex3f( vert_ne.x, vert_ne.y, vert_ne.z );
      glVertex3f( vert_nw.x, vert_nw.y, vert_nw.z );
      glVertex3f( vert_sw.x, vert_sw.y, vert_sw.z );
      glVertex3f( vert_se.x, vert_se.y, vert_se.z );

      glEnd();

   }

  /*
   * Toggle color so that next band will opposite red/white colors than this one.
   */
   colorToggle = ! colorToggle;

  /*
   * This circular band is done.
   */
   return;
}

/*****************************************************************************
 * Draw the purple grid of lines, behind the Boing ball.
 * When the Workbench is dropped to the bottom, Boing shows 12 rows.
 *****************************************************************************/
void DrawGrid()
{
   int				row, col;
   const int		rowTotal	= 12;					/* must be divisible by 2 */
   const int		colTotal	= rowTotal;				/* must be same as rowTotal */
   const GLfloat	widthLine	= 2.0;					/* should be divisible by 2 */
   const GLfloat	sizeCell	= GRID_SIZE / rowTotal;
   const GLfloat	z_offset	= -40.0;
   GLfloat			xl, xr;
   GLfloat			yt, yb;

   glPushMatrix();
   glDisable( GL_CULL_FACE );

  /*
   * Another relative Z translation to separate objects.
   */
   glTranslatef( 0.0, 0.0, DIST_BALL/10 );

  /*
   * Draw vertical lines (as skinny 3D rectangles).
   */
   for ( col = 0; col <= colTotal; col++ )
   {
     /*
      * Compute co-ords of line.
      */
      xl = -GRID_SIZE / 2 + col * sizeCell;
      xr = xl + widthLine;

      yt =  GRID_SIZE / 2;
      yb = -GRID_SIZE / 2 - widthLine;

      glBegin( GL_POLYGON );

      glColor3f( RGB_PURPLE );				/* purple */

      glVertex3f( xr, yt, z_offset );		/* NE */
      glVertex3f( xl, yt, z_offset );		/* NW */
      glVertex3f( xl, yb, z_offset );		/* SW */
      glVertex3f( xr, yb, z_offset );		/* SE */

      glEnd();
   }

  /*
   * Draw horizontal lines (as skinny 3D rectangles).
   */
   for ( row = 0; row <= rowTotal; row++ )
   {
     /*
      * Compute co-ords of line.
      */
      yt = GRID_SIZE / 2 - row * sizeCell;
      yb = yt - widthLine;

      xl = -GRID_SIZE / 2;
      xr =  GRID_SIZE / 2 + widthLine;

      glBegin( GL_POLYGON );

      glColor3f( RGB_PURPLE );				/* purple */

      glVertex3f( xr, yt, z_offset );		/* NE */
      glVertex3f( xl, yt, z_offset );		/* NW */
      glVertex3f( xl, yb, z_offset );		/* SW */
      glVertex3f( xr, yb, z_offset );		/* SE */

      glEnd();
   }

   glPopMatrix();

   return;
}

}     