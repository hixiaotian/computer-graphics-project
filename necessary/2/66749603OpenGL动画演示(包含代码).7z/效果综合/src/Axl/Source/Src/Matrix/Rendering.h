#ifndef _RENDERING_H
#define _RENDERING_H

#include <math.h>


void greUnloadLevelTextures(void);
void greLoadLevelTextures(void);
void greRenderLevelScene(void);

#endif