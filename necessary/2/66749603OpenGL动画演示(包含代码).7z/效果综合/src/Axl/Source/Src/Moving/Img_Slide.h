/*
 * Draw ball, or its shadow.
 */



/*
 * global vars
 */


namespace Amiga
{
	void init();
	void Draw();
	void DrawBoingBall();
	void BounceBall();
	void DrawBoingBallBand( GLfloat long_lo,
	                        GLfloat long_hi );
	void DrawGrid();
}   