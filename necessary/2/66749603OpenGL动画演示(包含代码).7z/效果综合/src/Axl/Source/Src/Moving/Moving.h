   
namespace moving
{
	void Draw();
	void DrawMeta();
}