#include "../../main.h"


/////////////////////////////////////////////////////////////////////

vec3_t eye			= {68.0f, 0.0f, 100.0f};
vec3_t rot			= {45.0f, 45.0f, 0.0f};

int				texmode=1, envMap=1;

#define				SIZE	1.6f

DWORD				tCur, tFps;
DWORD				tf=0, nf=0;
int				speed=70;

int				size=60;
int				hw=1;
int				OldX,OldY;
float				dt=(float) 0.02;
float				tval=(float) 1.0f/25;

float				surf[100][100][3];
float				norm[100][100][3];
float				force[100][100];
float				veloc[100][100];

float				LightAmbient[]=	{ 1.0f, 1.0f, 1.0f, 1.0f };
float				LightDiffuse[]=	{ 1.0f, 1.0f, 1.0f, 1.0f };
float				LightPosition[]=	{ 0.0f, 0.0f, -20.0f, 1.0f };


extern int			w_height;
extern int			w_width;
extern float			m_fAngle;

extern NIMG			texwater6,Chrome,texstar;
//extern PARTICLE_SYSTEM		star;
NIMG				Texture;
extern int			num_water;
//extern CCamera		objCamera; 

bool				INIT = true;
extern NSCENE 			NScene[NUM_SCENE];
extern Naskel3D			Naskel;
extern CCamera			objCamera; 

GLfloat Throttlei;
GLfloat Throttle = 5;
GLfloat _Throttle = Throttle;
GLfloat Speed = Throttle;
GLfloat Speedi;
GLfloat glow = .4;
GLfloat glowp = 0;
int loop;

float cubeH = 7.0;

#define	MAX_PARTICLES_BURNER	1000		// Number Of Particles To Create

GLfloat	slowdown=.50f;				// Slow Down Particles
GLfloat	xspeed;						// Base X Speed (To Allow Keyboard Direction Of Tail)
GLfloat	yspeed;						// Base Y Speed (To Allow Keyboard Direction Of Tail)

GLfloat water_flow = 0;
GLfloat V;
GLfloat Angle_burner;
GLfloat AngleZ;

typedef struct						// Create A Structure For Particle
{
	bool	active;					// Active (Yes/No)
	GLfloat	life;					// Particle Life
	GLfloat	fade;					// Fade Speed
	GLfloat	r;						// Red Value
	GLfloat	g;						// Green Value
	GLfloat	b;						// Blue Value
	GLfloat	x;						// X Position
	GLfloat	y;						// Y Position
	GLfloat	z;						// Z Position
	GLfloat	xi;						// X Direction
	GLfloat	yi;						// Y Direction
	GLfloat	zi;						// Z Direction
	GLfloat	xg;						// X Gravity
	GLfloat	yg;						// Y Gravity
	GLfloat	zg;						// Z Gravity
} particles;							// Particles Structure

particles particle[MAX_PARTICLES_BURNER];	// Particle Array (Room For Particle Info)

static GLfloat colors[12][3]=		// Rainbow Of Colors
{
	{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
	{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
	{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
};

inline GLfloat Hypot(GLfloat A, GLfloat B)
{
  return sqrt(A*A+B*B);
}

inline GLfloat ABS(GLfloat A)
{
  if (A < 0)
  A = -A; 
  return A;
}

/////////////////////////////////////////////////////////////////////


namespace water {

void Display(void)
{   
	

	float PosX = objCamera.mPos.x, PosY = objCamera.mPos.y, PosZ = objCamera.mPos.z;
	float ViewX = objCamera.mView.x, ViewY = objCamera.mView.y, ViewZ = objCamera.mView.z; 



	glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D); glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING); glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T); glEnable(GL_LIGHT1);
	glEnable(GL_LIGHTING);

	Naskel.SetMouse();
	DrawSurface();

	if (tCur-tFps>(DWORD)(1000/speed)) { MakeNorm(); Wave(); tFps = tCur; }		
	tCur=timeGetTime(); if (tCur-tf>=1000) {tf=tCur;nf=0;} else nf++;

	glDisable(GL_TEXTURE_2D); glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING); glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
}

void copy(float vec0[3], float vec1[3])
{
	    vec0[0] = vec1[0];
	    vec0[1] = vec1[1];
	    vec0[2] = vec1[2];
}

void sub(float vec0[3], float vec1[3], float vec2[3])
{
	    vec0[0] = vec1[0] - vec2[0];
	    vec0[1] = vec1[1] - vec2[1];
	    vec0[2] = vec1[2] - vec2[2];
}

void add(float vec0[3], float vec1[3], float vec2[3])
{
	    vec0[0] = vec1[0] + vec2[0];
	    vec0[1] = vec1[1] + vec2[1];
	    vec0[2] = vec1[2] + vec2[2];
}

void scalDiv(float vec[3], float c)
{
	    vec[0] /= c; vec[1] /= c; vec[2] /= c;
}

void cross(float vec0[3], float vec1[3], float vec2[3])
{
	    vec0[0] = vec1[1] * vec2[2] - vec1[2] * vec2[1];
	    vec0[1] = vec1[2] * vec2[0] - vec1[0] * vec2[2];
	    vec0[2] = vec1[0] * vec2[1] - vec1[1] * vec2[0];
}

void normz(float vec[3])
{
	    float c = sqrt(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
	    scalDiv(vec, c); 
}
void ResetSurface(void)
{
	int i,j;

	for(i=0; i<size; i++)
	for(j=0; j<size; j++)
	{
		surf[i][j][0] = (float)i/(float)size * 100;
		surf[i][j][1] = 0;
		surf[i][j][2] = (float)j/(float)size * 100;

		force[i][j] = 0;
		veloc[i][j] = 0;
	}
}

void DrawSurface(void)
{
	int i, j;


	glColor3f(1, 1, 1);	
	glBindTexture(GL_TEXTURE_2D, texwater6.ID);

	for(j=0; j<size-1; j++) {
	   glBegin(GL_TRIANGLE_STRIP);	
	   for(i=0; i<size; i++) {
	      glTexCoord2f((float)i*tval, (float)j*tval);
	      glNormal3f((float)norm[i][j][0], (float)norm[i][j][1], (float)norm[i][j][2]);
	      glVertex3f((float)surf[i][j][0], (float)surf[i][j][1], (float)surf[i][j][2]);

	      glTexCoord2f((float)i*tval, (float)(j+1)*tval);
	      glNormal3f((float)norm[i][j+1][0], (float)norm[i][j+1][1], (float)norm[i][j+1][2]);
	      glVertex3f((float)surf[i][j+1][0], (float)surf[i][j+1][1], (float)surf[i][j+1][2]);
	   }
	   glEnd();
	}
	int	m = (int)((float)OldX/w_width * size);
	int	n = (int)((float)OldY/w_height * size);
	glPushMatrix();
		glRotatef(m_fAngle, surf[m][n][0],10.0f-cubeH, surf[m][n][2]); m_fAngle +=0.8f;
		CreateCube(surf[m][n][0],10.0f-cubeH,surf[m][n][2], 2.0f);
	glPopMatrix();

}

void Move(int x, int y) 
{
	int m, n; OldX = x; OldY = y;
	m = (int)((float)x/w_width * size);
	n = (int)((float)y/w_height * size);
	
	surf[m][n][1] = hw;
	surf[m][n+1][1] = hw;
	surf[m+1][n][1] = hw;
	surf[m+1][n+1][1] = hw;
}

void MakeNorm(void)
{
	int i, j;
	float a[3],b[3],c[3];

	for(i=0; i<size; i++)
	for(j=0; j<size; j++)
	{
		if (i!=size-1 && j!=size-1)
		{
			sub(a, surf[i][j+1], surf[i][j]);
			sub(b, surf[i+1][j], surf[i][j]);
		}
		else
		{
			sub(a, surf[i][j-1], surf[i][j]);
			sub(b, surf[i-1][j], surf[i][j]);
		}
		
		cross(c, a, b);
		normz(c);

		if (i==0 && j==size-1)
		{
			sub(a, surf[i][j-1], surf[i][j]);
			sub(b, surf[i+1][j], surf[i][j]);

			cross(c, a, b);
			normz(c);

			c[0]=-c[0]; c[1]=-c[1]; c[2]=-c[2];
		}
		
		if (i==size-1 && j==0)
		{
			sub(a, surf[i-1][j], surf[i][j]);
			sub(b, surf[i][j+1], surf[i][j]);

			cross(c, a, b);
			normz(c);
		}		
		
		copy(norm[i][j], c);
   }
}

void Wave(void)
{
	int i,j;
	float d;

	for(i=0; i<size; i++)
	for(j=0; j<size; j++)
		force[i][j] = 0.0f;

	for(i=1; i<size-1; i++)
	for(j=1; j<size-1; j++)
	{
		d=surf[i][j][1]-surf[i][j-1][1];
		force[i][j] -= d;
		force[i][j-1] += d;

		d=surf[i-1][j][1]-surf[i-1][j][1];
		force[i][j] -= d;
		force[i-1][j] += d;

		d=surf[i][j][1]-surf[i][j+1][1];
		force[i][j] -= d;
		force[i][j+1] += d;

		d=surf[i][j][1]-surf[i+1][j][1];
		force[i][j] -= d;
		force[i+1][j] += d;

		d=(surf[i][j][1]-surf[i+1][j+1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i+1][j+1] += d;

		d=(surf[i][j][1]-surf[i-1][j-1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i-1][j-1] += d;

		d=(surf[i][j][1]-surf[i+1][j-1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i+1][j-1] += d;

		d=(surf[i][j][1]-surf[i+1][j-1][1])*SQRTOFTWOINV;
		force[i][j] -= d;
		force[i+1][j-1] += d;
	}

	for(i=0; i<size; i++)
	for(j=0; j<size; j++)
		veloc[i][j] += force[i][j] * dt;
	
	for(i=0; i<size; i++)
	for(j=0; j<size; j++)
	{
		surf[i][j][1] += veloc[i][j];
		
		if (surf[i][j][1]>0) surf[i][j][1] -= surf[i][j][1]/size;
		else surf[i][j][1] -= surf[i][j][1]/size;
	}
}

void Init(NIMG texwater)
{
	Texture = texwater;
	
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);

	glBindTexture(GL_TEXTURE_2D, texwater6.ID);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	 
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		
	ResetSurface();
	
	// Camera Pos
	objCamera.PositionCamera(
		15.88, 8.20,87.90, 43.48, -20.01, 43.48, 0.00, 1.00, 0.00
		);  

	
}

void CreateCube(float x, float y, float z, float radius)
{
	// Here we create 6 QUADS (Rectangles) to form a cube
	// With the passed in radius, we determine the width and height of the cube
	// You will notice, I add some color at each vertice to make it more interesting
	glPushMatrix();	
	
	glDisable(GL_TEXTURE_2D); glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING); glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	
	glBegin(GL_QUADS);		
		
		// These vertices create the Back Side
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z);

		// These vertices create the Front Side
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z + radius);
		glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z + radius);

		// These vertices create the Bottom Face
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z);
			
		// These vertices create the Top Face
		glColor3ub(0, 0, 255);   glVertex3f(x, y + radius, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z);

		// These vertices create the Left Face
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x, y + radius, z);

		// These vertices create the Right Face
		glColor3ub(0, 0, 255);   glVertex3f(x + radius, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x + radius, y, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z);

	glEnd();
	
	glPopMatrix();
}

}
