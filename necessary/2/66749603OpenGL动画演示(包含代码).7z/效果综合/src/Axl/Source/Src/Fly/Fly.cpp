#include "../../main.h"

extern NIMG FlyTextFore;
float curTime = 0.0;
float startTime;
extern NSCENE 	NScene[NUM_SCENE];

bool FlyInit = true;
extern float m_Z;
extern bool TimeFly;

#define MAX_FADEIN	3
#define MAX_FADE_ALPHA	0.1

float NDalpha = 0.0001f;
float SlideIn = 0.0f;


namespace fly
{


void Draw()
{
	float ActuTime = (timeGetTime()*0.001f) - StartTime;
	
	glEnable (GL_TEXTURE_2D);

	if (FlyInit) {
		
	glShadeModel(GL_SMOOTH);

		glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
		glEnable(GL_BLEND);
	
		glEnable( GL_LIGHT0 );
		glEnable( GL_NORMALIZE );
		glEnable( GL_COLOR_MATERIAL );
		glColorMaterial( GL_FRONT, GL_DIFFUSE );
		startTime = (float)rand();///RAND_MAX;
		
		// On remet la projection... 
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(45.0, 4/3, 0.001, 100.0);  // Do the perspective calculations. Last value = max clipping depth
		glMatrixMode(GL_MODELVIEW);         // Return to the modelview matrix
		glLoadIdentity();


		FlyInit = false;
	}
	static double lastTime=0;


	if(curTime>4) curTime/=5;
	else 	curTime=4;// - startTime;	
	
	glEnable(GL_BLEND);

	static BOOL gen = TRUE;
	static float float_pos[80][3];
	static float float_vel[80][2];
	static float float_col[80][3];
	int i;
	float tex_u, tex_v;
	float alpha;

	alpha = ActuTime / 90.0f;
	alpha = NDalpha;
	NDalpha+=0.0005;
	if (alpha>0.9) alpha = 0.9f;
	
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
	glDisable( GL_DEPTH_TEST );

	if( gen==TRUE )
	{
		gen = FALSE;
		for( i=0;i<80;i++ )
		{
			float_pos[i][0] = (float)rand()/RAND_MAX * 24.0f - 12.0f;
			float_pos[i][1] = (float)rand()/RAND_MAX * 8.0f - 4.0f;
			float_pos[i][2] = -(float)rand()/RAND_MAX * 1 - 1.8f;
			
			float_vel[i][0] = (float)rand()/RAND_MAX * 0.1f+0.05f;
			float_vel[i][1] = (float)rand()/RAND_MAX * 0.01f-0.005f;
			float_vel[i][2] = 0;

			float_col[i][0] = (float)rand()/RAND_MAX * 0.1f+0.6f;
			float_col[i][1] = (float)rand()/RAND_MAX * 0.1f+0.6f;
			float_col[i][2] = (float)rand()/RAND_MAX * 0.1f+0.6f;
		}
	}

	glBindTexture( GL_TEXTURE_2D, FlyTextFore.ID );

	for( i=0;i<80;i++ )
	{
		tex_u = (float_pos[i][0] + 12) / 24.0f;
		tex_v = (float_pos[i][1] + 8) / 16.0f;
		
		glColor4f( float_col[i][0], float_col[i][1], float_col[i][2], alpha );
		
		glBegin( GL_QUADS );
			glTexCoord2f( tex_u-0.05f, tex_v+0.08f );
			glVertex3f( float_pos[i][0]-1.0f, float_pos[i][1]+1.0f, float_pos[i][2] );
			glTexCoord2f( tex_u-0.05f, tex_v-0.08f );
			glVertex3f( float_pos[i][0]-1.0f, float_pos[i][1]-1.0f, float_pos[i][2] );
			glTexCoord2f( tex_u+0.05f, tex_v-0.08f );
			glVertex3f( float_pos[i][0]+1.0f, float_pos[i][1]-1.0f, float_pos[i][2] );
			glTexCoord2f( tex_u+0.05f, tex_v+0.08f );
			glVertex3f( float_pos[i][0]+1.0f, float_pos[i][1]+1.0f, float_pos[i][2] );
		glEnd();

		float_pos[i][0] += float_vel[i][0]*curTime/10;
		float_pos[i][1] += float_vel[i][1]*curTime/10;
		
		if( float_pos[i][0] > 12.0f )
		{
			float_pos[i][0] -= 24.0f;
			float_pos[i][1] = (float)rand()/RAND_MAX * 8.0f - 4.0f;
			float_vel[i][0] = (float)rand()/RAND_MAX * 0.2f+0.05f;
			float_vel[i][1] = (float)rand()/RAND_MAX * 0.01f-0.005f;
		}
		
	}
	glEnable( GL_DEPTH_TEST );
	glBlendFunc( GL_ONE, GL_ONE );		
	
	

}

}