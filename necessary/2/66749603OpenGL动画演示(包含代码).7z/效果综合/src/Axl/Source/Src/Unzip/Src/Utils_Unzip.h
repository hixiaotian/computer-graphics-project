#ifndef __utils_unzip_h__
#define __utils_unzip_h__

namespace unzip
{
    extern unsigned char * open(const char * filename, const char * inzipfile, unsigned int * size);
}

#endif
