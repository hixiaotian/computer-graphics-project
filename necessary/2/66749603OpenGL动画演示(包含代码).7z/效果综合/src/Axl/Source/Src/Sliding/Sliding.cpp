#include "../../main.h"
//#include "sliding.h"


extern NIMG	Sliding;
GLuint		texture[1];		
GLfloat 	xpos=0;
GLuint  	base;      
GLfloat 	fMove=0;
GLfloat 	rot=0;
BYTE 		map[50][41];
GLfloat 	brmap[50][41];
GLint 		nmap[50][41];
GLuint 		speedmap[50][2];

UINT Tick1=0, Tick2=0;   // used to help keep speed constant
UINT DTick;

int height		= SCREEN_HEIGHT;
int width		= SCREEN_WIDTH;

bool	SlideInit = true;

namespace sliding
{

void Init()
{

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);

		glViewport(0,0,width,height);	// Make our viewport the whole window
		glMatrixMode(GL_PROJECTION);	// Select The Projection Matrix
		glLoadIdentity();
		gluPerspective(45.0f,(GLfloat)width/(GLfloat)height, 1 ,150.0f);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	
		LoadLevel();
}
	
GLvoid glSetChar(unsigned char ch)        
{
		glCallList(base+ch); 
}


void RenderLevelScene() 
{
		glClear(GL_COLOR_BUFFER_BIT );	
		glLoadIdentity();
		
		if (SlideInit) {
			glCullFace(GL_BACK);
			glEnable(GL_CULL_FACE);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			
			glMatrixMode(GL_PROJECTION);	// Select The Projection Matrix
			glLoadIdentity();
			gluPerspective(45.0f,(GLfloat)width/(GLfloat)height, 1 ,150.0f);
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();

			SlideInit = false;
		}
		
		glCullFace(GL_BACK);
		glEnable(GL_CULL_FACE);
		glEnable(GL_BLEND);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, Sliding.ID);       
		glColor4f(0,0.5f,0,0.75f);

		glTranslatef(-20,-20,-36+fMove);
	
		for(int y=0;y<40;y++) {
			for(int x=0;x<50;x++) {
				if(brmap[x][y]<0.75f) {
					glColor4f(0,0.5f,0,brmap[x][y]);
				} else {
					glColor4f(brmap[x][y]/2,brmap[x][y],brmap[x][y]/2,0.75f);
				}
				glSetChar(map[x][y]);
				glTranslatef(0,0,40);
				glSetChar(map[x][y]);
				glTranslatef(0,0,40);
				glSetChar(map[x][y]);
				glTranslatef(0,0,40);
				glSetChar(map[x][y]);
				glTranslatef(0,0,40);
				glSetChar(map[x][y]);
				glTranslatef(0,0,40);
				glSetChar(map[x][y]);
				glTranslatef(0.8,0,-200);
			}
			glTranslatef(-40,1,0);
		}
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_BLEND);
}


GLvoid BuildFont(GLvoid)  
{
		glBindTexture(GL_TEXTURE_2D, Sliding.ID);
		base = glGenLists(256);  
		float cx;                           
		float cy;                           
		for(GLuint loop=0; loop<256; loop++)           
		{
			cx=float(loop%16)/16.0f;        
			cy=float(loop/16)/16.0f;        
			glNewList(base+loop,GL_COMPILE); 
			glBegin(GL_TRIANGLE_STRIP);              
				glTexCoord2f(cx,1-cy-0.0625f);  	
				glVertex3f(0,0,0);                
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);
				glVertex3f(1,0,0); 
				glTexCoord2f(cx,1-cy);  
				glVertex3f(0,1,0);       
				glTexCoord2f(cx+0.0625f,1-cy);  
				glVertex3f(1,1,0);              
			glEnd();                      	
			glEndList();                    
		}

}


GLvoid KillFont(GLvoid)            
{
	   glDeleteLists(base, 256);        
}


void UnloadLevelTextures()
{
		glDeleteTextures (1, &Sliding.ID);
		KillFont();
}


void LoadLevelTextures()
{
		BuildFont();
}

void LoadLevel()
{
		srand( (unsigned)time( NULL ) );
		LoadLevelTextures();
		for(int y=0;y<40;y++)
			for(int x=0;x<50;x++)
			{
				int i=rand()%10;
				if(i<2)
					map[x][y]=0;
				else
					map[x][y]=rand()%256;
				brmap[x][y]=0.35f+float(rand()%51)/100;
				nmap[x][y]=(rand()%5)-2;
				speedmap[x][0]=1+rand()%5;
				speedmap[x][1]=0;
			}
		Tick1 = GetTickCount ( );
		Tick2 = GetTickCount ( );
}


void UnloadLevel()
{
		UnloadLevelTextures();
}


void ProcessLevel()
{
	glEnable(GL_TEXTURE_2D);
		Tick1 = Tick2;
		Tick2 = GetTickCount ( );
		DTick += Tick2 - Tick1;
		fMove-=0.005f*float(Tick2 - Tick1);
		if(fMove<-200.0f)
			fMove=-120.0f;
		
		if(DTick>25)
		{
			DTick-=25;
			for(int x=0;x<50;x++)
			{
				int m;
				speedmap[x][1]++;
				if(speedmap[x][1]>speedmap[x][0])
				{	
					speedmap[x][1]=0;
					m=1;
				}
				else
					m=0;
					for(int y=0;y<40;y++)
					{
						if(m)
						{
							map[x][y]=map[x][y+1];
							brmap[x][y]=brmap[x][y+1];
							nmap[x][y]=nmap[x][y+1];
						}
						brmap[x][y]+=(float(nmap[x][y])*0.01f);
						if(brmap[x][y]>0.95f || brmap[x][y]<0.05f)
						nmap[x][y]=nmap[x][y]*(-1);
					}
				
			}
				for(x=0;x<50;x++)
				{
					int i=rand()%1000;
					if(i<300)
					{
						map[x][40]=0;
						if((rand()%10)<2)
							speedmap[x][0]=1+rand()%5;
					}
					else
					{
						if(i==300 && x<40)
						{
							int f=(rand()%5)-2;
							brmap[x][40]=1.0f;
							nmap[x][40]=f;
							map[x++][40]='A';
							brmap[x][40]=1.0f;
							nmap[x][40]=f;
							map[x++][40]='R';
							brmap[x][40]=1.0f;
							nmap[x][40]=f;
							map[x++][40]='R';
							brmap[x][40]=1.0f;
							nmap[x][40]=f;
							map[x++][40]='O';
							brmap[x][40]=1.0f;
							nmap[x][40]=f;
							map[x][40]='W';
						}
						else
						{
							map[x][40]=rand()%256;
							brmap[x][40]=0.35f+float(rand()%51)/100;
							nmap[x][40]=(rand()%5)-2;
						}
					}
				}
		}
		RenderLevelScene();
}
}