#ifndef Naskel3D_H
#define Naskel3D_H
			
//#include "matrice.h"

// Define
#define NIMG_JPG	0
#define NIMG_TGA	1
#define WATER_SPEED	2
#define NUM_SCENE	7
#define TIMEPERSCENE	29.125
#define MAX_CUBE	1600
#define SQR(x)		(x*x)

class Naskel3D;

typedef struct tagVERTEX	// Build Our Vertex Structure
{
	unsigned int color;
	float x, y, z;		// 3D Coordinates
	float u, v;		// Texture Coordinates
} VERTEX;

//Image structure
typedef struct NIMG_TYP
{
	unsigned char *vector;
	unsigned char *pixels;
	int width;
	int height;
	int components;
	DWORD* data;		//Image data (up to 32 bits)
	GLuint	 bpp;		//Image color depth in bits per pixel
	GLuint	 ID;		//Texture ID used to select a texture
	long	size;		// future use..
	int TYPE;
} NIMG, *NIMG_PTR;

// Render Texture
typedef struct NRT_TYP
{
	UINT data[6]; // This will reference to our texture data stored with
	int size;
	int channels;
	int type;		     
	int ID;
} NRT;

// Fog Structure
typedef struct NFOG_TYP
{
	GLfloat density;	// How Dense Will The Fog Be
	GLfloat	color[4];	// Set Fog Color
	GLfloat	start;		// Fog Start Depth
	GLfloat	end;		// Fog End Depth
	GLuint	mode;		// Storage For one of the Three Types Of Fog
	GLuint	hint_mode;	// Fog Hint Mode Value
	GLuint	hint_target;	// Fog Hint Target Value	
} NFOG;

// Scene Structure
typedef struct NSCENE_TYP
{
	float SceneTime;
	int ThisScene;
	int FirstTimeScene;
} NSCENE;

typedef struct DOME_TYP
{
	int		NumVertices;
	int		NumIndices;
	int		NumPlaneVertices;
	float		pRadius; 
	VERTEX		*PlaneVertices;
	WORD		*Indices;
} DOME,*DOME_PTR;

#define		FONT_HEIGHT	32
#define		MAX_CHARS	256
#define		FONT_EXTRUDE	0.4f
	
class Naskel3D {
	
public:
	Naskel3D();
	~Naskel3D();
	GLuint		base;

	GLuint		ListSceneCube[MAX_CUBE];
	UINT		g_FontList3DID;
	UINT		g_FontListSimpleID;
	UINT		g_FontNaskel3DID;
	UINT		CreateSimpleFont(LPSTR strFontName, int height, HWND m_hWnd);
	UINT		CreateOpenGL3DFont(LPSTR strFontName, float extrude, HWND m_hWnd);
	UINT		g_Texture[2];
	
	int		TotalF;
	int		speed;	/* speed is in frame/second */
	int		WaterMove,WaterWait;
	int		WaterX, WaterY;	
	int		TotalCube;
	int		Scene1Blend;
	int		ExplodeRotate;
	int		g_Viewport;
	
	float		PosCube[MAX_CUBE][3];
	float		AlphaTEST;
	float		rot_x,rot_y,rot_z;
	float		ALL_FRAME;	
	float		WaterCubeX,WaterCubeY,WaterCubeZ;
	float		LaunchTime;
	float		FGalaxieMove;
	float		ExplodeSpeed;
	float		g_RotateX, g_RotateY, g_RotateZ;

	DWORD		tStart,tCur, tFps;
	DWORD		tf, nf, showFps;

	bool		WaterDone;
	bool		BGalaxieMove1;
	bool		BGalaxieMove2;
	bool		TimeToExplode;
	bool		BExplode;
	bool		ImageLoad(NIMG_PTR image, char* filename,int type,GLfloat minfilter,GLfloat maxfilter);

	HWND		n3dhWnd;
		
	int		BuildTexture(char *szPathName, NIMG_PTR image,GLfloat minfilter,GLfloat maxfilter);

	GLvoid		Enable_Fog();
	GLvoid		Disable_Fog();
	GLvoid		SIN_COS_Init(GLvoid);

	HFONT		hOldFont;
	GLYPHMETRICSFLOAT g_GlyphInfo[MAX_CHARS];	
	HDC		g_hDC;
	NRT		rendertex;
//	NFOG	S5Fog;
	
	void		glDraw3DText(const char *strString, ...);
	void		glDrawText(int x, int y, const char *strString, ...);
	void		DrawLogo();
	void		Destroy3DFont();
	void		PositionText( int x, int y );	
	void		InitScene(int part);
	void		CreateCubeText(NIMG image, float x, float y, float z, float radius);
	void		CubeEnv(NIMG image);
	void		RenderScene(int part);
	void		CreateRenderTexture(UINT textureArray[], int size, int channels, int type, int textureID);
	void		NextScene(int scene);
	void		DrawBackgrnd(NIMG image);
	void		CreateCube(float x, float y, float z, float radius);
	void		CreateMultiCube(float x, float y, float z, int list);
	void		RotateMultiCube(int list,int rotate);
	void 		ExplodeMultiCube(int list);
	void		DrawAllScene();
	void		InitAllScene();
	void		SetMouse();
	void 		LogoF0sT();
	void		LogoNaskel();
	void		InitSkyPlane(int divisions, float PlanetRadius, float AtmosphereRadius, float hTile, float vTile,DOME_PTR dome);
	void		RenderSkyPlane(DOME dome);
	void		ReleaseSkyPlane(DOME dome);
	void		InitSkyDome(float radius, float dtheta, float dphi, float hTile, float vTile);
	void		RenderSkyDome(float x, float y, float z);
	void		Reset();
};


#endif