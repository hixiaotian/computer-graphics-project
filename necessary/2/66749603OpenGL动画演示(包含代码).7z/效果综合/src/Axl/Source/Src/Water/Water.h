#define SQRTOFTWOINV 1.0 / 1.414213562

typedef float vec_t;
typedef vec_t vec3_t[3];

namespace water {

	void Display(void);
	void copy(float vec0[3], float vec1[3]);
	void sub(float vec0[3], float vec1[3], float vec2[3]);
	void add(float vec0[3], float vec1[3], float vec2[3]);
	void scalDiv(float vec[3], float c);
	void cross(float vec0[3], float vec1[3], float vec2[3]);
	void normz(float vec[3]);
	void ResetSurface(void);
	void DrawSurface(void);
	void MakeNorm(void);
	void Wave(void);
	void Init(NIMG texwater);
	void Move(int x, int y);
	void CreateCube(float x, float y, float z, float radius);
	void SetTurbo(float x, float y, float z);
//	void clamp(vec3_t v);
}