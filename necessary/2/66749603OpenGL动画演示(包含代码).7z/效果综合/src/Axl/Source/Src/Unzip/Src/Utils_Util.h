#ifndef __utils_util_h__
#define __utils_util_h__

#include <windows.h>
#pragma warning (disable:4786) // Disable the STL debug information warnings
#pragma warning (disable:4172) // Disable "returning address of local variable or temporary"

#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
#include "utils_unzip.h"
//#include "utils_jpeg.h"
//#include <math.h>
//#include <setjmp.h>
//#include <assert.h>
//#include <vector>
//#include <string>
//#include <map>

//#include <limits.h>


#ifndef MAX_PATH
#define MAX_PATH PATH_MAX
#endif

namespace mods2
{
	bool 	Init();
	bool 	load(char *file);
	void	Free();
	void	Play();
	void	Stop();
	int	GetTime();	
}
/*
namespace mods
{
    extern bool            Init();
    extern bool            load(char *file);
    extern void            Free();
    extern char            *CGetTime();
    extern DWORD           DGetTime();
    extern float           GetCPU();
}
*/
namespace utils_util
{
    const char *    set_search_path(const char * path);
    const char *    get_search_path();
    bool            findfile(const char * filename, int size, char * pathname);
}

#endif
