#ifndef __utils_util_h__
#include "utils_util.h"
#endif

//#include <windows.h>		// Header File For Windows

// Mod player
//#include "bassmod.h"
#include "minifmod.h"

FMUSIC_MODULE *mod=NULL;

namespace mods2
{
	/////////////////////////////
	//MINIFMOD CALLBACK FUNCTIONS
	/////////////////////////////
	unsigned int fileopen(char *name)
	{
		return (unsigned int)fopen(name, "rb");
	}

	void fileclose(unsigned int handle)
	{
		fclose((FILE *)handle);
	}

	int fileread(void *buffer, int size, unsigned int handle)
	{
		return fread(buffer, 1, size, (FILE *)handle);
	}

	void fileseek(unsigned int handle, int pos, signed char mode)
	{
		fseek((FILE *)handle, pos, mode);
	}

	int filetell(unsigned int handle)
	{
		return ftell((FILE *)handle);
	}

	bool Init() {
		FSOUND_File_SetCallbacks(fileopen, fileclose, fileread, fileseek, filetell);
		if (!FSOUND_Init(44100, 0)) return false;
		return true;
	}

	bool load(char *file) {
		mod = FMUSIC_LoadSong(file, NULL); //sampleloadcallback);
		if (!mod) return false;
		
		FMUSIC_PlaySong(mod);
		
		return true;
	}
	int GetTime() {
		return FMUSIC_GetTime(mod);
	}
	void Free() {
		FMUSIC_FreeSong(mod);
		FSOUND_Close();	
	}
	void Play() {
		FMUSIC_PlaySong(mod);
	}
	void Stop() {
		FMUSIC_StopSong(mod);	
	}
}
/*
namespace mods
{
   bool Init() {
    		// setup output - default device, 44100hz, stereo, 16 bits 
    		if (!BASSMOD_Init(-1,44100,0))
			return false;
	return true;    	
   }
    
   bool load(char *file) {
		BASSMOD_MusicFree(); // free the current mod
		if (BASSMOD_MusicLoad(FALSE, file,0,0,BASS_MUSIC_RAMPS|
	            BASS_MUSIC_SURROUND|BASS_MUSIC_POSRESET)) {
			BASSMOD_MusicPlay();
			BASSMOD_SetVolume(60); // Set the volume to 60%
					       // because the default set is 100%....
		}
		else return false;
		return true;
   }
    
   void Free() {
	    BASSMOD_Free();	
   }
   
   char *CGetTime() {
	char text[12];
	int pos = BASSMOD_MusicGetPosition();
	if (pos==-1) pos=0;
	sprintf(text,"%03d.%03d",LOWORD(pos),HIWORD(pos));
	return text;
   }
   DWORD DGetTime() {
	//char text[12];
	DWORD pos = BASSMOD_MusicGetPosition();
	if (pos==-1) pos=0;
	//sprintf(text,"%03d.%03d",LOWORD(pos),HIWORD(pos));
	return pos;
   }
   
   float GetCPU() {
	return BASSMOD_GetCPU();	
   }
}
*/

namespace utils_util
{
    char *   g_search_path = 0;
    char     g_default_search_path[]=
            ".;"
            "./images;"
            "./textures;"
            "./models;"
            "./sounds;"
            ;

    const char *    set_search_path(const char * path)
    {
        if (g_search_path)
        {
            delete [] g_search_path;
            g_search_path = 0;
        }

        if (path)
        {
            int len = strlen(path);
            g_search_path = new char[len + 1];
            strcpy(g_search_path,path);
        }

        return get_search_path();
    }

    const char *    get_search_path()
    {
        return g_search_path != 0 ? g_search_path : g_default_search_path;
    }

    bool findfile(const char * filename, int size, char * pathname)
    {
        static char curr_pathname[1024];
        static char curr_path[1024];

        const char * ptr = get_search_path();
        char * idx = strchr(ptr,';');

        while (idx)
        {
            if (idx - ptr <= 0)
                break;

            memcpy( curr_path, ptr, idx - ptr);
            curr_path[idx - ptr] = '\0';

            sprintf(curr_pathname, "%s/%s",curr_path,filename);

		    FILE * fp = ::fopen(curr_pathname, "r" );

		    if(fp != 0)
            {
                int len = strlen(curr_pathname) + 1;
                if (len > size)
                    len = size;
                strncpy(pathname,curr_pathname, len);
                fclose(fp);
			    return true;
            }
            ptr = idx + 1;
            idx = strchr(ptr,';');
        }

        fprintf(stderr,"file not found: %s .\n",filename);
        fprintf(stderr,"search path: %s .\n",get_search_path());
        return false;
    }
}
