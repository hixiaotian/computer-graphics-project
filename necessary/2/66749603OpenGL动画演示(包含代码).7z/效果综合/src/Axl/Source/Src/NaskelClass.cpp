#include "../main.h"
#include "water/water.cpp"

#include "cyl.cpp"


//**************************//
// Defines                  //
//**************************//

#define	CAMERASPEED	0.001f
#define	__WITH_SOUND
#ifndef __FINAL
// Only debug if non final..
#define __DEBUG
#endif
#define Error(x)  if (::MessageBox(NULL, x, "Error", MB_ICONHAND|MB_OK|MB_DEFBUTTON1)==IDOK) exit(1);

NIMG			texture0, texstar, texwater, texwater1, texwater2, texwater3;
NIMG			texwater6, Sliding,Moving,Chrome;
NIMG			FireTex, TunnelTex,Img_Slide_BackGround, Img_Slide_ForeGround;
NIMG			FlyTextFore,FlyWhiteTex,skydome, amiga_girl, mouse_amiga,amiga_clic,amiga_bg,amiga_woops;
NIMG			Lava, Night,TubeTex,F0sT,LogoN;

NSCENE			NScene[NUM_SCENE];
extern CCamera			objCamera; 
extern int key_move[4];

int			w_height = SCREEN_HEIGHT;
int 			w_width	= SCREEN_WIDTH;
int			move[4];
extern HWND		g_hWnd;
extern 			int num_water;
float			LaunchTime;
float 			m_fAngle, m_smallc;
//#ifdef __DEBUG
extern float		m_Z;
extern bool GotNextScene;
//#endif
bool WaterResetPers = true;
bool TimeFly = false;
float FlySlide =  101;
int FlyText = 0;
bool FlyRotate = true;
bool sliding_init = true;
bool OglInit = true;
bool SkyDomeInit = true;
bool RotateOgl1 = true, RotateOgl2 = false, RotateOgl3 = false;
bool SkyRotate = true;
bool CylInit = true;

//******************************************//
// Sky Plane                                //
//******************************************//
DOME SkyPlane1, SkyPlane2;

// Cyl
float	CylAngle = 0.0;
int	CylElapsedTime;
DWORD	CylStart, CylLastTime;
float	pos_rubber=+30.0f;
float	CylX=0.0f;

Cylindre	*cyl,*tunnel,*tunnel2;
float 		AdvanceCube = 0.0f;

float		deform_cyl=0.0f,deform_cyl_val=0.005f,deform_cyl_maxval=1.5f;
float		deform_cyl2=0.0f,deform_cyl_val2=0.008f,deform_cyl_maxval2=4.0f;
float		deform_cyl3=0.0f,deform_cyl_val3=0.005f,deform_cyl_maxval3=4.0f;

// Scroll Text
float	ScrollText = w_height;
bool	scrollt = true;
bool	fostdone = false;
bool	InitFost = true;
float	rotateFost = 10.0f;
bool	directfost = true;
float	FostWait = 0.0;
bool	PauseText = false;
float	PauseWait = 0.0;


// the end..
bool	AllIsStoped = false;





//**************************//
// Fonction                 //
//**************************//
//#include "matrice.cpp"

// ************************ //
// SOUND DEVICE             //
// ************************ //

Naskel3D::Naskel3D() 
{
	cyl=new Cylindre(22,50,40.0f,4.0f);
	tunnel=new Cylindre(22,50,100.0f,6.0f);
	tunnel2=new Cylindre(22,50,100.0f,5.5f);
	
	TotalF		= 0;
	Scene1Blend	= 0;
	g_RotateX	= 0;
	g_RotateY	= 0;
	g_RotateZ	= 0;
	g_Viewport	= 512;
	n3dhWnd		= g_hWnd;
	TotalCube	= 0;
	
	tf		= 0;
	nf		= 0;
	showFps		= 0;
	speed		= 40;	/* speed is in frame/second */
	
	WaterMove	= 0;
	WaterX		= 0;
	WaterY		= 0;
	WaterCubeX	= -150.0f,
	WaterCubeY	= -150.0f,
	WaterCubeZ	= -150.0f;
	//WaterWait	= (timeGetTime()*0.001f) - StartTime;
	//LaunchTime	= WaterWait;
	WaterDone	= false;
	
	BGalaxieMove1	= true;
	BGalaxieMove2	= false;
	TimeToExplode	= false;
	
	ExplodeSpeed	= 0.0;	
	ExplodeRotate	= 0;
	BExplode	= true;
	//ThisScene0 = true; ThisScene1 = false; ThisScene2 = false; ThisScene3 = false;
	//ThisScene4 = false; ThisScene5 = false; ThisScene6 = false; ThisScene7 = false;
	 
	NScene[0].ThisScene = 1; NScene[0].FirstTimeScene = 1;
		
	for (int i=1;i<8;i++) {
		NScene[i].FirstTimeScene = 1;
		NScene[i].ThisScene = 0;
	}
}

Naskel3D::~Naskel3D() 
{
}

void Naskel3D::DrawAllScene()
{
/*	OK*/
	if (!AllIsStoped) {
		// Final Call for Render
		if (NScene[0].ThisScene) NextScene(0);
		else if (NScene[1].ThisScene) NextScene(1);
		else if (NScene[2].ThisScene) NextScene(2);
		else if (NScene[3].ThisScene) NextScene(3);
		else if (NScene[4].ThisScene) NextScene(4);
		else if (NScene[5].ThisScene) NextScene(5);
		else if (NScene[6].ThisScene) NextScene(6);
		else if (NScene[7].ThisScene) NextScene(7);
		else {
			mods2::Stop();
			mods2::Free();
			AllIsStoped= true;
			//SendMessage(g_hWnd,WM_DESTROY,NULL,NULL); // all is finished ready to stop..
		}
	} else {
		RenderScene(7);
	}
	/*
OK	*/


	//RenderScene(7);	// Unique Call For DEBUG ;)


#ifdef __DEBUG
glPushMatrix();
	//Reset();
	glColor3f(1, 1, 1);
	glDrawText(15, 45, "m_Z:%f",m_Z);
glPopMatrix();	
#endif	


	// Draw Naskel3D Logo
glPushMatrix();
	Reset();
	glColor3f(1, 1, 1);
	DrawLogo();
glPopMatrix();	
}


void Naskel3D::InitAllScene()
{
	glEnable(GL_TEXTURE_2D);				// Enable Texture Mapping
	glShadeModel(GL_SMOOTH);				// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);			// Black Background
	glClearDepth(1.0f);					// Depth Buffer Setup
	glDepthFunc (GL_LEQUAL);				// The Type Of Depth Testing (Less Or Equal)
//	glEnable(GL_DEPTH_TEST);				// Enables Depth Testing
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);			// Enable Blending

//	Shed.InitClock();	// Start the clock

	//	Sky Plane
	InitSkyPlane(16, 100.0f, 250.0f, 3.0f, 3.0f, &SkyPlane1);
	InitSkyPlane(16, 100.0f, 150.0f, 3.0f, 3.0f, &SkyPlane2);

	// Load All Textures Here FIRST
	if (!ImageLoad(&texture0, "textures/sky3.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load sky3.jpg, Exiting now.");
	if (!ImageLoad(&texstar, "textures/nebula.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load star.jpg, Exiting now.");

	if (!ImageLoad(&texwater6, "textures/water006.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant water006 star.jpg, Exiting now.");
	if (!ImageLoad(&Sliding, "textures/Font.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load Font.jpg, Exiting now.");	
	if (!ImageLoad(&Moving, "textures/moving.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load moving.jpg, Exiting now.");	
	if (!ImageLoad(&Chrome, "textures/Reflect.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load Reflect.jpg, Exiting now.");	
	if (!ImageLoad(&FlyWhiteTex, "textures/white.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load White.jpg, Exiting now.");	
	if (!ImageLoad(&skydome, "textures/girl-clair.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load skydome, Exiting now.");	
	if (!ImageLoad(&Night, "textures/bluetunnel.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load Night.jpg, Exiting now.");	
	if (!ImageLoad(&Lava, "textures/firetunnel.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load lava, Exiting now.");	
	if (!ImageLoad(&LogoN, "textures/naskel.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load TubeTex, Exiting now.");	
	if (!ImageLoad(&F0sT, "textures/fost.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load TubeTex, Exiting now.");	
	if (!ImageLoad(&FlyTextFore, "textures/girl-clair.jpg", NIMG_JPG, GL_LINEAR, GL_LINEAR)) Error("Cant load FlyTextFore, Exiting now.");	

	// First Font Creator (store the old font..)
	g_FontList3DID = CreateOpenGL3DFont("Arial", FONT_EXTRUDE, n3dhWnd);
	g_FontListSimpleID = CreateSimpleFont("Arial", FONT_HEIGHT, n3dhWnd);
	g_FontNaskel3DID = CreateSimpleFont("Impact", FONT_HEIGHT, n3dhWnd);

	InitScene(9);
	InitScene(8);
	InitScene(7);
	InitScene(6);
	InitScene(5);
	InitScene(4);
	InitScene(3);	// Star
	InitScene(2);
	InitScene(1);

#ifdef __WITH_SOUND	// Ne DOIT ETRE CALL QUAND DERNIER !!
//	CylStart = GetTickCount(); 
	StartTime = timeGetTime()*0.001f;
	InitScene(0);
	
//	LaunchTime = Shed.GetTime();
#endif

}

GLvoid Naskel3D::Enable_Fog() { glEnable(GL_FOG); }
GLvoid Naskel3D::Disable_Fog() { glDisable(GL_FOG); }

/*********************************************************************/
//	FOG END
/*********************************************************************/

// Loads:  BMP, EMF, GIF, ICO, JPG, WMF   
int Naskel3D::BuildTexture(char *szPathName, NIMG_PTR image,GLfloat minfilter,GLfloat maxfilter)						// Load Image And Convert To A Texture
{
	HDC		hdcTemp;												// The DC To Hold Our Bitmap
	HBITMAP		hbmpTemp;												// Holds The Bitmap Temporarily
	IPicture	*pPicture;												// IPicture Interface
	OLECHAR		wszPath[MAX_PATH+1];									// Full Path To Picture (WCHAR)
	char		szPath[MAX_PATH+1];										// Full Path To Picture
	long		lWidth;													// Width In Logical Units
	long		lHeight;												// Height In Logical Units
	long		lWidthPixels;											// Width In Pixels
	long		lHeightPixels;											// Height In Pixels
	GLint		glMaxTexDim ;											// Holds Maximum Texture Size

	if (strstr(szPathName, "http://"))									// If PathName Contains http:// Then...
	{
		strcpy(szPath, szPathName);										// Append The PathName To szPath
	}
	else																// Otherwise... We Are Loading From A File
	{
		GetCurrentDirectory(MAX_PATH, szPath);							// Get Our Working Directory
		strcat(szPath, "\\");											// Append "\" After The Working Directory
		strcat(szPath, szPathName);										// Append The PathName
	}

	MultiByteToWideChar(CP_ACP, 0, szPath, -1, wszPath, MAX_PATH);		// Convert From ASCII To Unicode
	HRESULT hr = OleLoadPicturePath(wszPath, 0, 0, 0, IID_IPicture, (void**)&pPicture);

	if(FAILED(hr))														// If Loading Failed
		return FALSE;													// Return False

	hdcTemp = CreateCompatibleDC(GetDC(0));								// Create The Windows Compatible Device Context
	if(!hdcTemp)														// Did Creation Fail?
	{
		pPicture->Release();											// Decrements IPicture Reference Count
		return FALSE;													// Return False (Failure)
	}

	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &glMaxTexDim);					// Get Maximum Texture Size Supported
	
	pPicture->get_Width(&lWidth);										// Get IPicture Width (Convert To Pixels)
	lWidthPixels	= MulDiv(lWidth, GetDeviceCaps(hdcTemp, LOGPIXELSX), 2540);
	pPicture->get_Height(&lHeight);										// Get IPicture Height (Convert To Pixels)
	lHeightPixels	= MulDiv(lHeight, GetDeviceCaps(hdcTemp, LOGPIXELSY), 2540);

	// Resize Image To Closest Power Of Two
	if (lWidthPixels <= glMaxTexDim) // Is Image Width Less Than Or Equal To Cards Limit
		lWidthPixels = 1 << (int)floor((log((double)lWidthPixels)/log(2.0f)) + 0.5f); 
	else  // Otherwise  Set Width To "Max Power Of Two" That The Card Can Handle
		lWidthPixels = 1 << (int)floor((log((double)glMaxTexDim)/log(2.0f)) + 0.5f);
 
	if (lHeightPixels <= glMaxTexDim) // Is Image Height Greater Than Cards Limit
		lHeightPixels = 1 << (int)floor((log((double)lHeightPixels)/log(2.0f)) + 0.5f);
	else  // Otherwise  Set Height To "Max Power Of Two" That The Card Can Handle
		lHeightPixels = 1 << (int)floor((log((double)glMaxTexDim)/log(2.0f)) + 0.5f);
	
	//	Create A Temporary Bitmap
	BITMAPINFO	bi = {0};												// The Type Of Bitmap We Request
	//DWORD		*pBits = 0;
	image->data = 0;											// Pointer To The Bitmap Bits

	bi.bmiHeader.biSize			= sizeof(BITMAPINFOHEADER);				// Set Structure Size
	bi.bmiHeader.biBitCount		= 32;									// 32 Bit
	bi.bmiHeader.biWidth		= lWidthPixels;							// Power Of Two Width
	bi.bmiHeader.biHeight		= lHeightPixels;						// Make Image Top Up (Positive Y-Axis)
	bi.bmiHeader.biCompression	= BI_RGB;								// RGB Encoding
	bi.bmiHeader.biPlanes		= 1;									// 1 Bitplane

	//	Creating A Bitmap This Way Allows Us To Specify Color Depth And Gives Us Imediate Access To The Bits
	hbmpTemp = CreateDIBSection(hdcTemp, &bi, DIB_RGB_COLORS, (void**)&image->data, 0, 0);
	
	if(!hbmpTemp)														// Did Creation Fail?
	{
		DeleteDC(hdcTemp);												// Delete The Device Context
		pPicture->Release();											// Decrements IPicture Reference Count
		return FALSE;													// Return False (Failure)
	}

	SelectObject(hdcTemp, hbmpTemp);									// Select Handle To Our Temp DC And Our Temp Bitmap Object

	// Render The IPicture On To The Bitmap
	pPicture->Render(hdcTemp, 0, 0, lWidthPixels, lHeightPixels, 0, lHeight, lWidth, -lHeight, 0);

	// Convert From BGR To RGB Format And Add An Alpha Value Of 255
	for(long i = 0; i < lWidthPixels * lHeightPixels; i++)	
	// Loop Through All Of The Pixels
	{
		BYTE* pPixel	= (BYTE*)(&image->data[i]);	// Grab The Current Pixel
		BYTE  temp	= pPixel[0];	// Store 1st Color In Temp Variable (Blue)
		pPixel[0]	= pPixel[2];	// Move Red Value To Correct Position (1st)
		pPixel[2]	= temp;		// Move Temp Value To Correct Blue Position (3rd)
		pPixel[3]	= 255;		// Set The Alpha Value To 255
	}

	glGenTextures(1, &image->ID);											// Create The Texture
 	
 	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
 
	// Typical Texture Generation Using Data From The Bitmap
	glBindTexture(GL_TEXTURE_2D, image->ID);
	
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,minfilter);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,maxfilter);
	
//	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, lWidthPixels, lHeightPixels, GL_RGB, GL_UNSIGNED_BYTE, image->data);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, lWidthPixels, lHeightPixels, 0, GL_RGBA, GL_UNSIGNED_BYTE, image->data);


	DeleteObject(hbmpTemp);												// Delete The Object
	DeleteDC(hdcTemp);													// Delete The Device Context

	pPicture->Release();
	free(image->data);	

	return TRUE;														// Return True (All Good)
}

bool Naskel3D::ImageLoad(NIMG_PTR image, char* filename,int type,GLfloat minfilter,GLfloat maxfilter)	
{
	unsigned 	int zip_size;
	unsigned 	char *zip_buf;
	char		tmp[] = "data/t.ntmp";
	unsigned char *pJpeg = NULL;
	bool		Stat = false;
	
	// PAK_FILE *************************************** PAK_FILE
	zip_buf = unzip::open("data/data.npk", filename, &zip_size);

	FILE *f = fopen(tmp, "wb");
		fwrite( zip_buf, sizeof(char), zip_size, f );
		fflush(f);
	fclose(f);
	#ifndef _DEBUG
	// dbgdel.cpp error ? 
	delete [] zip_buf;// Memory leeeeeeeeekkkkkkk :o)
	#endif
	// PAK_FILE *************************************** PAK_FILE End
		
	if (BuildTexture(tmp, image, minfilter, maxfilter)) Stat = true;

	remove (tmp);

	return Stat;
}

//******************************************//
// Sky Plane                                //
//******************************************//

void Naskel3D::InitSkyPlane(int divisions, float PlanetRadius, float AtmosphereRadius, 
					  float hTile, float vTile, DOME_PTR dome)
{
	// Make sure our vertex array is clear
	if (dome->PlaneVertices) 
	{
		#ifndef _DEBUG
		delete dome->PlaneVertices;
		dome->PlaneVertices = NULL;
		#endif
	}

	// Make sure our index array is clear
	if (dome->Indices)
	{
		#ifndef _DEBUG
		delete dome->Indices;
		dome->Indices = NULL;
		#endif
	}

	// Set the number of divisions into a valid range
	int divs = divisions;
	if (divisions < 1) 
		divs = 1;

	if (divisions > 512) 
		divs = 512; 

	dome->pRadius = PlanetRadius;

	// Initialize the Vertex and Indices arrays
	dome->NumPlaneVertices = (divs + 1) * (divs + 1);   // 1 division would give 4 verts
	dome->NumIndices  = divs * divs * 2 * 3;       // 1 division would give 6 indices for 2 tris

	dome->PlaneVertices = new VERTEX[dome->NumPlaneVertices];
	ZeroMemory(dome->PlaneVertices, sizeof(VERTEX));

	dome->Indices = new WORD[dome->NumIndices];
	ZeroMemory(dome->Indices, sizeof(WORD)*dome->NumIndices);

	// Calculate some values we will need
	float plane_size = 2.0f * (float)sqrt((SQR(AtmosphereRadius)-SQR(PlanetRadius)));
	float delta = plane_size/(float)divs;
	float tex_delta = 2.0f/(float)divs;
	
	// Variables we'll use during the dome's generation
	float x_dist   = 0.0f;
	float z_dist   = 0.0f;
	float x_height = 0.0f;
	float z_height = 0.0f;
	float height = 0.0f;

	int count = 0;

	VERTEX SV; // temporary vertex

	for (int i=0;i <= divs;i++)
	{
	    for (int j=0; j <= divs; j++)
		{
			x_dist = (-0.5f * plane_size) + ((float)j*delta);
			z_dist = (-0.5f * plane_size) + ((float)i*delta);

		    x_height = (x_dist*x_dist) / AtmosphereRadius;
			z_height = (z_dist*z_dist) / AtmosphereRadius;
			height = x_height + z_height;

			SV.x = x_dist;
			SV.y = 0.0f - height;
			SV.z = z_dist;

			// Calculate the texture coordinates
			SV.u = hTile*((float)j * tex_delta*0.5f);
			SV.v = vTile*(1.0f - (float)i * tex_delta*0.5f);

			dome->PlaneVertices[i*(divs+1)+j] = SV;
		}
	}

	// Calculate the indices
	int index = 0;
	for (i=0; i < divs;i++)
	{
		for (int j=0; j < divs; j++)
		{
			int startvert = (i*(divs+1) + j);

		    // tri 1
			dome->Indices[index++] = startvert;
			dome->Indices[index++] = startvert+1;
			dome->Indices[index++] = startvert+divs+1;

			// tri 2
			dome->Indices[index++] = startvert+1;
			dome->Indices[index++] = startvert+divs+2;
			dome->Indices[index++] = startvert+divs+1;
		}
	}
}

void Naskel3D::RenderSkyPlane(DOME dome)
{
	glBegin(GL_TRIANGLES);

	for (int i=0; i < dome.NumIndices; i++)
	{
		glColor3f(1.0f, 1.0f, 1.0f);		

		glTexCoord2f(dome.PlaneVertices[dome.Indices[i]].u, dome.PlaneVertices[dome.Indices[i]].v);
		glVertex3f(dome.PlaneVertices[dome.Indices[i]].x, dome.PlaneVertices[dome.Indices[i]].y, dome.PlaneVertices[dome.Indices[i]].z);
	}
	
	glEnd();
}

void Naskel3D::ReleaseSkyPlane(DOME dome)
{
	if (dome.PlaneVertices) 
	{
		#ifndef _DEBUG
		delete dome.PlaneVertices;
		dome.PlaneVertices = NULL;
		#endif
	}

	if (dome.Indices)
	{
		#ifndef _DEBUG
		// dbgdel.cpp error ? 
		delete dome.Indices;	// Memory leeeeeeeeekkkkkkk :o)
		#endif
		dome.Indices = NULL;
	}
}
void Naskel3D::DrawBackgrnd(NIMG image)
{
	glPushMatrix();
		glTranslatef(0.0f,0.0f,-10.0f);
	
		glEnable (GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, image.ID);

		glBegin(GL_QUADS);		// Front Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-9.0f, -8.0f,  -1.0f);	// Bottom Left Of The Texture and Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 9.0f, -8.0f,  -1.0f);	// Bottom Right Of The Texture and Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 9.0f,  8.0f,  -1.0f);	// Top Right Of The Texture and Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-9.0f,  8.0f,  -1.0f);	// Top Left Of The Texture and Quad
		glEnd();
	
		glDisable (GL_TEXTURE_2D);
	glPopMatrix();
}


// Create a cube with nice color...
void Naskel3D::CreateCube(float x, float y, float z, float radius)
{
	// Here we create 6 QUADS (Rectangles) to form a cube
	// With the passed in radius, we determine the width and height of the cube
	// You will notice, I add some color at each vertice to make it more interesting
	glPushMatrix();	

	glBegin(GL_QUADS);		
		
		// These vertices create the Back Side
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z);

		// These vertices create the Front Side
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z + radius);
		glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z + radius);

		// These vertices create the Bottom Face
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z);
			
		// These vertices create the Top Face
		glColor3ub(0, 0, 255);   glVertex3f(x, y + radius, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z);

		// These vertices create the Left Face
		glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x, y, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x, y + radius, z);

		// These vertices create the Right Face
		glColor3ub(0, 0, 255);   glVertex3f(x + radius, y, z);
		glColor3ub(255, 0, 255); glVertex3f(x + radius, y, z + radius);
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
		glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z);

	glEnd();
	
	glPopMatrix();
}

void Naskel3D::RotateMultiCube(int list, int rotate)
{
	glPushMatrix();
	float x = PosCube[list][0], y = PosCube[list][1], z =PosCube[list][2];
		if (rotate == 0) {
			glRotatef(m_fAngle, x, y, z);
			glRotatef(m_fAngle, x, y, z);
			glRotatef(m_fAngle, x, y, z);
		} else {
			glRotatef(-m_fAngle, x, y, z);
			glRotatef(-m_fAngle, x, y, z);
			glRotatef(-m_fAngle, x, y, z);
		}
	glCallList(ListSceneCube[list]);

	glPopMatrix();
}
void Naskel3D::ExplodeMultiCube(int list)
{
	glPushMatrix();
            
		switch(ExplodeRotate) {
			case 0: glTranslatef(ExplodeSpeed,0.0f,0.0f); break;
			case 1:	glTranslatef(0.0f,ExplodeSpeed*2,0.0f); break;
			case 2:	glTranslatef(0.0f,0.0f,ExplodeSpeed*3); break;	
			case 3: glTranslatef(-ExplodeSpeed,0.0f,0.0f); break;	
			case 4: glTranslatef(0.0f,-ExplodeSpeed*2,0.0f); break;	
			case 5: glTranslatef(0.0f,0.0f,-ExplodeSpeed*3); break;	
		}
		if (BExplode)  {
			ExplodeRotate++;
			if (ExplodeRotate==5)
				BExplode = false; 
		} else {			
			ExplodeRotate--;
			if (ExplodeRotate==0)
				BExplode = true; 
		}

		ExplodeSpeed+=0.00001f;
		
	glCallList(ListSceneCube[list]);

	glPopMatrix();
}

void Naskel3D::CreateMultiCube(float x, float y, float z, int list)
{
	ListSceneCube[list] = glGenLists(list);

	glNewList(ListSceneCube[list],GL_COMPILE);

	glBegin(GL_QUADS);		
	
	float radius = 0.04f;

	TotalCube++;
			
	// These vertices create the Back Side
	glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
	glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z);
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z); 
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z);

	// These vertices create the Front Side
	glColor3ub(0, 0, 255);   glVertex3f(x, y, z + radius);
	glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z + radius);
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z + radius);

	// These vertices create the Bottom Face
	glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
	glColor3ub(255, 0, 255); glVertex3f(x, y, z + radius);
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z + radius); 
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y, z);
			
	// These vertices create the Top Face
	glColor3ub(0, 0, 255);   glVertex3f(x, y + radius, z);
	glColor3ub(255, 0, 255); glVertex3f(x, y + radius, z + radius);
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z);

	// These vertices create the Left Face
	glColor3ub(0, 0, 255);   glVertex3f(x, y, z);
	glColor3ub(255, 0, 255); glVertex3f(x, y, z + radius);
	glColor3ub(0, 255, 255); glVertex3f(x, y + radius, z + radius); 
	glColor3ub(0, 255, 255); glVertex3f(x, y + radius, z);

	// These vertices create the Right Face
	glColor3ub(0, 0, 255);   glVertex3f(x + radius, y, z);
	glColor3ub(255, 0, 255); glVertex3f(x + radius, y, z + radius);
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z + radius); 
	glColor3ub(0, 255, 255); glVertex3f(x + radius, y + radius, z);
		
	glEnd();
	
	glEndList();
}

UINT Naskel3D::CreateOpenGL3DFont(LPSTR strFontName, float extrude, HWND m_hWnd)	
{
	UINT	fontListID = 0;
	HFONT	hFont;			
	fontListID = glGenLists(MAX_CHARS);
	hFont = CreateFont(	0, 0, 0, 0, FW_BOLD, FALSE, FALSE,
				FALSE, ANSI_CHARSET, OUT_TT_PRECIS,	
				CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
				FF_DONTCARE|DEFAULT_PITCH,  strFontName);

	g_hDC = ::GetDC(m_hWnd);
	
	hOldFont = (HFONT)SelectObject(g_hDC, hFont);

	wglUseFontOutlines(	g_hDC, 0, MAX_CHARS - 1,				
				fontListID, 0, 0.4f, WGL_FONT_POLYGONS,			
				g_GlyphInfo);				

	return fontListID;								
}

UINT Naskel3D::CreateSimpleFont(LPSTR strFontName, int height, HWND m_hWnd)	// Build Our Bitmap Font
{
	UINT	fontListID = 1;			// This will hold the base ID for our display list
	HFONT	hFont;				// This will store the handle to our font
	fontListID = glGenLists(MAX_CHARS);	// Generate the list for the font

	g_hDC = ::GetDC(m_hWnd);
	hFont = CreateFont(height, 0, 0, 0, FW_BOLD, FALSE,		
				FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS,	
				CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,	
				FF_DONTCARE|DEFAULT_PITCH, strFontName);		

	wglUseFontBitmaps(g_hDC, 0, MAX_CHARS - 1, fontListID);

	return fontListID;
}

void Naskel3D::PositionText( int x, int y )
{
	glPushAttrib( GL_TRANSFORM_BIT | GL_VIEWPORT_BIT );
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();	
	glLoadIdentity();	
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();	
	glLoadIdentity();
	y = w_height - FONT_HEIGHT - y;
	glViewport( x - 1, y - 1, 0, 0 );
	glRasterPos4f( 0, 0, 0, 1 );
	glPopMatrix();	
	glMatrixMode( GL_PROJECTION );
	glPopMatrix();
	glPopAttrib();	
}

void Naskel3D::glDrawText(int x, int y, const char *strString, ...)
{
	char		strText[256];
	va_list		argumentPtr;
	
	if (strString == NULL)	return;	
	va_start(argumentPtr, strString);
	vsprintf(strText, strString, argumentPtr);
	va_end(argumentPtr);
	PositionText(x, y);
	glPushAttrib(GL_LIST_BIT);
	glListBase(g_FontListSimpleID);
	glCallLists(strlen(strText), GL_UNSIGNED_BYTE, strText);
	glPopAttrib();	
}
void Naskel3D::DrawLogo()
{
	char	Text[]="Naskel3D";
	int	len = strlen(Text);
	PositionText(20, w_height-50);
	glPushAttrib(GL_LIST_BIT);
	glListBase(g_FontNaskel3DID);
	glCallLists(len, GL_UNSIGNED_BYTE, Text);
	glPopAttrib();	
}

void Naskel3D::glDraw3DText(const char *strString, ...)
{
	char		strText[256];			
	va_list		argumentPtr;			
	float		unitLength=0.0f;		
	if (strString == NULL)				
		return;					

	va_start(argumentPtr, strString);		
	vsprintf(strText, strString, argumentPtr);	
	va_end(argumentPtr);				

	for (int i=0; i < (int)strlen(strText); i++)
		unitLength += g_GlyphInfo[strText[i]].gmfCellIncX;	
	
	glTranslatef(0.0f - (unitLength / 2), 0.0f, 0.0f);

	glPushAttrib(GL_LIST_BIT);						
	glListBase(g_FontList3DID);						
	glCallLists(strlen(strText), GL_UNSIGNED_BYTE, strText);

	glPopAttrib();								
}

void Naskel3D::Destroy3DFont()										
{
	glDeleteLists(g_FontList3DID, MAX_CHARS);
	glDeleteLists(g_FontListSimpleID, MAX_CHARS);
	SelectObject(g_hDC, hOldFont);
}

void Naskel3D::InitScene(int part)
{
	switch(part) {

		case 0:	{
			// Sound...
			unsigned 	char *file;
			unsigned 	int size;
			file = unzip::open("data/data.npk", "sounds/REXLIL.XM", &size);
			// storing to an scratch file..... CHANGE ME
			FILE *f = fopen("data/s.ntmp", "wb");
				fwrite( file, sizeof(char), size, f );
				fflush(f);
			fclose(f); 
			
			#ifndef _DEBUG
			// dbgdel.cpp error ? 
			delete [] file; delete [] f; // Memory leeeeeeeeekkkkkkk :o)
			#endif
			
			if (!mods2::Init()) Error("Cant load the sound, Exiting now.");	// Load and play the song...
			if (!mods2::load("data/s.ntmp")) Error("Cant load the sound, Exiting now.");
			remove ("data/s.ntmp");	// All is in memory i can remove the temp file now..
			// ModPlayer End	
		}
		break;
				
		case 1: { 	// Init SceneCube
			int i = 0; float x,y,z;
			for (z=-0.5f;z<0.5f;z+=0.1f) {
			 for (y=-0.5f;y<0.5f;y+=0.1f)
			  for (x=-0.5f;x<0.5f;x+=0.08) {
			   CreateMultiCube(x,y,z,i);
			    // store the x,y,z pos of the cube
			   PosCube[i][0]=x; PosCube[i][1]=y; PosCube[i][2]=z;
			   i++;
			  }
			}
		}
		break;
		
		case 2: Star::InitStars(); sliding::Init(); ogl::Init(); break;		
	}	
}

void Naskel3D::NextScene(int n)
{
	float ActuTime = (timeGetTime()*0.001f) - StartTime;	// get the actual time

	if (NScene[n].FirstTimeScene) { // launch the timer
		NScene[n].FirstTimeScene = 0;
		NScene[n].SceneTime = (TIMEPERSCENE+ActuTime)-0.15;// = TIMEPERSCENE;
	}

	if (ActuTime<=NScene[n].SceneTime) { // do the current anim
		RenderScene(n);
	} else {	// ready to change the scene
		NScene[n+1].ThisScene=1;
		NScene[n].ThisScene=0;
	}

#ifdef __DEBUG
	char tmp[255],tmp1[255],tmp2[255],tmp3[255];
	
	sprintf(tmp, "GL_BLEND: %d - GL_CULL_FACE: %d - GL_DEPTH_TEST: %d - GL_TEXTURE_2D: %d - GL_NORMALIZE: %d",
	(glIsEnabled(GL_BLEND))		? 1 : 0,
	(glIsEnabled(GL_CULL_FACE))	? 1 : 0,
	(glIsEnabled(GL_DEPTH_TEST))	? 1 : 0,
	(glIsEnabled(GL_TEXTURE_2D))	? 1 : 0,
	(glIsEnabled(GL_NORMALIZE))	? 1 : 0);
	
	sprintf(tmp1, "GL_TEXTURE_GEN_S: %d - GL_TEXTURE_GEN_T: %d - GL_STENCIL_TEST: %d - GL_POLYGON_SMOOTH: %d",
	(glIsEnabled(GL_TEXTURE_GEN_S))	? 1 : 0,
	(glIsEnabled(GL_TEXTURE_GEN_T))	? 1 : 0,
	(glIsEnabled(GL_STENCIL_TEST))	? 1 : 0,
	(glIsEnabled(GL_POLYGON_SMOOTH))? 1 : 0);
	
	sprintf(tmp2, "GL_SMOOTH: %d - GL_LIGHTING: %d - GL_LIGHT0: %d - GL_LIGHT1: %d - GL_COLOR_MATERIAL: %d",
	(glIsEnabled(GL_SMOOTH))	? 1 : 0,
	(glIsEnabled(GL_LIGHTING))	? 1 : 0,
	(glIsEnabled(GL_LIGHT0))	? 1 : 0,
	(glIsEnabled(GL_LIGHT1))	? 1 : 0,
	(glIsEnabled(GL_COLOR_MATERIAL))	? 1 : 0);

	sprintf(tmp3, "GL_ALPHA_TEST: %d - GL_SCISSOR_TEST: %d - GL_LINE_SMOOTH: %d",
	(glIsEnabled(GL_ALPHA_TEST))	? 1 : 0,
	(glIsEnabled(GL_SCISSOR_TEST))	? 1 : 0,
	(glIsEnabled(GL_LINE_SMOOTH))	? 1 : 0
	);

	glDisable(GL_TEXTURE_2D);

	// Avance de la scene ... pratique pour le debug... :)
	// le timer n'est pas mis a jour !
	if (GotNextScene) {
		GotNextScene = false;
		NScene[n+1].ThisScene=1;
		NScene[n].ThisScene=0;
	}
	
	glColor3f(1, 1, 1);
	glDrawText(15, 25, "Scene %d  -  SceneTime: %f  -  ActuTime: %f", n+1, NScene[n].SceneTime, ActuTime);
		
	// On regarde les option d'ogl.. j'en ai marre d'avoir des probleme avec ca ;)
	glDrawText(15, 60, tmp);
	glDrawText(15, 76, tmp1);
	glDrawText(15, 88, tmp2);
	glDrawText(15, 100, tmp3);
		
#endif

}

void Naskel3D::RenderScene(int part)
{
	float ActuTime = (timeGetTime()*0.001f) - StartTime;
	
	switch(part) {

		case 0: {
			glPushMatrix();
				Reset();
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();
			
				glTranslatef(0.0f,0.0f,m_Z-FGalaxieMove);

				// First All scene move
				if (BGalaxieMove1) 
					if ((m_Z-FGalaxieMove)>= -5.29)
						FGalaxieMove+=0.005;
			
				// Draw the background
				DrawBackgrnd(texture0);
			
				// draw the star
				Star::vDraw();

				// call the multicube
				// first rotate...
				glRotatef(-m_fAngle, 0.0f, 1.0f, 0.0f);
				glRotatef(-m_fAngle, 0.0f, 0.0f, 1.0f);
				glRotatef(-m_fAngle+0.3f, 0.0f, 0.0f, 1.0f);

				int rotate = 0;

				// Si c le temps de finir, on explose tout ! ;)
				if (TimeToExplode!=true && ActuTime>23) {
					TimeToExplode=true;
				}
				if (ActuTime>28) // NScene[0].SceneTime)
					ExplodeSpeed*=ExplodeSpeed;// lol :)

				for (int i=0;i<=TotalCube;i++) {
					if (TimeToExplode) { 
						ExplodeMultiCube(i);
					} else {
						RotateMultiCube(i,rotate);
						if (rotate) rotate=0;
						else rotate=1;
					}
				}

				// call the normal cube and rotate a bit too ;)
				glRotatef(m_fAngle, 0.0f, 1.0f, 0.0f);
				glRotatef(m_fAngle, 0.0f, 0.0f, 1.0f);
				glRotatef(m_fAngle+0.3f, 0.0f, 0.0f, 1.0f);
			
				glEnable(GL_BLEND);		
				glBlendFunc(GL_SRC_ALPHA, GL_ONE);
				CreateCube(-0.9f, -0.9f, -0.9f, 1.9f);
		
				m_fAngle+= 0.8f;
			glPopMatrix();	
		}
		break;
		
		case 4: {
			glPushMatrix();
				Reset();
				glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();
				glTranslatef(0.0f,0.0f,-12.6f);
	
				fly::Draw();

				if (TimeFly!=true && ActuTime>NScene[1].SceneTime-28) TimeFly=true;
				if (TimeFly) {
				   switch (FlyText) {
				      case 0: glDrawText(FlySlide, w_height-50,"a Demo"); if (FlySlide>=w_width-50) {FlyRotate=false; FlyText++;} break;
				      case 1: glDrawText(FlySlide, w_height-50,"Without a"); if (FlySlide>=w_width-50) {FlyRotate=false; FlyText++;} break;
				      case 2: glDrawText(FlySlide, w_height-50,"Girl is"); if (FlySlide>=w_width-50) {FlyRotate=false; FlyText++;} break;
				      case 3: {
			      		// Rotate...
			      		glPushMatrix();
						glRotatef(m_fAngle, 0.0f, 1.0f, 0.0f);
						glRotatef(m_fAngle, 0.0f, 0.0f, 1.0f);
						glRotatef(m_fAngle+0.3f, 0.0f, 0.0f, 1.0f);
						glDisable(GL_TEXTURE_2D);
						glDisable(GL_BLEND);
						glColor3f(255, 0, 0);
				      		glDraw3DText("NOT a Demo ! :o)");
				      		glEnable(GL_TEXTURE_2D);
				      		glEnable(GL_BLEND);
				      		m_fAngle+=0.3f;
			      		glPopMatrix();
			      		
			      		// fade to white
					if (ActuTime>57.0) {
						glPushMatrix();
						float C;	// color...
						glTranslatef(0.0, 0.0, 13.2);
						glBindTexture(GL_TEXTURE_2D, FlyWhiteTex.ID);
						C =(ActuTime -10.8)/100;
						if (C>1) C =1;

						if (ActuTime>57.7)
				        	C = 10.8 - ActuTime/100;
	
						glBegin(GL_QUADS);
						    glTexCoord2f(0, 0);  glVertex3f(-2, -2, 0);
						    glTexCoord2f(1, 0);  glVertex3f( 2, -2, 0);	
						    glTexCoord2f(1, 1);  glVertex3f( 2,  2, 0);
						    glTexCoord2f(0, 1);  glVertex3f(-2,  2, 0);
						glEnd();
						glPopMatrix();
					}//58.082588
				      }
				      break;
				      }
				   if (FlySlide<=100) {FlyRotate=true;}
				   if (FlyRotate) FlySlide+= 4.0f;
				   else FlySlide-= 4.0f;
				}
		glPopMatrix();	
		}
		break;
		case 2: {	// Water
			glPushMatrix();
			Reset();
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();
				if (WaterResetPers) {
					water::Init(texwater);
					WaterResetPers = false;
				}
				float X=WaterCubeX, Y=WaterCubeY, Z=WaterCubeZ;
			
				glPushMatrix();
			
					// Only one time per 2 sec.
					
					if (!WaterDone) {
					WaterWait = ActuTime;
						if (WaterMove==0) {
							water::Move(WaterX,w_width/2);
							WaterMove = WATER_SPEED;
							if (WaterX>=w_height+20) {	WaterX=0; WaterY=0;WaterDone = true;}
							WaterX+=20;
						} else WaterMove--;
					}	

					if (WaterDone) {	// Sleep 4 sec before relaunching anim
						if (ActuTime>=(WaterWait+1)) {
							WaterWait = ActuTime;
							WaterDone = false;
						}
					}
					
					water::Display();
				glPopMatrix();
				m_fAngle+=0.8f;
			glPopMatrix();	
		}
		break;
		
		case 3: {
			glPushMatrix();
			Reset();
				// Moving
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();
				glTranslatef(0.0f,0.0f,0.7);
				moving::Draw();
			glPopMatrix();	
		}
		break;
		case 1: { // Matrix
			glPushMatrix();
			Reset();
				glEnable(GL_NORMALIZE);
				sliding::ProcessLevel();
				// in memory of my Amiga ;o)
				
			glPopMatrix();
		}
		break;
		case 5: {
			glPushMatrix();
				
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();	

				if (OglInit) {
					OglInit = false;
					Reset();
					ogl::Init();
				}
			
				glPushMatrix(); // Scene time: 
					glEnable(GL_LIGHTING);
					glEnable(GL_LIGHT0);
					glShadeModel(GL_SMOOTH);
					glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
					glEnable(GL_STENCIL_TEST);
					glLineWidth(1);
					
					if (RotateOgl1==true && ActuTime>148.01) {
						ogl::Reset();
						RotateOgl1 = false;
						RotateOgl2 = true;
					}

					if (RotateOgl2==true && ActuTime>152.06) {
						ogl::Reset();
						RotateOgl2 = false;
						RotateOgl3 = true;
					}

					if (RotateOgl3==true && ActuTime>156.09) {
						ogl::Reset();
						RotateOgl3 = false;
					}
					
					if ( RotateOgl3==false&& ActuTime>161) {
						// reset the last time
						ogl::Reset();
						glRotatef(m_fAngle, 0.0f, 1.0f, 0.0f);
						glRotatef(m_fAngle, 0.0f, 0.0f, 1.0f);
						glRotatef(m_fAngle+0.3f, 0.0f, 0.0f, 1.0f);
					}

					ogl::Draw();
					ogl::Animate();	
					m_fAngle+=0.8f;					
					
					Reset();
					glColor3f(1, 1, 1);
					glDrawText(60, 50," . - = M A d E  w I T h = - .");
			
				glPopMatrix();
				
			glPopMatrix();	
		}
		break;

		case 6: {
			glPushMatrix();
			//Reset();
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();
				// Init
				if (CylInit)
				{
					glDisable(GL_LIGHTING);
					glDisable(GL_LIGHT0);
					glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
					glFogi(GL_FOG_MODE, GL_EXP);		// Fog Mode
					glFogf(GL_FOG_DENSITY, 0.040f);
					glHint(GL_FOG_HINT, GL_DONT_CARE);
					glFogf(GL_FOG_START, 0.0f);
					glFogf(GL_FOG_END, 85.0f);	
					CylInit = false;
				}
				
				//*** Le Cylindre ***//
				tunnel->Cylindre_Deforme(deform_cyl,deform_cyl2,deform_cyl3);
				tunnel2->Cylindre_Deforme(deform_cyl,deform_cyl2,deform_cyl3);
				CylX=CylX+0.3f;
				deform_cyl2+=(float)(0.5*deform_cyl_val2);
				deform_cyl3+=(float)(0.5*deform_cyl_val3);
				
				Enable_Fog();
				
				glPushMatrix();
					glEnable(GL_TEXTURE_2D);
					glDisable(GL_CULL_FACE);
					glTranslatef(0.0f,0.0f,-25); //-30
					glRotatef(CylX,0.0f,0.0f,1.0f);
					glBindTexture(GL_TEXTURE_2D, Night.ID);
					tunnel->Cylindre_affiche();
				glPopMatrix();
					
				glPushMatrix();
					glEnable(GL_TEXTURE_2D);
					glEnable(GL_BLEND);
					glBindTexture(GL_TEXTURE_2D, Lava.ID);
					glRotatef(-CylX,0.0f,0.0f,1.0f);
					tunnel2->Cylindre_affiche();
					glDisable(GL_BLEND);
				glPopMatrix();
				//*** Le Cylindre ***//
				
				// Les ptits cube :)
				
				glPushMatrix();
					glDisable(GL_BLEND);
					glDisable(GL_TEXTURE_2D);
					
					glTranslatef(0.0f,0.0f,-AdvanceCube); //-30
					
					glRotatef(-CylX*2,1.0f,0.0f,0.0f);
					glRotatef(-CylX*2,0.0f,1.0f,0.0f);
					glRotatef(-CylX*2,0.0f,0.0f,1.0f);
					
					CreateCube(1.0,0.0,0.0,0.5);
			
					glPushMatrix();
						glTranslatef(1.0,0.0f,AdvanceCube/4); //-30
						CreateCube(AdvanceCube/4,1.0,1.0,0.5);
					glPopMatrix();	
					
					glPushMatrix();
						glTranslatef(2.0,0.5f,AdvanceCube/4); //-30
						CreateCube(0.0,1.0,0.0,0.5);
					glPopMatrix();	
					
				glPopMatrix();	
			
				if (AdvanceCube>=64) AdvanceCube =0.0;
				AdvanceCube +=0.5;
				
				Disable_Fog();	


			glPopMatrix();	
		}
		break;	
		
		case 7: { // Yeah Its the fianl :)
			glPushMatrix();
			Reset();
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
				glLoadIdentity();
				
				if (SkyDomeInit) {
					glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP); 
					glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP); 
					// Camera Pos
					objCamera.PositionCamera(15.88, 8.20,87.90, 103.01, 25.61, 103.01, 0.00, 1.00, 0.00); 
					SkyDomeInit = false;
				}
				SetMouse();

				// Render the sky plane, that was a nice effect :)
				glEnable(GL_TEXTURE_2D);
				glBindTexture(GL_TEXTURE_2D, Night.ID);
				
				glTranslatef(0.0f,SkyPlane1.pRadius,0);
				glRotatef(-m_fAngle,0.0f, 1.0f, 0.0f);
				RenderSkyPlane(SkyPlane1);

				m_fAngle+=0.05f;
				// -----				
				glPushMatrix();
					Reset();
					glDisable(GL_TEXTURE_2D);
					int Espace = 20;
					int H = ScrollText-100;
					int W = 500;
					glColor3f(1, 1, 1);
					
					float s = (H+(Espace*11)); // la base a suivre :)
					
					glDrawText(W, H+(Espace),"Elle est pour toi cette demo Kain ;)"); 
					glDrawText(W, H+(Espace*2),"           --");
					glDrawText(W, H+(Espace*3),"Thanx to :");
					glDrawText(W, H+(Espace*4),"My small brain ;)");
					glDrawText(W, H+(Espace*5),"All the coder over the world...");
					glDrawText(W, H+(Espace*6),"Fmod for your nice lib");
					glDrawText(W, H+(Espace*7),"Nvidia for your card, and your code");
					glDrawText(W, H+(Espace*8),"Nehe, for your tutorial");
					glDrawText(W, H+(Espace*9),"Jan Horn, We will never forget you...");
					glDrawText(W, H+(Espace*11),"Big Greets to:");

					if (scrollt == true && s<300) { // Affiche le logo de F0sT
						LogoF0sT();
					}
					glDrawText(W, H+(Espace*25),"To all my friends");
					glDrawText(W, H+(Espace*26),"Kikoo jeff ! :p");
					glDrawText(W, H+(Espace*27),"My gf, kiss babe :p");
					glDrawText(W, H+(Espace*28),"My son, you're the best baby on this world :o)");
					glDrawText(W, H+(Espace*29),"----------------------------------------------");
					glDrawText(W, H+(Espace*35),"And thank you for watching !");
					
					// wait 7 sec and slide down...
					if (PauseText) {
						if (ActuTime>=(PauseWait+7))
							LogoNaskel();
							return;
					}
					
					if (s<-150) {
						PauseWait = ActuTime;
						PauseText = true;
					}

				glPopMatrix();
				
				if (!fostdone)	ScrollText-=2.0f;
				
			glPopMatrix();	
		}
		break;
	}
}

void Naskel3D::LogoF0sT()
{
	float ActuTime = (timeGetTime()*0.001f) - StartTime;
	
	if (InitFost) {
		rotateFost = -20.0;
		InitFost = false;
		fostdone = true;
	}
	
	glPushMatrix();
		glLoadIdentity(); // reset..
		glTranslatef(1.5,rotateFost+10.5f,-5.0f);
		glDisable(GL_TEXTURE_2D); glDisable(GL_BLEND);
		glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
		glColor3f(197/255.0f, 197/255.0f, 197/255.0f);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glDraw3DText("F0sT");
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glColor3f(1, 1, 1);
	glPopMatrix();
	
	glPushMatrix();
		glLoadIdentity(); // reset..
		glTranslatef(rotateFost,0.0f,-50.0f);
	
		glEnable (GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, F0sT.ID);

		glBegin(GL_QUADS);		// Front Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-9.0f, -8.0f,  -1.0f);	// Bottom Left Of The Texture and Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 9.0f, -8.0f,  -1.0f);	// Bottom Right Of The Texture and Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 9.0f,  8.0f,  -1.0f);	// Top Right Of The Texture and Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-9.0f,  8.0f,  -1.0f);	// Top Left Of The Texture and Quad
		glEnd();
	
		glDisable (GL_TEXTURE_2D);
	glPopMatrix();
	
	if (directfost) {
		rotateFost +=0.05f;
		if (rotateFost >-12) { FostWait = ActuTime; directfost =false; }
	} else {
		// wait 7 sec and slide down...
		if (ActuTime>=(FostWait+7)) {
			rotateFost -=0.05f;
			if (rotateFost<-40) {
				scrollt = false;
				fostdone = false;
			}
		}
	}
}

void Naskel3D::LogoNaskel()
{
	float ActuTime = (timeGetTime()*0.001f) - StartTime;
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	
	m_fAngle+=0.8;
	
	glPushMatrix();
		glLoadIdentity(); // reset..
		glTranslatef(-4.0,0.0f,-30.0f);
	
		glEnable (GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, LogoN.ID);

		glBegin(GL_QUADS);		// Front Face
			glTexCoord2f(0.0f, 0.0f); glVertex3f(-13.0f, -5.0f,  -1.0f);	// Bottom Left Of The Texture and Quad
			glTexCoord2f(1.0f, 0.0f); glVertex3f( 13.0f, -5.0f,  -1.0f);	// Bottom Right Of The Texture and Quad
			glTexCoord2f(1.0f, 1.0f); glVertex3f( 13.0f,  5.0f,  -1.0f);	// Top Right Of The Texture and Quad
			glTexCoord2f(0.0f, 1.0f); glVertex3f(-13.0f,  5.0f,  -1.0f);	// Top Left Of The Texture and Quad
		glEnd();
	
		glDisable (GL_TEXTURE_2D);
	glPopMatrix();
	
	glPushMatrix();
		glLoadIdentity(); // reset..
		glTranslatef(1.8f,-0.5f,-4.5f);
		glRotatef(-m_fAngle,0.0f, 1.0f, 0.0f);
		glDisable(GL_TEXTURE_2D); glDisable(GL_BLEND);
		glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
		glColor3f(68/255.0f, 30/255.0f, 235/255.0f);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glDraw3DText("3D");
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glColor3f(1, 1, 1);
	glPopMatrix();
	
	glDrawText(w_width/2, w_height-150,"-( The End )-");
		
}

void Naskel3D::Reset()
{
	glDisable(GL_TEXTURE_2D);	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);		glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);	glDisable(GL_CULL_FACE);
	Disable_Fog();			glDisable(GL_BLEND);
	//glDisable(GL_NORMALIZE);	
	glDisable(GL_COLOR_MATERIAL);	glDisable(GL_STENCIL_TEST);
	glDisable(GL_LIGHT1);		glDisable(GL_LIGHT0);
	glDisable(GL_ALPHA_TEST);	glDisable(GL_SCISSOR_TEST);
	glDisable(GL_LINE_SMOOTH);
	glClearColor(0.0,0.0,0.0,0.0);	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
}

void Naskel3D::SetMouse()
{
	// look la pos.
	objCamera.Update();
	objCamera.Look();	
}
